import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import { StyleSheet, Text, View } from "react-native";
import PremiumButton from "./components/PremiumButton"; // ✅ CORRIGIDO

type Params = {
  status?: string;
  reason?: string;
  caution?: string;
};

export default function Atendimento() {
  const p = useLocalSearchParams<Params>();

  const status = (p.status ?? "PENDENTE").toString();
  const reason = (p.reason ?? "Sem detalhes").toString();
  const caution = (p.caution ?? "").toString();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ATENDIMENTO HUMANO</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Status do cadastro:</Text>
        <Text style={styles.value}>{status}</Text>

        <Text style={[styles.label, { marginTop: 10 }]}>Motivo:</Text>
        <Text style={styles.value}>{reason}</Text>

        {!!caution && (
          <>
            <Text style={[styles.label, { marginTop: 10 }]}>Alerta ao atendente:</Text>
            <Text style={[styles.value, { color: "#b00020" }]}>{caution}</Text>
          </>
        )}

        <View style={{ marginTop: 14 }}>
          <PremiumButton
            title="Enviar para análise humana (stub)"
            onPress={() => {
              router.replace("/");
            }}
            variant="steel"
          />
        </View>

        <View style={{ marginTop: 10 }}>
          <PremiumButton title="Voltar ao início" onPress={() => router.replace("/")} />
        </View>
      </View>

      <Text style={styles.hint}>
        * Se estiver REPROVADO ou PENDENTE, o atendente verá seus documentos com cuidado e cautela.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffffff",
    paddingTop: 60,
    paddingHorizontal: 16,
  },
  title: {
    fontSize: 26,
    fontWeight: "900",
    color: "#0b4aa6",
    marginBottom: 12,
  },
  card: {
    backgroundColor: "#f7fbff",
    borderWidth: 1,
    borderColor: "#dbe9ff",
    borderRadius: 16,
    padding: 14,
  },
  label: {
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 1,
    color: "#2b2b2b",
  },
  value: {
    marginTop: 4,
    fontSize: 14,
    fontWeight: "800",
    color: "#0b1d3a",
  },
  hint: {
    marginTop: 12,
    color: "#4a4a4a",
    fontSize: 12,
  },
});