export const TESLA_DAY_STYLE = [
  // base mais clean
  { elementType: "geometry", stylers: [{ saturation: -10 }, { lightness: 8 }] },

  // reduz POIs / poluição
  { featureType: "poi", stylers: [{ visibility: "off" }] },
  { featureType: "poi.park", stylers: [{ visibility: "on" }, { lightness: 15 }] },

  // labels mais discretos
  { elementType: "labels.text.fill", stylers: [{ color: "#4B5563" }] },
  { elementType: "labels.text.stroke", stylers: [{ color: "#FFFFFF" }, { weight: 3 }] },
  { featureType: "transit", stylers: [{ visibility: "off" }] },

  // ruas principais mais “premium”
  {
    featureType: "road",
    elementType: "geometry",
    stylers: [{ color: "#ffffff" }, { lightness: 12 }],
  },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#d7dde6" }, { weight: 1 }],
  },

  // água mais elegante
  {
    featureType: "water",
    elementType: "geometry",
    stylers: [{ color: "#cfe6ff" }, { lightness: 10 }],
  },
];