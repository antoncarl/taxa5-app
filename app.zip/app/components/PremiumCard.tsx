import React from "react";
import { StyleSheet, View, ViewProps } from "react-native";
import { UI } from "../theme/ui";

export function PremiumCard(props: ViewProps) {
  return <View {...props} style={[styles.card, props.style]} />;
}

const styles = StyleSheet.create({
  card: {
    borderRadius: UI.radius.lg,
    padding: UI.spacing.cardPad,
    backgroundColor: UI.colors.iceCard,
    borderWidth: 1,
    borderColor: UI.colors.borderBlueSoft,
    ...UI.shadow.blueSoft,
  },
});