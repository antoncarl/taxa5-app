import * as Haptics from "expo-haptics";
import React, { ReactNode, useEffect, useRef, useState } from "react";
import {
    Animated,
    Easing,
    Platform,
    Pressable,
    StyleSheet,
    TextInput,
    View,
} from "react-native";

type Props = {
  placeholder?: string;
  leftIcon?: ReactNode;
  dense?: boolean;

  value?: string;
  editable?: boolean;
  onPress?: () => void;

  onFocus?: () => void;
  onBlur?: () => void;
  onChangeText?: (t: string) => void;
};

export function PremiumInput({
  placeholder,
  leftIcon,
  dense,
  value,
  editable = true,
  onPress,
  onFocus,
  onBlur,
  onChangeText,
}: Props) {
  const [focused, setFocused] = useState(false);

  const glow = useRef(new Animated.Value(0)).current;
  const press = useRef(new Animated.Value(0)).current;

  const padY = dense ? 14 : 16;

  useEffect(() => {
    Animated.timing(glow, {
      toValue: focused ? 1 : 0,
      duration: focused ? 160 : 220,
      easing: Easing.out(Easing.ease),
      useNativeDriver: false,
    }).start();
  }, [focused, glow]);

  const shadowOpacity = glow.interpolate({
    inputRange: [0, 1],
    outputRange: [0.08, 0.14],
  });

  const borderColor = glow.interpolate({
    inputRange: [0, 1],
    outputRange: ["rgba(0,0,0,0.08)", "rgba(11,79,163,0.45)"],
  });

  const scale = press.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.985],
  });

  const handlePressIn = () => {
    Animated.timing(press, {
      toValue: 1,
      duration: 110,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.timing(press, {
      toValue: 0,
      duration: 160,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  };

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onPress={() => {
          if (!editable && onPress) {
            Haptics.selectionAsync();
            onPress();
          }
        }}
      >
        <Animated.View
          style={[
            styles.wrap,
            {
              paddingVertical: padY,
              borderColor: borderColor as any,
              shadowOpacity: shadowOpacity as any,
              opacity: editable ? 1 : 0.98,
            },
          ]}
        >
          {leftIcon ? <View style={styles.icon}>{leftIcon}</View> : null}

          <TextInput
            value={value}
            placeholder={placeholder}
            placeholderTextColor="#8A97A5"
            style={styles.input}
            editable={editable}
            pointerEvents={editable ? "auto" : "none"}
            onFocus={() => {
              setFocused(true);
              if (editable) Haptics.selectionAsync();
              onFocus?.();
            }}
            onBlur={() => {
              setFocused(false);
              onBlur?.();
            }}
            onChangeText={onChangeText}
          />

          <View pointerEvents="none" style={styles.innerHighlight} />
        </Animated.View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.98)",
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    shadowColor: "#000",
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 7 },
    elevation: Platform.OS === "android" ? 4 : 0,
  },

  icon: { marginRight: 10, opacity: 0.95 },

  input: {
    flex: 1,
    fontSize: 18,
    fontWeight: "800",
    color: "#1F2A37",
    paddingVertical: 0,
  },

  innerHighlight: {
    position: "absolute",
    left: 8,
    right: 8,
    top: 6,
    height: 18,
    borderRadius: 99,
    backgroundColor: "rgba(255,255,255,0.55)",
  },
});