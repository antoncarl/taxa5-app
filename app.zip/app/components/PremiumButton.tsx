import React, { useRef } from "react";
import {
  Animated,
  Easing,
  Pressable,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from "react-native";

type Variant = "primary" | "steel" | "danger" | "success";

type Props = {
  title: string;
  onPress?: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: Variant;
  style?: ViewStyle;
  leftIcon?: React.ReactNode;
  titleStyle?: any;
};

export default function PremiumButton({
  title,
  onPress,
  disabled = false,
  loading = false,
  variant = "primary",
  style,
  leftIcon,
  titleStyle,
}: Props) {

  const scale = useRef(new Animated.Value(1)).current;
  const depth = useRef(new Animated.Value(0)).current;

  const pressIn = () => {
    Animated.parallel([
      Animated.timing(scale, {
        toValue: 0.97,
        duration: 90,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(depth, {
        toValue: 1,
        duration: 90,
        useNativeDriver: false,
      }),
    ]).start();
  };

  const pressOut = () => {
    Animated.parallel([
      Animated.timing(scale, {
        toValue: 1,
        duration: 120,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(depth, {
        toValue: 0,
        duration: 120,
        useNativeDriver: false,
      }),
    ]).start();
  };

  const getColor = () => {
    switch (variant) {
      case "danger":
        return "#D62D2D";
      case "success":
        return "#16A34A";
      case "steel":
        return "#F5F7FA";
      default:
        return "#2B7AE6";
    }
  };

  const background = getColor();

  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      onPressIn={pressIn}
      onPressOut={pressOut}
      style={[styles.wrap, style]}
    >
      <Animated.View
        style={[
          styles.shell,
          {
            transform: [{ scale }],
          },
        ]}
      >
        <View
          style={[
            styles.button,
            {
              backgroundColor: background,
            },
          ]}
        >
          <View style={styles.gloss} />
          <View style={styles.depth} />

          <View style={styles.row}>
            {leftIcon && <View style={{ marginRight: 10 }}>{leftIcon}</View>}

            <Text
              style={[
                styles.text,
                variant === "steel" && { color: "#1F2A37" },
                titleStyle,
              ]}
            >
              {title}
            </Text>
          </View>
        </View>
      </Animated.View>
    </Pressable>
  );
}

const styles = StyleSheet.create({

  wrap: {
    width: "100%",
  },

  shell: {
    borderRadius: 999,
    padding: 4,
    shadowColor: "#2B7AE6",
    shadowOpacity: 0.35,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  button: {
    height: 64,
    borderRadius: 999,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  gloss: {
    position: "absolute",
    top: 0,
    width: "100%",
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.35)",
    borderTopLeftRadius: 999,
    borderTopRightRadius: 999,
  },

  depth: {
    position: "absolute",
    bottom: -6,
    width: "100%",
    height: "40%",
    backgroundColor: "rgba(0,0,0,0.15)",
    borderBottomLeftRadius: 999,
    borderBottomRightRadius: 999,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
  },

  text: {
    color: "#FFF",
    fontWeight: "900",
    fontSize: 17,
    letterSpacing: 1,
  },
});