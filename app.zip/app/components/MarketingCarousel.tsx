import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Dimensions,
  FlatList,
  NativeScrollEvent,
  NativeSyntheticEvent,
  StyleSheet,
  Text,
  View,
} from "react-native";

const { width: SCREEN_W } = Dimensions.get("window");

type Props = {
  height?: number;
};

type Slide = {
  title: string;
  subtitle: string;
};

export function MarketingCarousel({ height = 184 }: Props) {
  const data: Slide[] = useMemo(
    () => [
      { title: "VIAGENS COM DESCONTO", subtitle: "Até 20% OFF" },
      { title: "DESCONTO EM RESTAURANTES", subtitle: "Até 30% OFF" },
      { title: "PROMOÇÃO EM FARMÁCIAS", subtitle: "Até 25% OFF" },
    ],
    []
  );

  const listRef = useRef<FlatList<Slide>>(null);
  const [index, setIndex] = useState(0);

  const CARD_W = SCREEN_W - 32; // paddingHorizontal: 16 (dos lados)
  const AUTOPLAY_MS = 4500;

  useEffect(() => {
    const id = setInterval(() => {
      const next = (index + 1) % data.length;
      setIndex(next);
      listRef.current?.scrollToOffset({ offset: next * CARD_W, animated: true });
    }, AUTOPLAY_MS);

    return () => clearInterval(id);
  }, [index, data.length, CARD_W]);

  const onMomentumEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const x = e.nativeEvent.contentOffset.x;
    const i = Math.round(x / CARD_W);
    setIndex(i);
  };

  return (
    <View style={[styles.wrap, { height }]}>
      <FlatList
        ref={listRef}
        data={data}
        keyExtractor={(_, i) => String(i)}
        horizontal
        showsHorizontalScrollIndicator={false}
        pagingEnabled
        decelerationRate="fast"
        snapToInterval={CARD_W}
        snapToAlignment="start"
        disableIntervalMomentum
        onMomentumScrollEnd={onMomentumEnd}
        renderItem={({ item }) => (
          <View style={[styles.card, { width: CARD_W, height }]}>
            <Text style={styles.title}>{item.title}</Text>
            <Text style={styles.subtitle}>{item.subtitle}</Text>
          </View>
        )}
      />

      <View style={styles.dots}>
        {data.map((_, i) => (
          <View key={i} style={[styles.dot, i === index && styles.dotActive]} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: "100%",
  },

  card: {
    borderRadius: 26,
    backgroundColor: "#F8FCFF",
    borderWidth: 1,
    borderColor: "rgba(135, 194, 255, 0.35)",
    paddingHorizontal: 18,
    paddingTop: 24, // levemente menor pra caber no height 184
    paddingBottom: 18,
    justifyContent: "center",
    alignItems: "center",

    shadowColor: "#2D7CFF",
    shadowOpacity: 0.18,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 8,
  },

  // ✅ azul (marca) — mantém premium e não cinza
  title: {
    fontSize: 30, // ajustado para height 184
    fontWeight: "900",
    letterSpacing: 0.4,
    color: "#0B4FA3",
    textAlign: "center",
  },

  subtitle: {
    marginTop: 8,
    fontSize: 20, // ajustado para height 184
    fontWeight: "700",
    color: "#5F7388",
    textAlign: "center",
  },

  dots: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 10,
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },

  dot: {
    width: 6,
    height: 6,
    borderRadius: 99,
    backgroundColor: "rgba(11,79,163,0.20)",
  },

  dotActive: {
    width: 8,
    height: 8,
    backgroundColor: "rgba(11,79,163,0.85)",
  },
});