import React, { PropsWithChildren, useState } from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

type Props = PropsWithChildren & { title: string };

export function Collapsible({ children, title }: Props) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <View style={styles.wrap}>
      <TouchableOpacity
        style={styles.heading}
        onPress={() => setIsOpen((v) => !v)}
        activeOpacity={0.8}
      >
        <Text style={[styles.chevron, { transform: [{ rotate: isOpen ? "90deg" : "0deg" }] }]}>
          ▶
        </Text>

        <Text style={styles.title}>{title}</Text>
      </TouchableOpacity>

      {isOpen && <View style={styles.content}>{children}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { width: "100%" },

  heading: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 8,
  },

  chevron: {
    fontSize: 14,
    fontWeight: "900",
    color: "#0B4FA3",
    width: 18,
    textAlign: "center",
  },

  title: {
    fontSize: 14,
    fontWeight: "800",
    color: "#1F2A37",
  },

  content: {
    marginTop: 6,
    marginLeft: 26,
  },
});