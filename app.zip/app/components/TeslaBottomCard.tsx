import * as Haptics from "expo-haptics";
import React, { useRef } from "react";
import { Animated, Pressable, StyleSheet, Text, View } from "react-native";

export function TeslaBottomCard({ phase }: { phase: string }) {
  const progress = useRef(new Animated.Value(0)).current;

  const handlePress = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);

    Animated.timing(progress, {
      toValue: 1,
      duration: 900,
      useNativeDriver: false,
    }).start();
  };

  const width = progress.interpolate({
    inputRange: [0, 1],
    outputRange: ["0%", "100%"],
  });

  return (
    <View style={styles.wrap}>
      <View style={styles.card}>
        <Text style={styles.title}>
          {phase === "coming" ? "Motorista a caminho" : "Motorista chegou"}
        </Text>

        <Pressable style={styles.button} onPress={handlePress}>
          <Animated.View style={[styles.progress, { width }]} />
          <Text style={styles.text}>CONFIRMAR</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: "absolute",
    bottom: 20,
    left: 0,
    right: 0,
    padding: 16,
  },

  card: {
    backgroundColor: "#FFF",
    borderRadius: 20,
    padding: 16,
  },

  title: {
    fontWeight: "900",
    fontSize: 16,
    marginBottom: 10,
  },

  button: {
    height: 50,
    borderRadius: 14,
    backgroundColor: "#0B4FA3",
    justifyContent: "center",
    alignItems: "center",
    overflow: "hidden",
  },

  progress: {
    position: "absolute",
    left: 0,
    top: 0,
    bottom: 0,
    backgroundColor: "#083A7A",
  },

  text: {
    color: "#FFF",
    fontWeight: "900",
  },
});