// app/components/NeonButton.tsx
import React, { ReactNode, useEffect, useMemo, useRef } from "react";
import {
  Animated,
  Easing,
  Platform,
  Pressable,
  StyleProp,
  StyleSheet,
  Text,
  View,
  ViewStyle,
} from "react-native";

// Haptics opcional (se não tiver instalado, não quebra)
let Haptics: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  Haptics = require("expo-haptics");
} catch {}

/**
 * NeonButton INSANO
 * - Glow reage ao toque (press in/out)
 * - Pulse suave contínuo (respiração)
 * - Shimmer (faixa de brilho) passando por cima
 * - Haptic (se expo-haptics existir)
 *
 * Uso:
 * <NeonButton title="Chamar agora" onPress={() => {}} />
 * <NeonButton title="Emergência" tone="danger" />
 */

type Props = {
  title: string;
  subtitle?: string;
  onPress?: () => void;
  disabled?: boolean;

  // azul = padrão Taxa5, danger = vermelho claro, success = verde/azul
  tone?: "primary" | "danger" | "success" | "neutral";

  // ícone opcional (Ionicons etc)
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;

  style?: StyleProp<ViewStyle>;
};

export default function NeonButton({
  title,
  subtitle,
  onPress,
  disabled,
  tone = "primary",
  leftIcon,
  rightIcon,
  style,
}: Props) {
  const press = useRef(new Animated.Value(0)).current; // 0..1
  const pulse = useRef(new Animated.Value(0)).current; // 0..1 loop
  const shimmer = useRef(new Animated.Value(0)).current; // 0..1 loop

  const palette = useMemo(() => getPalette(tone), [tone]);

  useEffect(() => {
    // Pulse contínuo (respiração)
    const p = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 1700,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 1700,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );

    // Shimmer contínuo
    const s = Animated.loop(
      Animated.timing(shimmer, {
        toValue: 1,
        duration: 1800,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true,
      })
    );

    p.start();
    s.start();

    return () => {
      p.stop();
      s.stop();
    };
  }, [pulse, shimmer]);

  const scale = press.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.965],
  });

  const glowOpacity = press.interpolate({
    inputRange: [0, 1],
    outputRange: [0.22, 0.42],
  });

  const pulseScale = pulse.interpolate({
    inputRange: [0, 1],
    outputRange: [1.0, 1.03],
  });

  const shimmerX = shimmer.interpolate({
    inputRange: [0, 1],
    outputRange: [-160, 320],
  });

  const handlePressIn = () => {
    if (disabled) return;
    Animated.timing(press, {
      toValue: 1,
      duration: 120,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();

    try {
      Haptics?.selectionAsync?.();
    } catch {}
  };

  const handlePressOut = () => {
    if (disabled) return;
    Animated.timing(press, {
      toValue: 0,
      duration: 160,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  };

  const handlePress = () => {
    if (disabled) return;
    try {
      Haptics?.impactAsync?.(Haptics?.ImpactFeedbackStyle?.Light ?? "light");
    } catch {}
    onPress?.();
  };

  return (
    <Animated.View
      style={[
        styles.outer,
        style,
        {
          transform: [{ scale: Animated.multiply(scale, pulseScale) as any }],
        },
      ]}
    >
      {/* Glow externo (camada “neon”) */}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.glow,
          {
            shadowColor: palette.glow,
            opacity: disabled ? 0.08 : glowOpacity,
          },
        ]}
      />

      <Pressable
        onPress={handlePress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled}
        style={({ pressed }) => [
          styles.btn,
          {
            borderColor: disabled ? "rgba(0,0,0,0.10)" : palette.border,
            backgroundColor: disabled ? "rgba(245,248,252,0.92)" : palette.bg,
          },
          pressed && !disabled ? styles.btnPressed : null,
        ]}
      >
        {/* highlight interno superior */}
        <View pointerEvents="none" style={styles.innerHighlight} />

        {/* Shimmer */}
        <Animated.View
          pointerEvents="none"
          style={[
            styles.shimmer,
            {
              backgroundColor: palette.shimmer,
              transform: [{ translateX: shimmerX }, { rotate: "18deg" }],
              opacity: disabled ? 0 : 0.42,
            },
          ]}
        />

        <View style={styles.row}>
          {leftIcon ? <View style={styles.iconLeft}>{leftIcon}</View> : null}

          <View style={styles.textCol}>
            <Text
              style={[
                styles.title,
                { color: disabled ? "rgba(31,42,55,0.45)" : palette.text },
              ]}
              numberOfLines={1}
            >
              {title}
            </Text>

            {subtitle ? (
              <Text
                style={[
                  styles.subtitle,
                  { color: disabled ? "rgba(60,91,120,0.35)" : palette.subtext },
                ]}
                numberOfLines={1}
              >
                {subtitle}
              </Text>
            ) : null}
          </View>

          {rightIcon ? <View style={styles.iconRight}>{rightIcon}</View> : null}
        </View>
      </Pressable>
    </Animated.View>
  );
}

function getPalette(tone: Props["tone"]) {
  switch (tone) {
    case "danger":
      return {
        bg: "rgba(255,255,255,0.92)",
        border: "rgba(255,80,80,0.55)",
        glow: "rgba(255,80,80,0.95)",
        text: "#1F2A37",
        subtext: "rgba(128,44,44,0.70)",
        shimmer: "rgba(255,120,120,0.22)",
      };
    case "success":
      return {
        bg: "rgba(255,255,255,0.92)",
        border: "rgba(0,160,120,0.45)",
        glow: "rgba(0,160,120,0.95)",
        text: "#1F2A37",
        subtext: "rgba(0,90,70,0.70)",
        shimmer: "rgba(0,160,120,0.18)",
      };
    case "neutral":
      return {
        bg: "rgba(255,255,255,0.92)",
        border: "rgba(0,0,0,0.10)",
        glow: "rgba(45,124,255,0.85)",
        text: "#1F2A37",
        subtext: "rgba(60,91,120,0.68)",
        shimmer: "rgba(255,255,255,0.20)",
      };
    case "primary":
    default:
      return {
        bg: "rgba(255,255,255,0.92)",
        border: "rgba(135, 194, 255, 0.65)",
        glow: "rgba(45,124,255,0.95)",
        text: "#1F2A37",
        subtext: "rgba(11,79,163,0.72)",
        shimmer: "rgba(45,124,255,0.16)",
      };
  }
}

const styles = StyleSheet.create({
  outer: {
    width: "100%",
  },

  glow: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    borderRadius: 26,
    shadowOpacity: 1,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: Platform.OS === "android" ? 10 : 0,
  },

  btn: {
    borderRadius: 26,
    borderWidth: 1,
    overflow: "hidden",
    paddingVertical: 16,
    paddingHorizontal: 16,

    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 12 },
    elevation: Platform.OS === "android" ? 7 : 0,
  },

  btnPressed: {
    shadowOpacity: 0.06,
    elevation: Platform.OS === "android" ? 5 : 0,
  },

  innerHighlight: {
    position: "absolute",
    left: 10,
    right: 10,
    top: 8,
    height: 26,
    borderRadius: 99,
    backgroundColor: "rgba(255,255,255,0.40)",
  },

  shimmer: {
    position: "absolute",
    top: -30,
    bottom: -30,
    width: 90,
    borderRadius: 40,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },

  iconLeft: {
    width: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  iconRight: {
    width: 32,
    alignItems: "center",
    justifyContent: "center",
  },

  textCol: {
    flex: 1,
    gap: 2,
  },

  title: {
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: -0.2,
  },

  subtitle: {
    fontSize: 13,
    fontWeight: "700",
    letterSpacing: 0.2,
  },
});