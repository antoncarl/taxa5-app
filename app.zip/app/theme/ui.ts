export const UI = {
  colors: {
    brand: "#0B4FA3",
    brandDark: "#0A3F8A",
    ink: "#2B4055",
    iceBg: "#DCEEFF",      // fundo gelo azulado
    iceCard: "#F8FCFF",    // branco gelo com leve azul
    borderBlue: "rgba(135, 194, 255, 0.45)",
    borderBlueSoft: "rgba(135, 194, 255, 0.35)",
    glowBlue: "#2D7CFF",
    glass: "rgba(255,255,255,0.70)",
    placeholder: "rgba(76,97,117,0.55)", // mantém cinza só no placeholder
  },

  radius: {
    xl: 28,
    lg: 26,
    md: 22,
    sm: 18,
  },

  spacing: {
    pageX: 16,
    cardPad: 14,
  },

  type: {
    hello: { size: 20, weight: "700" as const, letter: 0.3 },
    title: { size: 36, weight: "900" as const, letter: 0.5 },
    label: { size: 15, weight: "900" as const, letter: 2.5 },
  },

  shadow: {
    // brilho premium azul (NUNCA cinza)
    blueSoft: {
      shadowColor: "#2D7CFF",
      shadowOpacity: 0.18,
      shadowRadius: 18,
      shadowOffset: { width: 0, height: 10 },
      elevation: 8,
    },
    blueStrong: {
      shadowColor: "#2D7CFF",
      shadowOpacity: 0.25,
      shadowRadius: 22,
      shadowOffset: { width: 0, height: 12 },
      elevation: 12,
    },
  },
};