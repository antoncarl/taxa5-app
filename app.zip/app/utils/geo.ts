type Coord = { latitude: number; longitude: number };

export const toRad = (v: number) => (v * Math.PI) / 180;

export const haversineKm = (a: Coord, b: Coord) => {
  const R = 6371;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);

  const x =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);

  const c = 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  return R * c;
};

export const lerpCoord = (a: Coord, b: Coord, t: number): Coord => ({
  latitude: a.latitude + (b.latitude - a.latitude) * t,
  longitude: a.longitude + (b.longitude - a.longitude) * t,
});

export const bearingDeg = (a: Coord, b: Coord) => {
  const y = Math.sin(toRad(b.longitude - a.longitude)) * Math.cos(toRad(b.latitude));
  const x =
    Math.cos(toRad(a.latitude)) * Math.sin(toRad(b.latitude)) -
    Math.sin(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.cos(toRad(b.longitude - a.longitude));

  const brng = (Math.atan2(y, x) * 180) / Math.PI;
  return (brng + 360) % 360;
};

// rota “suave” (simples, barato, suficiente p/ demo Tesla)
export const buildRoute = (from: Coord, to: Coord, points = 18): Coord[] => {
  const arr: Coord[] = [];
  for (let i = 0; i <= points; i++) {
    const t = i / points;

    // leve curva (cinema): empurra um pouquinho no meio
    const curve = Math.sin(t * Math.PI) * 0.00035;

    arr.push({
      latitude: from.latitude + (to.latitude - from.latitude) * t + curve,
      longitude: from.longitude + (to.longitude - from.longitude) * t - curve,
    });
  }
  return arr;
};