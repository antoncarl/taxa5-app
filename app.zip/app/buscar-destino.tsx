import { useRouter } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import MapView, { PROVIDER_GOOGLE } from "react-native-maps";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "rgba(255,255,255,0.92)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(15,23,42,0.10)",
    border2: "rgba(15,23,42,0.08)",
    blue: "#0B4FA3",
    blueSoft: "rgba(11,79,163,0.12)",
    white: "#FFFFFF",
  },
  radius: { lg: 16, xl: 22, pill: 999 },
};

export default function BuscarDestino() {
  const router = useRouter();

  const openBusca = () => router.push("/passageiro/busca");

  return (
    <View style={styles.container}>
      <MapView
        style={StyleSheet.absoluteFillObject}
        provider={PROVIDER_GOOGLE}
        showsCompass={false}
        showsMyLocationButton={false}
        toolbarEnabled={false}
        showsUserLocation
        pitchEnabled
        rotateEnabled
      />

      {/* Top UI */}
      <View style={styles.topWrap}>
        <Text style={styles.titleHello}>Olá, Anton</Text>
        <Text style={styles.title}>Para onde vamos?</Text>

        <View style={styles.card}>
          <Text style={styles.label}>EMBARQUE</Text>

          <Pressable onPress={openBusca} style={styles.inputWrap}>
            <Text style={styles.icon}>🔍</Text>
            <TextInput
              placeholder="Sua localização"
              placeholderTextColor="rgba(11,27,43,0.35)"
              style={styles.input}
              editable={false}
              pointerEvents="none"
            />
          </Pressable>

          <Text style={[styles.label, { marginTop: 14 }]}>DESTINO</Text>

          <Pressable onPress={openBusca} style={styles.inputWrap}>
            <Text style={styles.icon}>🔍</Text>
            <TextInput
              placeholder="Digitar destino..."
              placeholderTextColor="rgba(11,27,43,0.35)"
              style={styles.input}
              editable={false}
              pointerEvents="none"
            />
          </Pressable>
        </View>
      </View>

      {/* Bottom marketing */}
      <View style={styles.bottomWrap}>
        <View style={styles.marketingCard}>
          <Text style={styles.marketingTitle}>VIAGENS COM DESCONTO</Text>
          <Text style={styles.marketingSub}>Até 20% OFF</Text>
        </View>
      </View>

      {/* leve “nitidez” */}
      <View pointerEvents="none" style={styles.crispOverlay} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: UI.colors.bg },

  topWrap: {
    position: "absolute",
    top: 52,
    left: 16,
    right: 16,
  },

  titleHello: {
    fontSize: 18,
    fontWeight: "700",
    textAlign: "center",
    marginBottom: 6,
    color: UI.colors.text,
  },

  title: {
    fontSize: 34,
    fontWeight: "900",
    textAlign: "center",
    marginBottom: 14,
    color: UI.colors.text,
  },

  card: {
    borderRadius: UI.radius.xl,
    padding: 16,
    borderWidth: 1,
    borderColor: UI.colors.border,
    backgroundColor: UI.colors.surface,
  },

  label: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 2,
    color: "rgba(11,27,43,0.70)",
  },

  inputWrap: {
    marginTop: 10,
    height: 54,
    borderRadius: UI.radius.lg,
    borderWidth: 1,
    borderColor: UI.colors.border2,
    backgroundColor: UI.colors.white,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    gap: 10,
  },

  icon: { fontSize: 18 },

  input: {
    flex: 1,
    fontSize: 15,
    fontWeight: "600",
    color: UI.colors.text,
  },

  bottomWrap: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 22,
  },

  marketingCard: {
    borderRadius: UI.radius.xl,
    paddingVertical: 18,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: UI.colors.border,
    backgroundColor: UI.colors.surface,
    alignItems: "center",
  },

  marketingTitle: {
    fontSize: 22,
    fontWeight: "900",
    color: UI.colors.blue,
    letterSpacing: 1,
    textAlign: "center",
  },

  marketingSub: {
    marginTop: 6,
    fontSize: 14,
    fontWeight: "700",
    color: UI.colors.muted,
  },

  crispOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.03)",
  },
});