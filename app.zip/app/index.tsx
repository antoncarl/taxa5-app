import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import React, { useEffect, useRef } from "react";
import { Animated, Easing, Image, StyleSheet, View } from "react-native";

export default function Index() {
  const router = useRouter();

  const glow = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const aGlow = Animated.loop(
      Animated.sequence([
        Animated.timing(glow, {
          toValue: 1,
          duration: 850,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(glow, {
          toValue: 0,
          duration: 850,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    );

    const aScale = Animated.loop(
      Animated.sequence([
        Animated.timing(scale, {
          toValue: 1.02,
          duration: 900,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(scale, {
          toValue: 1.0,
          duration: 900,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
      ])
    );

    aGlow.start();
    aScale.start();

    const t = setTimeout(() => {
      router.replace("/start"); // precisa existir: app/start.tsx
    }, 2600);

    return () => {
      clearTimeout(t);
      aGlow.stop();
      aScale.stop();
      glow.stopAnimation();
      scale.stopAnimation();
    };
  }, [router, glow, scale]);

  const glowOpacity = glow.interpolate({
    inputRange: [0, 1],
    outputRange: [0.18, 0.55],
  });

  return (
    <View style={styles.screen}>
      <StatusBar hidden />

      {/* LOGO TELA CHEIA */}
      <Animated.View
        style={[StyleSheet.absoluteFillObject, { transform: [{ scale }] }]}
      >
        <Image
          source={require("../assets/logo.png")}
          style={StyleSheet.absoluteFillObject}
          resizeMode="cover"
        />
      </Animated.View>

      {/* BRILHO */}
      <Animated.View
        pointerEvents="none"
        style={[styles.glow, { opacity: glowOpacity }]}
      />

      {/* VINHETA LEVE */}
      <View pointerEvents="none" style={styles.vignette} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#000000",
  },
  glow: {
    position: "absolute",
    left: "50%",
    top: "50%",
    width: 560,
    height: 560,
    marginLeft: -280,
    marginTop: -280,
    borderRadius: 560,
    backgroundColor: "#2B7AE6",
  },
  vignette: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.35)",
  },
});