import AsyncStorage from "@react-native-async-storage/async-storage";

export type SentinelStatus = "EM_ANALISE" | "APROVADO" | "PENDENTE" | "REPROVADO";

const KEY = "@sentinel:status";

export async function getSentinelStatus(): Promise<SentinelStatus> {
  const v = await AsyncStorage.getItem(KEY);
  if (v === "APROVADO" || v === "PENDENTE" || v === "REPROVADO" || v === "EM_ANALISE") return v;
  return "EM_ANALISE";
}

export async function setSentinelStatus(status: SentinelStatus) {
  await AsyncStorage.setItem(KEY, status);
}
