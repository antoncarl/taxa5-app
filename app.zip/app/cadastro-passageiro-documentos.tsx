import { MaterialIcons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Alert,
    Platform,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

type DocKey = "frente" | "verso" | "selfie" | "upload";

export default function CadastroPassageiroDocumentos() {
  const [frente, setFrente] = useState(false);
  const [verso, setVerso] = useState(false);
  const [selfie, setSelfie] = useState(false);
  const [upload, setUpload] = useState(false);

  const canFinish = useMemo(() => {
    const docOk = upload || (frente && verso);
    return selfie && docOk;
  }, [frente, verso, selfie, upload]);

  function toggle(k: DocKey) {
    if (k === "frente") setFrente((v) => !v);
    if (k === "verso") setVerso((v) => !v);
    if (k === "selfie") setSelfie((v) => !v);
    if (k === "upload") setUpload((v) => !v);
  }

  function onPressLinha(k: DocKey) {
    const nome =
      k === "frente"
        ? "Foto frente"
        : k === "verso"
        ? "Foto verso"
        : k === "selfie"
        ? "Selfie (prova de vida)"
        : "Upload (RG/CNH digital/arquivo)";

    Alert.alert(
      nome,
      "No MVP isso ainda é mock.\nDeseja marcar/desmarcar para simular?",
      [
        { text: "Cancelar", style: "cancel" },
        { text: "Marcar/Desmarcar", onPress: () => toggle(k) },
      ]
    );
  }

  function concluir() {
    if (!canFinish) {
      Alert.alert(
        "Ainda falta",
        "Para concluir: Selfie + (Upload OU Foto frente + Foto verso)."
      );
      return;
    }

    // Próximo passo: status em análise (ou outra rota sua)
    router.replace({
      pathname: "/sentinel-status",
      params: { status: "EM_ANALISE" },
    });
  }

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={12}>
          <MaterialIcons name="arrow-back" size={22} color={COLORS.blue} />
        </Pressable>

        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Passageiro</Text>
          <Text style={styles.headerSub}>Documentos • Etapa 2/3</Text>
        </View>

        <View style={styles.secBadge}>
          <MaterialIcons name="verified-user" size={18} color={COLORS.blue} />
          <Text style={styles.secBadgeText}>SENTINEL</Text>
        </View>
      </View>

      {/* Title */}
      <Text style={styles.title}>DOCUMENTOS</Text>
      <Text style={styles.subtitle}>
        Documento oficial + selfie (prova de vida). Você pode enviar por foto OU upload.
      </Text>

      {/* Card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Documento oficial com foto</Text>

        <DocLine label="Foto frente" done={frente} icon="photo-camera" onPress={() => onPressLinha("frente")} />
        <DocLine label="Foto verso" done={verso} icon="photo-camera" onPress={() => onPressLinha("verso")} />
        <DocLine label="Selfie (prova de vida)" done={selfie} icon="photo-camera" onPress={() => onPressLinha("selfie")} />
        <DocLine label="Upload (RG/CNH digital/arquivo)" done={upload} icon="upload-file" onPress={() => onPressLinha("upload")} />

        <View style={styles.noteBox}>
          <MaterialIcons name="info" size={18} color={COLORS.blue} />
          <Text style={styles.noteText}>
            Regra Brasil: documento digital = Upload. Documento físico = Foto frente + verso. Um ou outro. A selfie é obrigatória.
          </Text>
        </View>

        <View style={styles.requirementsBox}>
          <ReqRow ok={selfie} text="Selfie obrigatória" />
          <ReqRow ok={upload || (frente && verso)} text="Upload OU (frente + verso)" />
        </View>

        <View style={styles.actionsRow}>
          <Pressable onPress={() => router.back()} style={styles.secondaryBtn}>
            <Text style={styles.secondaryText}>Voltar</Text>
          </Pressable>

          <Pressable
            onPress={concluir}
            style={[styles.primaryBtn, !canFinish && styles.primaryBtnDisabled]}
          >
            <Text style={[styles.primaryText, !canFinish && styles.primaryTextDisabled]}>
              Concluir
            </Text>
          </Pressable>
        </View>

        <View style={styles.mockBox}>
          <Text style={styles.mockTitle}>Mock rápido</Text>
          <View style={styles.mockGrid}>
            <MockBtn text="Frente" onPress={() => toggle("frente")} />
            <MockBtn text="Verso" onPress={() => toggle("verso")} />
            <MockBtn text="Selfie" onPress={() => toggle("selfie")} />
            <MockBtn text="Upload" onPress={() => toggle("upload")} />
          </View>
        </View>
      </View>

      <View style={{ height: 18 }} />
    </ScrollView>
  );
}

function DocLine({
  label,
  done,
  icon,
  onPress,
}: {
  label: string;
  done: boolean;
  icon: any;
  onPress: () => void;
}) {
  return (
    <Pressable style={styles.docLine} onPress={onPress}>
      <View style={{ flex: 1, paddingRight: 10 }}>
        <Text style={styles.docLineText} numberOfLines={1}>
          {label}
        </Text>

        <View style={styles.pillRow}>
          <View style={[styles.pill, done ? styles.pillOk : styles.pillPending]}>
            <Text style={[styles.pillText, done ? styles.pillTextOk : styles.pillTextPending]}>
              {done ? "OK" : "Pendente"}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.docRight}>
        <View style={styles.iconCircle}>
          <MaterialIcons name={icon} size={20} color={COLORS.blue} />
        </View>
        <MaterialIcons name="chevron-right" size={24} color={COLORS.gray2} />
      </View>
    </Pressable>
  );
}

function ReqRow({ ok, text }: { ok: boolean; text: string }) {
  return (
    <View style={styles.reqRow}>
      <MaterialIcons
        name={ok ? "check-circle" : "radio-button-unchecked"}
        size={18}
        color={ok ? COLORS.green : COLORS.gray2}
      />
      <Text style={styles.reqText}>{text}</Text>
    </View>
  );
}

function MockBtn({ text, onPress }: { text: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.mockBtn}>
      <Text style={styles.mockBtnText}>{text}</Text>
    </Pressable>
  );
}

const COLORS = {
  bg: "#FFFFFF",
  card: "#F7FBFF",
  blue: "#0B5CFF",
  text: "#0E1B2A",
  gray: "#637083",
  gray2: "#8A99AB",
  border: "#DCEBFF",
  border2: "#E8F2FF",
  green: "#1AAE6F",
};

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.bg },
  content: {
    paddingTop: Platform.OS === "android" ? 12 : 18,
    paddingHorizontal: 16,
    paddingBottom: 28,
  },

  header: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10 },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  headerTitle: { color: COLORS.text, fontSize: 16, fontWeight: "900" },
  headerSub: { marginTop: 2, color: COLORS.gray, fontSize: 12, fontWeight: "700" },

  secBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#EAF3FF",
    borderWidth: 1,
    borderColor: "#CFE3FF",
  },
  secBadgeText: { color: COLORS.blue, fontWeight: "900", fontSize: 12, letterSpacing: 0.6 },

  title: { color: COLORS.blue, fontSize: 28, fontWeight: "900", letterSpacing: 0.6, marginTop: 6 },
  subtitle: { color: COLORS.gray, fontSize: 13, marginTop: 6, marginBottom: 14, lineHeight: 18, fontWeight: "700" },

  card: { borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, padding: 14, backgroundColor: COLORS.card },
  cardTitle: { color: COLORS.text, fontSize: 16, fontWeight: "900", marginBottom: 12 },

  docLine: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: COLORS.border2,
    marginBottom: 10,
  },
  docLineText: { color: COLORS.text, fontSize: 15, fontWeight: "900" },

  pillRow: { marginTop: 8, flexDirection: "row" },
  pill: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, borderWidth: 1 },
  pillOk: { backgroundColor: "#E9FFF3", borderColor: "#BFEED7" },
  pillPending: { backgroundColor: "#F3F6FA", borderColor: "#E2E9F3" },
  pillText: { fontSize: 12, fontWeight: "900" },
  pillTextOk: { color: COLORS.green },
  pillTextPending: { color: COLORS.gray2 },

  docRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  iconCircle: {
    width: 38,
    height: 38,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#EAF3FF",
    borderWidth: 1,
    borderColor: "#CFE3FF",
  },

  noteBox: {
    marginTop: 10,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    padding: 12,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: COLORS.border2,
  },
  noteText: { flex: 1, color: COLORS.gray, fontSize: 12, fontWeight: "700", lineHeight: 16 },

  requirementsBox: {
    marginTop: 12,
    padding: 12,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: COLORS.border2,
    gap: 8,
  },
  reqRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  reqText: { color: COLORS.gray, fontSize: 13, fontWeight: "800" },

  actionsRow: { marginTop: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  secondaryBtn: {
    height: 46,
    paddingHorizontal: 16,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  secondaryText: { color: COLORS.blue, fontWeight: "900", fontSize: 15 },

  primaryBtn: {
    flex: 1,
    height: 46,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.blue,
    borderWidth: 1,
    borderColor: "#083FAE",
  },
  primaryBtnDisabled: { backgroundColor: "#D9E7FF", borderColor: "#C8DCFF" },
  primaryText: { color: "#FFFFFF", fontSize: 15, fontWeight: "900", letterSpacing: 0.2 },
  primaryTextDisabled: { color: "#6C7EA0" },

  mockBox: { marginTop: 14, padding: 12, borderRadius: 16, borderWidth: 1, borderColor: COLORS.border2, backgroundColor: "#FFFFFF" },
  mockTitle: { color: COLORS.gray2, fontSize: 12, fontWeight: "900", marginBottom: 10 },
  mockGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  mockBtn: { paddingVertical: 10, paddingHorizontal: 12, borderRadius: 14, backgroundColor: "#EAF3FF", borderWidth: 1, borderColor: "#CFE3FF" },
  mockBtnText: { color: COLORS.blue, fontWeight: "900", fontSize: 13 },
});
