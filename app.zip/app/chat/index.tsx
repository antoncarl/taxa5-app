import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import {
    collection,
    doc,
    getDocs,
    limit,
    orderBy,
    query,
    serverTimestamp,
    setDoc,
} from "firebase/firestore";
import React, { useEffect, useMemo, useState } from "react";
import {
    ActivityIndicator,
    FlatList,
    Pressable,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// ⚠️ Ajuste caminho se necessário
import { auth, db } from "../../src/lib/firebase";

type Thread = {
  id: string;
  title: string;
  updatedAt?: any;
};

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
  },
  radius: { lg: 18, xl: 22 },
};

export default function ChatList() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const uid = auth.currentUser?.uid;

  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);

  const [fontsLoaded] = useFonts({ Cinzel_700Bold });

  const cinzel = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : undefined),
    [fontsLoaded]
  );

  // 🔥 Carregar conversas
  useEffect(() => {
    if (!uid) return;

    (async () => {
      try {
        const q = query(
          collection(db, "chat_threads"),
          orderBy("updatedAt", "desc"),
          limit(50)
        );

        const snap = await getDocs(q);

        const arr: Thread[] = snap.docs.map((d) => ({
          id: d.id,
          title: d.data().title || "Conversa",
          updatedAt: d.data().updatedAt,
        }));

        setThreads(arr);
      } catch (e) {
        console.log("Erro threads:", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [uid]);

  // 🚀 Criar conversa motorista/passageiro
  async function createThread(type: "passageiro" | "motorista" | "suporte") {
    if (!uid) return;

    const id = `${type}_${uid}_${Date.now()}`;

    await setDoc(doc(db, "chat_threads", id), {
      id,
      type,
      participants: [uid],
      title:
        type === "suporte"
          ? "SUPORTE"
          : type === "motorista"
          ? "Motorista"
          : "Passageiro",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    router.push({
      pathname: "/chat/[threadId]",
      params: { threadId: id, title: type.toUpperCase() },
    });
  }

  function openThread(t: Thread) {
    router.push({
      pathname: "/chat/[threadId]",
      params: { threadId: t.id, title: t.title },
    });
  }

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, cinzel]}>CONVERSAS</Text>

      {/* BOTÕES CRIAR */}
      <View style={styles.actions}>
        <Primary title="Chat Passageiro" onPress={() => createThread("passageiro")} />
        <Primary title="Chat Motorista" onPress={() => createThread("motorista")} />
        <Primary title="Suporte" onPress={() => createThread("suporte")} />
      </View>

      {/* LISTA */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={threads}
          keyExtractor={(i) => i.id}
          renderItem={({ item }) => (
            <Pressable onPress={() => openThread(item)} style={styles.row}>
              <Text style={styles.rowTitle}>{item.title}</Text>
              <Text style={styles.rowSub}>{item.id}</Text>
            </Pressable>
          )}
          contentContainerStyle={{ paddingBottom: 40 }}
        />
      )}
    </View>
  );
}

function Primary({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.btn}>
      <Text style={styles.btnText}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    marginBottom: 12,
    color: UI.colors.text,
  },

  actions: {
    gap: 10,
    marginBottom: 14,
  },

  btn: {
    height: 54,
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },

  btnText: {
    color: "#fff",
    fontWeight: "900",
    fontSize: 14,
  },

  row: {
    backgroundColor: "#fff",
    borderRadius: UI.radius.lg,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: UI.colors.border,
  },

  rowTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: UI.colors.text,
  },

  rowSub: {
    marginTop: 4,
    fontSize: 11,
    color: UI.colors.muted,
  },

  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});