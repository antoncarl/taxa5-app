import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system";
import { useFonts } from "expo-font";
import * as ImagePicker from "expo-image-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import {
    addDoc,
    collection,
    doc,
    limit,
    onSnapshot,
    orderBy,
    query,
    serverTimestamp,
    updateDoc,
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
    ActivityIndicator,
    FlatList,
    KeyboardAvoidingView,
    Platform,
    Pressable,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// ✅ Seu projeto tem src/firebase (não src/lib)
import { auth, db, storage } from "../../src/lib/firebase";

type Msg = {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  createdAt?: any;
  file?: {
    url: string;
    mime?: string;
    name?: string;
    size?: number;
    kind?: "image" | "video" | "audio" | "file";
  };
};

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    bubbleUser: "#2B7AE6",
    bubbleAi: "#FFFFFF",
  },
  radius: { lg: 18, xl: 22, pill: 999 },
};

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || ""; // ex: https://seuapp.onrender.com

export default function ChatThread() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { threadId, title } = useLocalSearchParams<{ threadId: string; title?: string }>();

  const uid = auth.currentUser?.uid;

  const [fontsLoaded] = useFonts({ Cinzel_700Bold });
  const cinzel = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : undefined),
    [fontsLoaded]
  );

  const [messages, setMessages] = useState<Msg[]>([]);
  const [loading, setLoading] = useState(true);

  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  // input cresce até ~10 linhas
  const [inputH, setInputH] = useState(50);
  const inputMin = 50;
  const inputMax = 50 + 9 * 20; // ~10 linhas
  const listRef = useRef<FlatList<Msg>>(null);

  // ============
  // Realtime
  // ============
  useEffect(() => {
    if (!threadId) return;

    const q = query(
      collection(db, "chat_threads", String(threadId), "messages"),
      orderBy("createdAt", "desc"),
      limit(200)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const arr: Msg[] = snap.docs.map((d) => {
          const v: any = d.data();
          return {
            id: d.id,
            role: v.role || "system",
            text: v.text || "",
            createdAt: v.createdAt,
            file: v.file || undefined,
          };
        });

        setMessages(arr);
        setLoading(false);
      },
      (err) => {
        console.log("snapshot error:", err);
        setLoading(false);
      }
    );

    return unsub;
  }, [threadId]);

  // ============
  // Helpers
  // ============
  async function pushMessage(m: Omit<Msg, "id">) {
    if (!threadId) return;

    await addDoc(collection(db, "chat_threads", String(threadId), "messages"), {
      role: m.role,
      text: m.text,
      createdAt: serverTimestamp(),
      file: m.file ?? null,
    });

    await updateDoc(doc(db, "chat_threads", String(threadId)), {
      updatedAt: serverTimestamp(),
    });
  }

  function kindFromMime(mime?: string): Msg["file"]["kind"] {
    const m = (mime || "").toLowerCase();
    if (m.startsWith("image/")) return "image";
    if (m.startsWith("video/")) return "video";
    if (m.startsWith("audio/")) return "audio";
    return "file";
  }

  async function uploadToStorage(localUri: string, name: string, mime?: string) {
    if (!uid || !threadId) throw new Error("not authed/thread");

    const res = await fetch(localUri);
    const blob = await res.blob();

    const path = `taxa5/chat/${uid}/${String(threadId)}/${Date.now()}_${name}`;
    const r = ref(storage, path);
    await uploadBytes(r, blob as any, { contentType: mime || "application/octet-stream" });

    const url = await getDownloadURL(r);
    return url;
  }

  async function callBackendAI(userText: string, fileB64?: string, mime?: string, filename?: string) {
    if (!BACKEND_URL) return null;

    const tok = await auth.currentUser?.getIdToken();
    if (!tok) return null;

    const payload: any = {
      thread_id: String(threadId),
      message: userText,
    };

    if (fileB64) {
      payload.file = fileB64;
      payload.mime = mime || "";
      payload.filename = filename || "";
    }

    const resp = await fetch(`${BACKEND_URL}/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${tok}`,
      },
      body: JSON.stringify(payload),
    });

    const json = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      const msg = json?.error || "Falha no backend";
      throw new Error(msg);
    }
    return json;
  }

  // ============
  // Actions
  // ============
  async function sendTextOnly() {
    const t = (text || "").trim();
    if (!t || sending) return;

    setSending(true);
    setText("");

    try {
      await pushMessage({ role: "user", text: t });

      const out = await callBackendAI(t);
      if (out?.reply) {
        await pushMessage({ role: "assistant", text: String(out.reply || "") });
      }
    } catch (e: any) {
      await pushMessage({
        role: "system",
        text: `Erro: ${String(e?.message || e)}`,
      });
    } finally {
      setSending(false);
    }
  }

  async function pickImageOrVideo() {
    if (sending) return;

    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      await pushMessage({ role: "system", text: "Permissão negada para galeria." });
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      quality: 0.85,
      videoQuality: ImagePicker.UIImagePickerControllerQualityType.Medium,
    });

    if (result.canceled) return;

    const asset = result.assets?.[0];
    if (!asset?.uri) return;

    const mime = asset.type === "video" ? "video/mp4" : "image/jpeg";
    const name = asset.type === "video" ? "video.mp4" : "foto.jpg";

    await sendAttachment(asset.uri, name, mime, (asset as any).fileSize);
  }

  async function pickDocument() {
    if (sending) return;

    const result = await DocumentPicker.getDocumentAsync({
      copyToCacheDirectory: true,
      multiple: false,
    });

    if (result.canceled) return;

    const f = result.assets?.[0];
    if (!f?.uri) return;

    await sendAttachment(
      f.uri,
      f.name || "arquivo",
      f.mimeType || "application/octet-stream",
      f.size || 0
    );
  }

  async function sendAttachment(uri: string, name: string, mime?: string, size?: number) {
    setSending(true);

    try {
      // 1) upload Storage
      const url = await uploadToStorage(uri, name, mime);

      await pushMessage({
        role: "user",
        text: text.trim() ? text.trim() : "",
        file: {
          url,
          name,
          mime,
          size,
          kind: kindFromMime(mime),
        },
      });

      // 2) tenta mandar pro backend (somente se <= 2MB)
      let b64: string | undefined;
      const max = 2_000_000;
      const canInline = typeof size === "number" && size > 0 ? size <= max : false;

      if (canInline) {
        // ✅ compatível com versões onde EncodingType não existe
        b64 = await FileSystem.readAsStringAsync(uri, { encoding: "base64" as any });
      }

      const out = await callBackendAI(text.trim() ? text.trim() : "(anexo)", b64, mime, name);
      setText("");

      if (out?.reply) {
        await pushMessage({ role: "assistant", text: String(out.reply || "") });
      }
    } catch (e: any) {
      await pushMessage({
        role: "system",
        text: `Erro anexo: ${String(e?.message || e)}`,
      });
    } finally {
      setSending(false);
    }
  }

  // ============
  // Render
  // ============
  const headerTitle = String(title || "CHAT");

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 8 }]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.back}>
          <Text style={styles.backTxt}>‹</Text>
        </Pressable>

        <View style={{ flex: 1 }}>
          <Text style={[styles.hTitle, cinzel]} numberOfLines={1}>
            {headerTitle}
          </Text>
          <Text style={styles.hSub} numberOfLines={1}>
            {String(threadId || "")}
          </Text>
        </View>
      </View>

      {/* Messages */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          ref={listRef}
          inverted
          data={messages}
          keyExtractor={(i) => i.id}
          contentContainerStyle={{ paddingHorizontal: 12, paddingTop: 10, paddingBottom: 10 }}
          renderItem={({ item }) => <Bubble item={item} />}
        />
      )}

      {/* Composer */}
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[styles.composerWrap, { paddingBottom: insets.bottom + 10 }]}>
          <View style={styles.composer}>
            {/* anexos */}
            <Pressable onPress={pickImageOrVideo} style={styles.iconBtn}>
              <Text style={styles.icon}>＋</Text>
            </Pressable>

            <Pressable onPress={pickDocument} style={styles.iconBtn}>
              <Text style={styles.icon}>📎</Text>
            </Pressable>

            {/* input que cresce */}
            <View style={styles.inputBox}>
              <TextInput
                value={text}
                onChangeText={setText}
                placeholder="Digite sua mensagem…"
                placeholderTextColor="rgba(11,27,43,0.35)"
                selectionColor={UI.colors.blue}
                keyboardAppearance="light"
                multiline
                style={[styles.input, { height: Math.max(inputMin, Math.min(inputH, inputMax)) }]}
                onContentSizeChange={(e) => {
                  const h = e.nativeEvent.contentSize.height;
                  setInputH(h + 16);
                }}
              />
            </View>

            {/* enviar */}
            <Pressable
              onPress={sendTextOnly}
              disabled={sending || !text.trim()}
              style={[styles.sendBtn, (sending || !text.trim()) && { opacity: 0.45 }]}
            >
              {sending ? <ActivityIndicator color="#fff" /> : <Text style={styles.sendTxt}>↥</Text>}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function Bubble({ item }: { item: Msg }) {
  const isUser = item.role === "user";
  const isAi = item.role === "assistant";
  const isSystem = item.role === "system";

  const bg = isUser ? UI.colors.bubbleUser : UI.colors.bubbleAi;
  const textColor = isUser ? "#fff" : UI.colors.text;

  if (isSystem) {
    return (
      <View style={{ paddingVertical: 6 }}>
        <View style={styles.sys}>
          <Text style={styles.sysTxt}>{item.text}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={{ paddingVertical: 6 }}>
      <View
        style={[
          styles.bubble,
          isUser ? styles.bubbleRight : styles.bubbleLeft,
          { backgroundColor: bg },
          !isUser && { borderWidth: 1, borderColor: UI.colors.border },
        ]}
      >
        {!!item.file?.url && (
          <View style={styles.fileRow}>
            <Text style={[styles.fileTag, { color: isUser ? "rgba(255,255,255,0.92)" : UI.colors.muted }]}>
              {item.file.kind?.toUpperCase() || "ARQUIVO"}
            </Text>
            <Text style={[styles.fileName, { color: textColor }]} numberOfLines={1}>
              {item.file.name || "Anexo"}
            </Text>
            <Text style={[styles.fileUrl, { color: isUser ? "rgba(255,255,255,0.82)" : UI.colors.blue }]}>
              {item.file.url}
            </Text>
          </View>
        )}

        {!!item.text && <Text style={[styles.bubbleTxt, { color: textColor }]}>{item.text}</Text>}

        {isAi && !item.text && !item.file?.url ? <Text style={[styles.bubbleTxt, { color: textColor }]}>…</Text> : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: UI.colors.bg },

  header: {
    marginHorizontal: 12,
    borderRadius: UI.radius.xl,
    backgroundColor: "rgba(255,255,255,0.88)",
    borderWidth: 1,
    borderColor: UI.colors.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  back: {
    width: 42,
    height: 42,
    borderRadius: 16,
    backgroundColor: "rgba(31,102,209,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  backTxt: { fontSize: 28, color: UI.colors.blue, marginTop: -2 },

  hTitle: { fontSize: 18, letterSpacing: 2, color: UI.colors.text },
  hSub: { marginTop: 2, fontSize: 11, color: UI.colors.muted },

  center: { flex: 1, alignItems: "center", justifyContent: "center" },

  bubble: {
    maxWidth: "86%",
    borderRadius: 18,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  bubbleLeft: { alignSelf: "flex-start" },
  bubbleRight: { alignSelf: "flex-end" },

  bubbleTxt: { fontSize: 14, fontWeight: "600", lineHeight: 20 },

  sys: {
    alignSelf: "center",
    backgroundColor: "rgba(11,27,43,0.06)",
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.10)",
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 8,
    maxWidth: "92%",
  },
  sysTxt: { color: "rgba(11,27,43,0.70)", fontWeight: "700", fontSize: 12 },

  fileRow: {
    marginBottom: 8,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.18)",
  },
  fileTag: { fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginBottom: 4 },
  fileName: { fontSize: 13, fontWeight: "800" },
  fileUrl: { marginTop: 4, fontSize: 11, fontWeight: "700" },

  composerWrap: {
    paddingHorizontal: 12,
    paddingTop: 10,
  },

  composer: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 10,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: UI.colors.border,
    borderRadius: UI.radius.xl,
    padding: 10,
  },

  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 16,
    backgroundColor: "rgba(31,102,209,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  icon: { fontSize: 18 },

  inputBox: { flex: 1 },
  input: {
    minHeight: 50,
    maxHeight: 50 + 9 * 20,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: UI.colors.surface,
    borderWidth: 1,
    borderColor: UI.colors.border,
    color: UI.colors.text,
    fontSize: 14,
    fontWeight: "700",
  },

  sendBtn: {
    width: 46,
    height: 46,
    borderRadius: 18,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },
  sendTxt: { color: "#fff", fontSize: 18, fontWeight: "900", marginTop: -2 },
});