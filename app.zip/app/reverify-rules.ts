import AsyncStorage from "@react-native-async-storage/async-storage";

const RIDES = "@taxa5:ridesCount";
const LAST = "@taxa5:lastReverifyRide";
const GAP = "@taxa5:nextReverifyGap";

function randInt(min: number, max: number) {
  // inclusivo
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export async function getRidesCount() {
  return Number((await AsyncStorage.getItem(RIDES)) ?? "0");
}

export async function incrementRideCount() {
  const n = (await getRidesCount()) + 1;
  await AsyncStorage.setItem(RIDES, String(n));
  return n;
}

export async function ensureReverifyConfig() {
  const last = Number((await AsyncStorage.getItem(LAST)) ?? "0");
  let gap = Number((await AsyncStorage.getItem(GAP)) ?? "0");
  if (!gap) {
    gap = randInt(50, 100);
    await AsyncStorage.setItem(GAP, String(gap));
  }
  return { last, gap };
}

export async function needsPassengerReverify() {
  const rides = await getRidesCount();
  const { last, gap } = await ensureReverifyConfig();
  return rides - last >= gap;
}

export async function markPassengerReverifyDone() {
  const rides = await getRidesCount();
  await AsyncStorage.setItem(LAST, String(rides));

  // sorteia novo intervalo 50–100 para não decorar
  const gap = randInt(50, 100);
  await AsyncStorage.setItem(GAP, String(gap));
}
