import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Alert,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

const CONSENT_KEY = "@taxa5:consentAccepted";

export default function PrivacyConsent() {
  const [c1, setC1] = useState(false);
  const [c2, setC2] = useState(false);
  const [c3, setC3] = useState(false);
  const [loading, setLoading] = useState(false);

  const podeAceitar = useMemo(() => c1 && c2 && c3 && !loading, [c1, c2, c3, loading]);

  async function aceitar() {
    try {
      setLoading(true);
      await AsyncStorage.setItem(CONSENT_KEY, "1");
      Alert.alert("Ok", "Consentimento registrado.");
      router.back();
    } catch (e: any) {
      Alert.alert("Erro", String(e?.message ?? e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={s.container}>
      <Text style={s.title}>Termos Sentinel • Consentimento</Text>

      <ScrollView style={s.box} contentContainerStyle={{ padding: 14 }}>
        <Text style={s.h}>TERMOS DE SEGURANÇA E PROTEÇÃO DE DADOS</Text>
        <Text style={s.p}>
          Para garantir a segurança dos usuários, o Taxa 5 utiliza o Security Sentinel Protocol
          (protocolo de verificação e antifraude).
        </Text>

        <Text style={s.h}>1) Identidade e prova de vida</Text>
        <Text style={s.p}>
          Durante o cadastro, poderão ser solicitados documentos e verificação facial com prova de vida
          (selfie com movimento).
        </Text>

        <Text style={s.h}>2) Armazenamento seguro</Text>
        <Text style={s.p}>
          As evidências (documentos e selfie) serão armazenadas de forma criptografada na nuvem do Sentinel.
          O Taxa 5 não acessa diretamente essas evidências.
        </Text>

        <Text style={s.h}>3) Acesso às evidências</Text>
        <Text style={s.p}>
          O acesso só poderá ocorrer: (a) por solicitação do titular; (b) por ordem judicial/requisição legal válida;
          (c) por investigação formal de fraude, com autorização dupla auditada no Sentinel.
        </Text>

        <Text style={s.h}>4) Finalidade e proteção</Text>
        <Text style={s.p}>
          Essas medidas protegem usuários e motoristas, e permitem investigação por autoridades em caso de crimes,
          preservando cadeia de custódia e auditoria.
        </Text>

        <Text style={s.small}>
          (Stub agora) A infraestrutura completa de criptografia, auditoria e desbloqueio por dupla autorização
          será implementada pelo Sentinel como serviço separado.
        </Text>
      </ScrollView>

      <View style={s.checks}>
        <Check
          checked={c1}
          onToggle={() => setC1((v) => !v)}
          label="Eu li e entendi os termos de segurança."
        />
        <Check
          checked={c2}
          onToggle={() => setC2((v) => !v)}
          label="Autorizo a verificação de identidade e prova de vida no cadastro."
        />
        <Check
          checked={c3}
          onToggle={() => setC3((v) => !v)}
          label="Concordo com armazenamento criptografado e regras de acesso legal/auditado."
        />
      </View>

      <Pressable
        disabled={!podeAceitar}
        onPress={aceitar}
        style={[s.btn, !podeAceitar && { opacity: 0.55 }]}
      >
        <Text style={s.btnText}>{loading ? "Salvando..." : "Aceito"}</Text>
      </Pressable>

      <Pressable onPress={() => router.back()} style={s.link}>
        <Text style={s.linkText}>Voltar</Text>
      </Pressable>
    </View>
  );
}

function Check({
  checked,
  onToggle,
  label,
}: {
  checked: boolean;
  onToggle: () => void;
  label: string;
}) {
  return (
    <Pressable onPress={onToggle} style={s.checkRow}>
      <View style={[s.boxCheck, checked && s.boxCheckOn]}>
        <Text style={s.boxCheckTxt}>{checked ? "✓" : ""}</Text>
      </View>
      <Text style={s.checkLabel}>{label}</Text>
    </Pressable>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 16, paddingTop: 44 },
  title: { fontSize: 18, fontWeight: "900", color: "#0B2D5C", marginBottom: 10 },
  box: { flex: 1, borderRadius: 14, borderWidth: 1, borderColor: "rgba(15,102,214,0.18)", backgroundColor: "rgba(15,102,214,0.05)" },
  h: { fontSize: 13, fontWeight: "900", color: "#0B2D5C", marginTop: 10, marginBottom: 6 },
  p: { fontSize: 13, color: "#122", opacity: 0.9, lineHeight: 18 },
  small: { marginTop: 12, fontSize: 11, color: "#122", opacity: 0.6, fontWeight: "600" },
  checks: { marginTop: 12, gap: 10 },
  checkRow: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  boxCheck: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: "#0F66D6", alignItems: "center", justifyContent: "center", marginTop: 1 },
  boxCheckOn: { backgroundColor: "#0F66D6" },
  boxCheckTxt: { color: "#fff", fontWeight: "900" },
  checkLabel: { flex: 1, fontSize: 12.5, color: "#122", opacity: 0.88, fontWeight: "700" },
  btn: { marginTop: 14, backgroundColor: "#0F66D6", paddingVertical: 14, borderRadius: 14, alignItems: "center" },
  btnText: { color: "#fff", fontWeight: "900", fontSize: 16 },
  link: { marginTop: 10, alignItems: "center" },
  linkText: { color: "#0F66D6", fontWeight: "900" },
});
