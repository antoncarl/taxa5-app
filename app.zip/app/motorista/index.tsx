import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useSession } from "../lib/session";

export default function MotoristaHome() {
  const router = useRouter();
  const { ride, driverAcceptRide } = useSession();

  const [online, setOnline] = useState(true);

  const canSeeRide = useMemo(() => {
    return online && ride.status === "waiting_driver" && ride.pickup && ride.destination;
  }, [online, ride.status, ride.pickup, ride.destination]);

  const accept = () => {
    if (!ride.pickup) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    driverAcceptRide({
      id: "drv_01",
      name: "Motorista Taxa",
      car: "Taxa 5 • Azul",
      pos: {
        latitude: ride.pickup.latitude + 0.006,
        longitude: ride.pickup.longitude - 0.004,
      },
    });

    router.push("/motorista/DriverMap");
  };

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={10}>
          <Text style={styles.backTxt}>←</Text>
        </Pressable>
        <Text style={styles.title}>Perfil motorista</Text>
        <View style={{ width: 42 }} />
      </View>

      <View style={styles.card}>
        <Text style={styles.h}>Status</Text>
        <Pressable
          onPress={() => {
            Haptics.selectionAsync();
            setOnline((v) => !v);
          }}
          style={[styles.toggle, online ? styles.on : styles.off]}
        >
          <Text style={styles.toggleTxt}>{online ? "ONLINE" : "OFFLINE"}</Text>
        </Pressable>

        <Text style={styles.sub}>
          Quando ONLINE, você recebe solicitações.
        </Text>
      </View>

      {canSeeRide ? (
        <View style={[styles.card, { marginTop: 14 }]}>
          <Text style={styles.h}>Corrida disponível</Text>
          <Text style={styles.line}><Text style={styles.k}>Embarque:</Text> {ride.pickupText}</Text>
          <Text style={styles.line}><Text style={styles.k}>Destino:</Text> {ride.destinationText}</Text>
          <Text style={styles.line}><Text style={styles.k}>Categoria:</Text> {ride.category?.name ?? "-"}</Text>

          <Pressable onPress={accept} style={styles.accept}>
            <Text style={styles.acceptTxt}>ACEITAR (Tesla)</Text>
          </Pressable>
        </View>
      ) : (
        <Text style={styles.empty}>
          Nenhuma corrida pendente agora. Faça um pedido no perfil Passageiro para testar.
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#EEF6FF" },

  header: {
    paddingTop: 44,
    paddingHorizontal: 16,
    paddingBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  backBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.92)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },
  backTxt: { fontSize: 18, fontWeight: "900", color: "#0B4FA3" },
  title: { fontSize: 18, fontWeight: "900", color: "#1F2A37" },

  card: {
    marginHorizontal: 16,
    borderRadius: 24,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
    padding: 14,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 10 },
    elevation: 4,
  },

  h: { fontSize: 14, fontWeight: "900", color: "#3C5B78", letterSpacing: 2 },
  sub: { marginTop: 10, fontWeight: "700", color: "#5F7388" },

  toggle: {
    marginTop: 10,
    height: 52,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  on: { backgroundColor: "rgba(11,79,163,0.12)", borderColor: "rgba(11,79,163,0.22)" },
  off: { backgroundColor: "rgba(0,0,0,0.10)", borderColor: "rgba(0,0,0,0.14)" },
  toggleTxt: { fontWeight: "900", color: "#1F2A37" },

  line: { marginTop: 8, fontWeight: "800", color: "#1F2A37" },
  k: { color: "#5F7388" },

  accept: {
    marginTop: 14,
    height: 56,
    borderRadius: 22,
    backgroundColor: "#0B4FA3",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0B4FA3",
    shadowOpacity: 0.22,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 12 },
    elevation: 8,
  },
  acceptTxt: { color: "#FFF", fontWeight: "900", fontSize: 16 },

  empty: { marginTop: 18, marginHorizontal: 16, fontWeight: "700", color: "#5F7388" },
});