import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.62)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    green: "#16A34A",
  },
  radius: { lg: 18, xl: 22 },
};

export default function TermosMotorista101() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [accepted, setAccepted] = useState(false);

  // (Por enquanto LIBERADO, mas já deixei a estrutura pronta pra bloquear depois)
  const [canAccept, setCanAccept] = useState(true);

  const scrollRef = useRef<ScrollView>(null);

  const [fontsLoaded] = useFonts({ Cinzel_700Bold });
  const titleStyle = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" as const } : undefined),
    [fontsLoaded]
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, titleStyle]}>Termos do Motorista</Text>

      <View style={styles.card}>
        <Text style={styles.subtitle}>
          Leia com atenção. Este termo registra o consentimento e o uso do
          protocolo de segurança.
        </Text>

        <View style={styles.hr} />

        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={{ paddingBottom: 14 }}
          showsVerticalScrollIndicator={true}
          onScroll={(e) => {
            // 🔒 Depois a gente ativa o bloqueio real (por enquanto fica livre)
            // const { layoutMeasurement, contentOffset, contentSize } = e.nativeEvent;
            // const bottom = layoutMeasurement.height + contentOffset.y >= contentSize.height - 24;
            // if (bottom) setCanAccept(true);
          }}
          scrollEventThrottle={16}
        >
          <Text style={styles.h2}>1. Identificação e finalidade</Text>
          <Text style={styles.p}>
            Ao se cadastrar como MOTORISTA, você concorda em fornecer dados e
            documentos para validação de identidade e segurança operacional.
          </Text>

          <Text style={styles.h2}>2. Verificação de identidade</Text>
          <Text style={styles.p}>
            Você autoriza a captura e o envio de imagens/documentos (ex.: CNH,
            documento do veículo, certidões) e selfie com prova de vida (ex.:
            piscar, mover cabeça), para validação antifraude.
          </Text>

          <Text style={styles.h2}>3. Sentinel Protocol (cadeia de custódia)</Text>
          <Text style={styles.p}>
            Você concorda que os dados de verificação e evidências de auditoria
            poderão ser armazenados em nuvem com criptografia e registro de
            auditoria (“cadeia de custódia”) para suporte a investigações e
            solicitações legais.
          </Text>

          <Text style={styles.h2}>4. Uso em casos legais</Text>
          <Text style={styles.p}>
            Em caso de incidentes (ex.: crimes, fraudes, segurança), essas
            evidências podem ser utilizadas como prova e disponibilizadas mediante
            ordem judicial e regras legais aplicáveis.
          </Text>

          <Text style={styles.h2}>5. Responsabilidades</Text>
          <Text style={styles.p}>
            Você declara que os documentos enviados são verdadeiros e atuais. O
            envio de informação falsa pode resultar em bloqueio e encaminhamento
            para verificação humana, quando necessário.
          </Text>

          <Text style={styles.h2}>6. Consentimento</Text>
          <Text style={styles.p}>
            Ao aceitar, você registra seu consentimento para o tratamento e o
            armazenamento descritos acima.
          </Text>

          <Text style={styles.note}>
            (Depois vamos colocar o texto jurídico final completo, com CNPJ,
            controlador/operador, prazos e detalhes.)
          </Text>
        </ScrollView>

        <View style={styles.hr} />

        <Pressable
          onPress={() => setAccepted((v) => !v)}
          style={({ pressed }) => [
            styles.checkboxRow,
            pressed && { opacity: 0.96 },
          ]}
        >
          <View style={[styles.checkbox, accepted && styles.checkboxOn]}>
            {accepted ? <Text style={styles.check}>✓</Text> : null}
          </View>
          <Text style={styles.checkboxText}>
            Eu li e aceito os termos do motorista.
          </Text>
        </Pressable>

        <Pressable
          // ✅ Por enquanto NÃO bloqueia (você pediu)
          disabled={!accepted || !canAccept}
          onPress={() => router.push("/motorista/102")}
          style={({ pressed }) => [
            styles.btn,
            (pressed && accepted) ? { transform: [{ scale: 0.995 }] } : null,
            (!accepted || !canAccept) && { opacity: 0.45 },
          ]}
        >
          <Text style={styles.btnText}>Aceitar e continuar</Text>
        </Pressable>

        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>Voltar</Text>
        </Pressable>
      </View>

      <View style={{ height: insets.bottom + 12 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    color: UI.colors.text,
    marginBottom: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
  },

  subtitle: {
    color: UI.colors.muted,
    fontWeight: "700",
    lineHeight: 20,
  },

  hr: {
    height: 1,
    backgroundColor: "rgba(11,27,43,0.08)",
    marginVertical: 12,
  },

  scroll: {
    maxHeight: 360,
    backgroundColor: "rgba(234,243,255,0.55)",
    borderRadius: UI.radius.lg,
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.08)",
    padding: 12,
  },

  h2: {
    color: UI.colors.text,
    fontWeight: "900",
    marginTop: 10,
    marginBottom: 6,
  },

  p: {
    color: UI.colors.text,
    fontWeight: "600",
    lineHeight: 20,
  },

  note: {
    marginTop: 12,
    color: UI.colors.muted,
    fontWeight: "700",
    fontStyle: "italic",
  },

  checkboxRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 4,
    marginBottom: 12,
  },

  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.25)",
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },

  checkboxOn: {
    backgroundColor: UI.colors.green,
    borderColor: "rgba(0,0,0,0)",
  },

  check: {
    color: "#FFFFFF",
    fontWeight: "900",
  },

  checkboxText: {
    flex: 1,
    color: UI.colors.text,
    fontWeight: "700",
  },

  btn: {
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },

  btnText: {
    color: UI.colors.white,
    fontSize: 16,
    fontWeight: "900",
  },

  backBtn: {
    marginTop: 10,
    height: 46,
    borderRadius: UI.radius.lg,
    borderWidth: 1,
    borderColor: UI.colors.border,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },

  backText: {
    color: UI.colors.blue,
    fontWeight: "900",
  },
});