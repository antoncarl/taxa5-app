import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Image,
    Pressable,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    green: "#16A34A",
  },
  radius: { lg: 18, xl: 22 },
};

export default function MotoristaDocs102() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [cnh, setCnh] = useState<string | null>(null);
  const [veiculo, setVeiculo] = useState<string | null>(null);
  const [antecedentes, setAntecedentes] = useState<string | null>(null);
  const [carro, setCarro] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);
  const [perfil, setPerfil] = useState<string | null>(null);

  const [fontsLoaded] = useFonts({ Cinzel_700Bold });
  const titleStyle = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : undefined),
    [fontsLoaded]
  );

  async function pickImage(setter: (uri: string) => void) {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (!res.canceled) {
      setter(res.assets[0].uri);
    }
  }

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, titleStyle]}>Documentos</Text>

      <View style={styles.card}>
        <Item title="CNH" value={cnh} onPress={() => pickImage(setCnh)} />
        <Item title="Documento do veículo" value={veiculo} onPress={() => pickImage(setVeiculo)} />
        <Item title="Antecedentes criminais" value={antecedentes} onPress={() => pickImage(setAntecedentes)} />
        <Item title="Foto do carro (com placa)" value={carro} onPress={() => pickImage(setCarro)} />
        <Item title="Selfie com reconhecimento" value={selfie} onPress={() => pickImage(setSelfie)} />
        <Item title="Foto de perfil" value={perfil} onPress={() => pickImage(setPerfil)} />
      </View>

      {/* BOTÃO AVANÇAR (LIBERADO) */}
      <Pressable
        onPress={() => router.replace("/passageiro/home")}
        style={styles.btn}
      >
        <Text style={styles.btnText}>Finalizar cadastro</Text>
      </Pressable>
    </View>
  );
}

function Item({
  title,
  value,
  onPress,
}: {
  title: string;
  value: string | null;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={styles.item}>
      <Text style={styles.itemTitle}>{title}</Text>

      {value ? (
        <Image source={{ uri: value }} style={styles.preview} />
      ) : (
        <Text style={styles.placeholder}>Selecionar / Tirar foto</Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    color: UI.colors.text,
    marginBottom: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
  },

  item: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(11,27,43,0.08)",
  },

  itemTitle: {
    fontWeight: "800",
    color: UI.colors.text,
    marginBottom: 6,
  },

  placeholder: {
    color: UI.colors.muted,
    fontWeight: "600",
  },

  preview: {
    width: "100%",
    height: 120,
    borderRadius: 12,
  },

  btn: {
    marginTop: 20,
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },

  btnText: {
    color: UI.colors.white,
    fontSize: 16,
    fontWeight: "900",
  },
});