import { router } from "expo-router";
import React from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import PremiumButton from "./components/PremiumButton";

export default function Manual() {
  return (
    <ScrollView contentContainerStyle={s.container}>
      <View style={s.card}>
        <Text style={s.title}>MANUAL • MELHORAR SUA NOTA</Text>

        <Text style={s.p}>• Seja educado e respeitoso.</Text>
        <Text style={s.p}>• Confirme embarque/destino com clareza.</Text>
        <Text style={s.p}>• Evite cancelamentos sem motivo.</Text>
        <Text style={s.p}>• Motorista: dirija com segurança e respeito total.</Text>
        <Text style={s.p}>• Chegue no ponto e comunique atrasos.</Text>
        <Text style={s.p}>• Carro limpo e comportamento profissional.</Text>

        <View style={{ height: 12 }} />

        <PremiumButton title="VOLTAR" onPress={() => router.back()} />
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#fff",
    padding: 14,
    justifyContent: "center",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },
  title: {
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 0.5,
    textAlign: "center",
    marginBottom: 12,
  },
  p: {
    fontSize: 15,
    lineHeight: 21,
    marginBottom: 8,
  },
});
