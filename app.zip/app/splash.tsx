import { Audio } from "expo-av";
import { useRouter } from "expo-router";
import { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";

export default function Splash() {
  const router = useRouter();

  const scale = useSharedValue(1);
  const glow = useSharedValue(0.35);

  useEffect(() => {
    // Pulsação premium
    scale.value = withRepeat(
      withTiming(1.05, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
      -1,
      true
    );

    // Brilho suave
    glow.value = withRepeat(
      withTiming(0.85, { duration: 1200, easing: Easing.inOut(Easing.quad) }),
      -1,
      true
    );

    let sound: Audio.Sound | null = null;

    (async () => {
      try {
        const { sound: s } = await Audio.Sound.createAsync(
          require("../assets/tec.mp3"),
          { volume: 0.22, shouldPlay: true }
        );
        sound = s;
      } catch (e) {
        console.log("Som TEC não carregou:", e);
      }
    })();

    const timer = setTimeout(async () => {
      try {
        if (sound) {
          await sound.stopAsync();
          await sound.unloadAsync();
        }
      } catch {}

      router.replace("/cadastro");
    }, 3000);

    return () => {
      clearTimeout(timer);
      (async () => {
        try {
          if (sound) {
            await sound.unloadAsync();
          }
        } catch {}
      })();
    };
  }, []);

  const logoStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glow.value,
    transform: [{ scale: scale.value * 1.08 }],
  }));

  return (
    <View style={styles.container}>
      <Animated.Image
        source={require("../assets/logo.png")}
        style={[styles.glow, glowStyle]}
        resizeMode="contain"
      />

      <Animated.Image
        source={require("../assets/logo.png")}
        style={[styles.logo, logoStyle]}
        resizeMode="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#020617",
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    width: 240,
    height: 240,
  },
  glow: {
    position: "absolute",
    width: 280,
    height: 280,
    opacity: 0.4,
  },
});