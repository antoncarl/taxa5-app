import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Pressable,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

type Params = { pickup?: string; dest?: string };

type Category = {
  key: string;
  title: string;
  subtitle?: string;
  price: string;
  rightIcon?: "photo" | "arrow";
  selectable?: boolean;
  stepper?: boolean;
};

export default function Corrida() {
  const router = useRouter();
  const p = useLocalSearchParams<Params>();

  const pickup = (p.pickup ?? "").toString();
  const dest = (p.dest ?? "").toString();

  const [selected, setSelected] = useState<string | null>(null);
  const [nego, setNego] = useState(36.2);
  const [payment, setPayment] = useState<"Dinheiro" | "Pix" | "Cartão">("Dinheiro");

  const categories: Category[] = useMemo(
    () => [
      { key: "pop", title: "Pop", subtitle: "• 4  5 min", price: "R$41,60", rightIcon: "photo" },
      { key: "popx", title: "Pop Expresso", subtitle: "• 4  3 min", price: "R$47,83", rightIcon: "photo" },
      { key: "nego", title: "Negocia", subtitle: "Negocie e escolha", price: `R$${nego.toFixed(2).replace(".", ",")}`, stepper: true },
      { key: "taxi", title: "Táxi", subtitle: "aprox. 6 min", price: "R$95,75" },
      { key: "moto", title: "Entrega Moto", subtitle: "7 min", price: "R$15,60", rightIcon: "arrow" },
      { key: "carro", title: "Entrega Carro", subtitle: "5 min", price: "R$48,50", rightIcon: "arrow" },
      { key: "util", title: "Entrega Utilitário", subtitle: "1.8×1.3×1.1m • 500kg", price: "R$60,80" },
    ],
    [nego]
  );

  const canRequest = !!selected;

  return (
    <SafeAreaView style={styles.safe}>
      {/* topo mapa (placeholder) */}
      <View style={styles.mapArea}>
        <Pressable onPress={() => router.back()} style={styles.back} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#0B4FA3" />
        </Pressable>

        <View style={styles.bubbleLeft}>
          <Text style={styles.bubbleText} numberOfLines={1}>
            {pickup || "Embarque"}
          </Text>
          <Ionicons name="chevron-forward" size={16} color="#0F172A" />
        </View>

        <View style={styles.bubbleRight}>
          <Text style={styles.bubbleText} numberOfLines={1}>
            {dest || "Destino"}
          </Text>
          <Ionicons name="chevron-forward" size={16} color="#0F172A" />
        </View>

        {/* aqui depois a gente troca por PassengerMap + rota azul estilo Tesla */}
      </View>

      {/* bottom sheet categorias */}
      <View style={styles.sheet}>
        <ScrollView contentContainerStyle={{ paddingBottom: 110 }}>
          {categories.map((c) => {
            const isSel = selected === c.key;

            return (
              <Pressable
                key={c.key}
                onPress={() => setSelected(c.key)}
                style={[styles.row, isSel && styles.rowSel]}
              >
                <View style={styles.carIcon}>
                  <Ionicons name="car-sport-outline" size={18} color="#0B4FA3" />
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.rowTitle}>{c.title} <Text style={styles.people}>{c.subtitle ? ` ${c.subtitle}` : ""}</Text></Text>
                  {!!c.subtitle && c.key !== "pop" && c.key !== "popx" ? (
                    <Text style={styles.rowSub}>{c.subtitle}</Text>
                  ) : null}
                </View>

                {c.stepper ? (
                  <View style={styles.stepper}>
                    <Pressable
                      onPress={() => setNego((v) => Math.max(5, +(v - 1).toFixed(2)))}
                      style={styles.stepBtn}
                      hitSlop={10}
                    >
                      <Ionicons name="remove" size={18} color="#0F172A" />
                    </Pressable>
                    <Text style={styles.stepValue}>{c.price.replace("R$", "").trim()}</Text>
                    <Pressable
                      onPress={() => setNego((v) => +(v + 1).toFixed(2))}
                      style={styles.stepBtn}
                      hitSlop={10}
                    >
                      <Ionicons name="add" size={18} color="#0F172A" />
                    </Pressable>
                  </View>
                ) : (
                  <Text style={styles.price}>{c.price}</Text>
                )}

                <View style={styles.right}>
                  {c.rightIcon === "photo" ? (
                    <Ionicons name="images-outline" size={18} color="#9CA3AF" />
                  ) : c.rightIcon === "arrow" ? (
                    <Ionicons name="arrow-forward" size={18} color="#9CA3AF" />
                  ) : null}
                </View>

                <View style={[styles.radio, isSel && styles.radioOn]}>
                  {isSel ? <View style={styles.radioDot} /> : null}
                </View>
              </Pressable>
            );
          })}

          <Pressable
            onPress={() => router.push({ pathname: "/passageiro/pagamento", params: { selected: payment } })}
            style={styles.payRow}
          >
            <View style={styles.payIcon}>
              <Ionicons name="cash-outline" size={18} color="#0B4FA3" />
            </View>

            <Text style={styles.payTitle}>Pagamento</Text>

            <View style={{ flex: 1 }} />
            <Text style={styles.payValue}>{payment}</Text>
            <Ionicons name="chevron-forward" size={18} color="#9CA3AF" />
          </Pressable>
        </ScrollView>
      </View>

      <View style={styles.footer}>
        <Pressable
          onPress={() => {}}
          disabled={!canRequest}
          style={[styles.request, !canRequest && styles.requestDisabled]}
        >
          <Text style={[styles.requestText, !canRequest && styles.requestTextDisabled]}>
            Solicitar
          </Text>
          {!canRequest && <Text style={styles.requestHint}>Selecione 1 categoria</Text>}
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const ICE = "#F4F8FF";
const BORDER = "rgba(15, 23, 42, 0.08)";

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: ICE },

  mapArea: {
    height: 280,
    backgroundColor: "#EAF2FF",
    position: "relative",
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    overflow: "hidden",
  },
  back: {
    position: "absolute",
    left: 14,
    top: 14,
    width: 44,
    height: 44,
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: BORDER,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 10,
  },

  bubbleLeft: {
    position: "absolute",
    left: 14,
    top: 70,
    maxWidth: "72%",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: BORDER,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  bubbleRight: {
    position: "absolute",
    right: 14,
    top: 120,
    maxWidth: "72%",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: BORDER,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  bubbleText: { fontSize: 13, fontWeight: "900", color: "#0F172A" },

  sheet: {
    flex: 1,
    marginTop: -24,
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.06)",
    paddingTop: 10,
  },

  row: {
    marginHorizontal: 14,
    marginTop: 10,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.07)",
    backgroundColor: "#FFFFFF",
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  rowSel: { borderColor: "rgba(11,79,163,0.25)", backgroundColor: "#F8FBFF" },

  carIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: "#F1F6FF",
    borderWidth: 1,
    borderColor: "rgba(11,79,163,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },

  rowTitle: { fontSize: 16, fontWeight: "900", color: "#0F172A" },
  people: { fontSize: 12, fontWeight: "800", color: "#64748B" },
  rowSub: { marginTop: 2, fontSize: 12, fontWeight: "700", color: "#64748B" },

  price: { fontSize: 18, fontWeight: "900", color: "#0F172A" },

  right: { width: 26, alignItems: "center", justifyContent: "center" },

  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: "rgba(15,23,42,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  radioOn: { borderColor: "#0B4FA3" },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#0B4FA3" },

  stepper: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: "#F8FBFF",
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.06)",
  },
  stepBtn: {
    width: 30,
    height: 30,
    borderRadius: 10,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.08)",
    alignItems: "center",
    justifyContent: "center",
  },
  stepValue: { minWidth: 62, textAlign: "center", fontSize: 16, fontWeight: "900", color: "#0F172A" },

  payRow: {
    marginHorizontal: 14,
    marginTop: 14,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.07)",
    backgroundColor: "#FFFFFF",
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  payIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: "#F1F6FF",
    borderWidth: 1,
    borderColor: "rgba(11,79,163,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  payTitle: { fontSize: 14, fontWeight: "900", color: "#0F172A" },
  payValue: { fontSize: 14, fontWeight: "900", color: "#0F172A" },

  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    padding: 14,
    backgroundColor: "rgba(255,255,255,0.96)",
    borderTopWidth: 1,
    borderTopColor: "rgba(15,23,42,0.06)",
  },
  request: {
    height: 56,
    borderRadius: 18,
    backgroundColor: "#0B4FA3",
    alignItems: "center",
    justifyContent: "center",
  },
  requestDisabled: { backgroundColor: "rgba(11,79,163,0.25)" },
  requestText: { fontSize: 16, fontWeight: "900", color: "#FFFFFF" },
  requestTextDisabled: { color: "rgba(255,255,255,0.85)" },
  requestHint: { marginTop: 2, fontSize: 12, fontWeight: "800", color: "rgba(255,255,255,0.85)" },
});