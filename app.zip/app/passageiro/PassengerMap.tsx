import * as Location from "expo-location";
import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from "react";
import { Platform, StyleSheet, View } from "react-native";
import MapView, { PROVIDER_GOOGLE } from "react-native-maps";
import { TESLA_DAY_STYLE } from "./mapStyles";

export type FocusMode = "idle" | "search";

export type PassengerMapHandle = {
  setFocusMode: (mode: FocusMode) => void;
};

const FALLBACK = {
  latitude: -23.55052,
  longitude: -46.633308,
};

const PassengerMap = forwardRef<PassengerMapHandle>((_, ref) => {
  const mapRef = useRef<MapView>(null);
  const centerRef = useRef(FALLBACK);
  const watchRef = useRef<Location.LocationSubscription | null>(null);
  const lastCameraTsRef = useRef(0);
  const focusModeRef = useRef<FocusMode>("idle");

  const idlePitch = Platform.OS === "android" ? 68 : 64;
  const idleHeading = Platform.OS === "android" ? 18 : 12;
  const idleAltitude = 700;
  const searchAltitude = 1100;

  const animateTo = (mode: FocusMode, duration = 700) => {
    const cfg =
      mode === "search"
        ? {
            pitch: 42,
            altitude: searchAltitude,
            heading: 0,
          }
        : {
            pitch: idlePitch,
            altitude: idleAltitude,
            heading: idleHeading,
          };

    mapRef.current?.animateCamera(
      {
        center: centerRef.current,
        pitch: cfg.pitch,
        altitude: cfg.altitude,
        heading: cfg.heading,
      },
      { duration }
    );
  };

  useImperativeHandle(ref, () => ({
    setFocusMode: (mode) => {
      focusModeRef.current = mode;
      animateTo(mode, 500);
    },
  }));

  useEffect(() => {
    let mounted = true;

    const start = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();

        if (!mounted) return;

        mapRef.current?.animateCamera(
          {
            center: FALLBACK,
            pitch: idlePitch,
            altitude: idleAltitude,
            heading: idleHeading,
          },
          { duration: 600 }
        );

        if (status !== "granted") return;

        const current = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        if (!mounted) return;

        centerRef.current = {
          latitude: current.coords.latitude,
          longitude: current.coords.longitude,
        };

        animateTo("idle", 900);

        watchRef.current = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            timeInterval: 1600,
            distanceInterval: 8,
          },
          (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;

            if (!lat || !lng) return;

            const prev = centerRef.current;

            const next = {
              latitude: prev.latitude + (lat - prev.latitude) * 0.35,
              longitude: prev.longitude + (lng - prev.longitude) * 0.35,
            };

            centerRef.current = next;

            if (focusModeRef.current !== "idle") return;

            const now = Date.now();
            if (now - lastCameraTsRef.current < 1100) return;
            lastCameraTsRef.current = now;

            mapRef.current?.animateCamera(
              {
                center: next,
                pitch: idlePitch,
                altitude: idleAltitude,
                heading: idleHeading,
              },
              { duration: 650 }
            );
          }
        );
      } catch {}
    };

    start();

    return () => {
      mounted = false;
      watchRef.current?.remove();
    };
  }, []);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={StyleSheet.absoluteFillObject}
        initialRegion={{
          latitude: FALLBACK.latitude,
          longitude: FALLBACK.longitude,
          latitudeDelta: 0.012,
          longitudeDelta: 0.012,
        }}
        customMapStyle={TESLA_DAY_STYLE}
        mapType="standard"
        pitchEnabled
        rotateEnabled
        showsBuildings
        showsIndoors={false}
        showsUserLocation
        showsMyLocationButton={false}
        showsCompass={false}
        showsScale={false}
        toolbarEnabled={false}
        zoomControlEnabled={false}
        moveOnMarkerPress={false}
        loadingEnabled
        renderToHardwareTextureAndroid={true}
        cacheEnabled={false}
      />
    </View>
  );
});

export default PassengerMap;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});