import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Keyboard,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Place as RidePlace, useRideStore } from "../../src/store/rideStore";

type Suggestion = {
  placeId: string;
  primary: string;
  secondary?: string;
};

// ✅ garante string (evita erro TS "string | undefined")
const GOOGLE_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAPS_KEY ?? "";

// Identidade visual (branco gelo + azul premium)
const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
  },
  radius: { lg: 18, xl: 22, pill: 999 },
  shadow: {
    soft: Platform.select({
      ios: {
        shadowColor: "#0B1B2B",
        shadowOpacity: 0.10,
        shadowRadius: 18,
        shadowOffset: { width: 0, height: 10 },
      },
      android: { elevation: 3 },
      default: {},
    }) as any,
  },
};

function pickPrimarySecondary(description: string): { primary: string; secondary?: string } {
  const parts = description
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (parts.length <= 1) return { primary: description };
  return { primary: parts[0], secondary: parts.slice(1).join(", ") };
}

async function fetchPlacesAutocomplete(q: string): Promise<Suggestion[]> {
  if (!GOOGLE_KEY) return [];

  const url =
    "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
    `?input=${encodeURIComponent(q)}` +
    `&key=${encodeURIComponent(GOOGLE_KEY)}` +
    `&language=pt-BR` +
    `&components=country:br`;

  const res = await fetch(url);
  const json = await res.json();

  const preds: any[] = json?.predictions ?? [];
  return preds.slice(0, 10).map((p) => {
    const desc = String(p.description ?? "");
    const { primary, secondary } = pickPrimarySecondary(desc);
    return {
      placeId: String(p.place_id),
      primary,
      secondary,
    };
  });
}

async function fetchPlaceDetails(placeId: string): Promise<RidePlace | null> {
  if (!GOOGLE_KEY) return null;

  const url =
    "https://maps.googleapis.com/maps/api/place/details/json" +
    `?place_id=${encodeURIComponent(placeId)}` +
    `&key=${encodeURIComponent(GOOGLE_KEY)}` +
    `&language=pt-BR` +
    `&fields=formatted_address,geometry`;

  const res = await fetch(url);
  const json = await res.json();

  const r = json?.result;
  const description = String(r?.formatted_address ?? "");
  const lat = Number(r?.geometry?.location?.lat ?? 0);
  const lng = Number(r?.geometry?.location?.lng ?? 0);

  if (!description || !lat || !lng) return null;

  return { description, lat, lng };
}

export default function Local() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const origin = useRideStore((s) => s.origin);
  const destination = useRideStore((s) => s.destination);
  const setOrigin = useRideStore((s) => s.setOrigin);
  const setDestination = useRideStore((s) => s.setDestination);

  const [activeField, setActiveField] = useState<"origin" | "destination">("origin");

  const [originText, setOriginText] = useState(origin?.description ?? "");
  const [destText, setDestText] = useState(destination?.description ?? "");

  const [query, setQuery] = useState("");
  const [loadingSug, setLoadingSug] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);

  const originRef = useRef<TextInput>(null);
  const destRef = useRef<TextInput>(null);

  // ✅ erro claro se faltar chave
  const [keyError, setKeyError] = useState<string | null>(null);
  useEffect(() => {
    if (!GOOGLE_KEY) {
      setKeyError(
        "Chave do Google não encontrada.\n\nConfira o arquivo .env na raiz:\nEXPO_PUBLIC_GOOGLE_MAPS_KEY=AIza...\n\nDepois reinicie:\nnpx expo start -c"
      );
    } else {
      setKeyError(null);
    }
  }, []);

  // preencher embarque inicial com localização (se vazio)
  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (!mounted) return;
        if (status !== "granted") return;

        if ((originText || "").trim().length > 0) return;

        const loc = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });
        if (!mounted) return;

        const desc = "Minha localização";
        setOriginText(desc);
        setOrigin({ description: desc, lat: loc.coords.latitude, lng: loc.coords.longitude });
      } catch {}
    })();

    return () => {
      mounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mantém query sincronizada com campo ativo (quando troca foco)
  useEffect(() => {
    const t = activeField === "origin" ? originText : destText;
    setQuery(t ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeField]);

  // ✅ Sugestões com 1 letra (regra nossa) + debounce
  useEffect(() => {
    const q = (query ?? "").trim();

    if (!q || q.length < 1) {
      setSuggestions([]);
      setLoadingSug(false);
      return;
    }

    let alive = true;
    const timer = setTimeout(async () => {
      try {
        setLoadingSug(true);
        const items = await fetchPlacesAutocomplete(q);
        if (!alive) return;
        setSuggestions(items);
      } catch {
        if (!alive) return;
        setSuggestions([]);
      } finally {
        if (alive) setLoadingSug(false);
      }
    }, 180);

    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [query]);

  async function onPickSuggestion(s: Suggestion) {
    Keyboard.dismiss();
    setSuggestions([]);

    const place = await fetchPlaceDetails(s.placeId);
    if (!place) return;

    if (activeField === "origin") {
      setOrigin(place);
      setOriginText(place.description);

      // auto-avança pro destino
      setActiveField("destination");
      setQuery(destText);
      setTimeout(() => destRef.current?.focus(), 60);
    } else {
      setDestination(place);
      setDestText(place.description);
      setQuery(""); // fecha a lista
    }
  }

  function clearOrigin() {
    setOrigin(null);
    setOriginText("");
    setActiveField("origin");
    setSuggestions([]);
    setQuery("");
    setTimeout(() => originRef.current?.focus(), 60);
  }

  function clearDest() {
    setDestination(null);
    setDestText("");
    setActiveField("destination");
    setSuggestions([]);
    setQuery("");
    setTimeout(() => destRef.current?.focus(), 60);
  }

  const canConfirm = !!origin && !!destination;

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      {/* Topo: Casa / Trabalho */}
      <View style={styles.topRow}>
        <Pressable onPress={() => router.push("/passageiro/casa")} style={styles.pillGhost}>
          <Ionicons name="home" size={16} color={UI.colors.blue} />
          <Text style={styles.pillGhostText}>Casa</Text>
        </Pressable>

        <Pressable onPress={() => router.push("/passageiro/trabalho")} style={styles.pillGhost}>
          <Ionicons name="briefcase" size={16} color={UI.colors.blue} />
          <Text style={styles.pillGhostText}>Trabalho</Text>
        </Pressable>
      </View>

      {/* Card */}
      <View style={[styles.card, UI.shadow.soft]}>
        <Text style={styles.title}>Para onde vamos?</Text>

        {keyError ? (
          <View style={styles.errBox}>
            <Text style={styles.errText}>{keyError}</Text>
          </View>
        ) : null}

        {/* EMBARQUE */}
        <Text style={styles.label}>EMBARQUE</Text>
        <View style={styles.inputWrap}>
          <Ionicons name="search" size={18} color="rgba(11,27,43,0.45)" />
          <TextInput
            ref={originRef}
            value={originText}
            onFocus={() => setActiveField("origin")}
            onChangeText={(t) => {
              setOriginText(t);
              setActiveField("origin");
              setQuery(t);
              if (origin) setOrigin(null);
            }}
            placeholder="Toque para definir embarque…"
            placeholderTextColor="rgba(11,27,43,0.35)"
            selectionColor={UI.colors.blue}
            keyboardAppearance="light"
            style={styles.input}
            returnKeyType="next"
            onSubmitEditing={() => destRef.current?.focus()}
            autoCorrect={false}
          />
          {!!originText && (
            <Pressable onPress={clearOrigin} hitSlop={10} style={styles.clearBtn}>
              <Ionicons name="close" size={18} color={UI.colors.text} />
            </Pressable>
          )}
        </View>

        {/* DESTINO */}
        <Text style={[styles.label, { marginTop: 14 }]}>DESTINO</Text>
        <View style={styles.inputWrap}>
          <Ionicons name="search" size={18} color="rgba(11,27,43,0.45)" />
          <TextInput
            ref={destRef}
            value={destText}
            onFocus={() => setActiveField("destination")}
            onChangeText={(t) => {
              setDestText(t);
              setActiveField("destination");
              setQuery(t);
              if (destination) setDestination(null);
            }}
            placeholder="Toque para definir destino…"
            placeholderTextColor="rgba(11,27,43,0.35)"
            selectionColor={UI.colors.blue}
            keyboardAppearance="light"
            style={styles.input}
            returnKeyType="done"
            autoCorrect={false}
          />
          {!!destText && (
            <Pressable onPress={clearDest} hitSlop={10} style={styles.clearBtn}>
              <Ionicons name="close" size={18} color={UI.colors.text} />
            </Pressable>
          )}
        </View>

        {/* + PARADAS */}
        <View style={styles.stopsRow}>
          <Pressable onPress={() => router.push("/passageiro/paradas")} style={[styles.stopsBtn, UI.shadow.soft]}>
            <Text style={styles.stopsPlus}>+</Text>
            <Text style={styles.stopsText}>Paradas</Text>
          </Pressable>
        </View>

        {/* SUGESTÕES */}
        <View style={{ marginTop: 12 }}>
          {loadingSug && suggestions.length === 0 ? (
            <View style={styles.loadingRow}>
              <ActivityIndicator />
              <Text style={styles.loadingText}>Buscando…</Text>
            </View>
          ) : null}

          {suggestions.length > 0 ? (
            <View style={[styles.sugBox, UI.shadow.soft]}>
              <FlatList
                keyboardShouldPersistTaps="handled"
                data={suggestions}
                keyExtractor={(item) => item.placeId}
                renderItem={({ item }) => (
                  <Pressable onPress={() => onPickSuggestion(item)} style={styles.sugItem}>
                    <Text style={styles.sugPrimary} numberOfLines={1}>
                      {item.primary}
                    </Text>
                    {!!item.secondary && (
                      <Text style={styles.sugSecondary} numberOfLines={1}>
                        {item.secondary}
                      </Text>
                    )}
                  </Pressable>
                )}
              />
            </View>
          ) : null}
        </View>
      </View>

      {/* Confirmar */}
      <View style={{ paddingBottom: insets.bottom + 12, paddingHorizontal: 16, marginTop: 14 }}>
        <Pressable
          disabled={!canConfirm}
          onPress={() => router.push("/passageiro/escolha-carro")}
          style={[styles.confirmBtn, UI.shadow.soft, { opacity: canConfirm ? 1 : 0.45 }]}
        >
          <Text style={styles.confirmText}>Confirmar</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  topRow: {
    flexDirection: "row",
    gap: 10,
    paddingHorizontal: 2,
    marginBottom: 10,
  },
  pillGhost: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    height: 40,
    borderRadius: UI.radius.pill,
    backgroundColor: "rgba(255,255,255,0.55)",
    borderWidth: 1,
    borderColor: "rgba(31,102,209,0.18)",
  },
  pillGhostText: {
    color: UI.colors.text,
    fontWeight: "700",
  },

  card: {
    backgroundColor: "rgba(255,255,255,0.92)",
    borderRadius: UI.radius.xl,
    borderWidth: 1,
    borderColor: UI.colors.border,
    padding: 14,
  },

  title: {
    fontSize: 22,
    fontWeight: "800",
    color: UI.colors.text,
    marginBottom: 12,
  },

  errBox: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "rgba(225,29,72,0.25)",
    borderRadius: 18,
    padding: 12,
    marginBottom: 12,
  },
  errText: { color: "#9F1239", fontWeight: "800", fontSize: 12, lineHeight: 16 },

  label: {
    fontSize: 12,
    letterSpacing: 2,
    fontWeight: "800",
    color: "rgba(11,27,43,0.70)",
    marginBottom: 8,
  },

  inputWrap: {
    height: 54,
    borderRadius: UI.radius.lg,
    paddingHorizontal: 12,
    backgroundColor: UI.colors.surface,
    borderWidth: 1,
    borderColor: UI.colors.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  input: {
    flex: 1,
    height: 54,
    color: UI.colors.text,
    fontSize: 15,
    fontWeight: "600",
  },

  clearBtn: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: "rgba(11,27,43,0.06)",
    alignItems: "center",
    justifyContent: "center",
  },

  stopsRow: {
    marginTop: 12,
    alignItems: "flex-end",
  },
  stopsBtn: {
    height: 44,
    width: "52%",
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.surface,
    borderWidth: 1,
    borderColor: "rgba(31,102,209,0.22)",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  stopsPlus: {
    fontSize: 26,
    fontWeight: "900",
    color: UI.colors.blue,
    marginTop: -2,
  },
  stopsText: {
    fontSize: 14,
    fontWeight: "900",
    color: UI.colors.blue,
  },

  sugBox: {
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.surface,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
  },
  sugItem: {
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(11,27,43,0.06)",
  },
  sugPrimary: {
    fontSize: 14,
    fontWeight: "800",
    color: UI.colors.text,
  },
  sugSecondary: {
    marginTop: 2,
    fontSize: 12,
    fontWeight: "600",
    color: UI.colors.muted,
  },

  loadingRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 4,
  },
  loadingText: {
    color: UI.colors.muted,
    fontWeight: "700",
  },

  confirmBtn: {
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },
  confirmText: {
    color: UI.colors.white,
    fontSize: 16,
    fontWeight: "900",
  },
});