import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { Ionicons } from "@expo/vector-icons";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo } from "react";
import {
    Pressable,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#F4F8FF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    white: "#FFFFFF",
    blue2: "#2B7AE6",
    border: "rgba(11,27,43,0.10)",
    line: "rgba(255,255,255,0.78)",
    warningText: "#FFD84D",
    successText: "#16A34A",
  },
  radius: {
    lg: 18,
    xl: 28,
    pill: 999,
  },
};

export default function Gravar() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [fontsLoaded] = useFonts({
    Cinzel_700Bold,
  });

  const titleFont = useMemo(
    () =>
      fontsLoaded
        ? { fontFamily: "Cinzel_700Bold" as const }
        : { fontWeight: "900" as const },
    [fontsLoaded]
  );

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        style={styles.screen}
        contentContainerStyle={{
          paddingTop: insets.top + 8,
          paddingBottom: insets.bottom + 34,
          paddingHorizontal: 18,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.backBtn,
              pressed && styles.backBtnPressed,
            ]}
          >
            <View style={styles.backGloss} />
            <View style={styles.backDepth} />
            <View style={styles.backInnerBorder} />
            <Ionicons name="arrow-back" size={24} color={UI.colors.blue2} />
          </Pressable>

          <View style={styles.titleBox}>
            <Text style={[styles.title, titleFont]}>GRAVAR</Text>
          </View>

          <View style={{ width: 50 }} />
        </View>

        <Text style={styles.subtitle}>
          Escolha a forma de registro
        </Text>

        <View style={styles.list}>
          <ActionButton
            icon="mic-outline"
            title="GRAVAÇÃO DE ÁUDIO"
            onPress={() => router.push("/passageiro/gravar-audio")}
          />

          <ActionButton
            icon="camera-outline"
            title="CÂMERA FRONTAL"
            onPress={() => router.push("/passageiro/camera-frontal")}
          />

          <ActionButton
            icon="videocam-outline"
            title="CÂMERA TRASEIRA"
            onPress={() => router.push("/passageiro/camera-traseira")}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function ActionButton({
  icon,
  title,
  onPress,
}: {
  icon: React.ComponentProps<typeof Ionicons>["name"];
  title: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.btnWrap,
        pressed && styles.btnWrapPressed,
      ]}
    >
      <View style={styles.btn}>
        <View style={styles.btnGlowTop} />
        <View style={styles.btnGlowBottom} />
        <View style={styles.btnInnerBorder} />

        <View style={styles.iconWrap}>
          <Ionicons name={icon} size={24} color={UI.colors.white} />
        </View>

        <Text style={styles.btnTitle}>{title}</Text>

        <Ionicons
          name="chevron-forward"
          size={20}
          color="rgba(255,255,255,0.92)"
        />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 18,
  },

  backBtn: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.88)",
    borderWidth: 1,
    borderColor: UI.colors.border,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  backBtnPressed: {
    transform: [{ scale: 0.96 }],
  },

  backGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.78)",
  },

  backDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  backInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.88)",
  },

  titleBox: {
    flex: 1,
    alignItems: "center",
  },

  title: {
    fontSize: 28,
    color: "rgba(64,108,160,0.86)",
    letterSpacing: 5,
  },

  subtitle: {
    textAlign: "center",
    color: UI.colors.muted,
    fontSize: 14,
    fontWeight: "700",
    marginBottom: 22,
  },

  list: {
    gap: 18,
  },

  btnWrap: {
    borderRadius: UI.radius.pill,
  },

  btnWrapPressed: {
    transform: [{ scale: 0.985 }],
  },

  btn: {
    minHeight: 78,
    borderRadius: UI.radius.pill,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    backgroundColor: UI.colors.blue2,
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(215,235,255,0.95)",
  },

  btnGlowTop: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "52%",
    backgroundColor: "rgba(255,255,255,0.20)",
  },

  btnGlowBottom: {
    position: "absolute",
    bottom: -10,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.08)",
  },

  btnInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: UI.radius.pill,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.30)",
  },

  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.14)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 14,
  },

  btnTitle: {
    flex: 1,
    color: UI.colors.white,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 0.4,
  },
});