import { useRouter } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import PassengerMap, { PassengerMapHandle } from "./PassengerMap";

const UI = {
  colors: {
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    surface: "rgba(255,255,255,0.92)",
    surfaceStrong: "rgba(255,255,255,0.96)",
    border: "rgba(11,27,43,0.10)",
    overlay: "rgba(255,255,255,0.76)",
    shadow: "rgba(11,27,43,0.18)",
    white: "#FFFFFF",
    line: "rgba(255,255,255,0.72)",
  },
  radius: { lg: 18, xl: 24, pill: 999 },
};

export default function Home() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const passengerName = "Anton";

  const mapRef = useRef<PassengerMapHandle>(null);
  const [overlayH, setOverlayH] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => {
      mapRef.current?.setFocusMode("idle");
    }, 220);

    return () => clearTimeout(t);
  }, []);

  const hello = useMemo(
    () => passengerName?.trim() || "Passageiro",
    [passengerName]
  );

  return (
    <View style={styles.screen}>
      <PassengerMap ref={mapRef} />

      <View
        pointerEvents="none"
        style={[
          styles.topOverlay,
          {
            height: overlayH > 0 ? overlayH : insets.top + 182,
          },
        ]}
      />

      <Pressable
        onPress={() => router.push("/menu-passageiro")}
        hitSlop={12}
        style={({ pressed }) => [
          styles.menuOuter,
          { top: insets.top + 10, left: 14 },
          pressed && styles.menuOuterPressed,
        ]}
      >
        <View style={styles.menuGloss} />
        <View style={styles.menuDepth} />
        <View style={styles.menuInnerBorder} />
        <View style={styles.menuInner}>
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
          <View style={styles.menuLine} />
        </View>
      </Pressable>

      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Text style={styles.helloText} numberOfLines={1}>
          Olá, <Text style={styles.helloName}>{hello}</Text>
        </Text>

        <Text style={styles.title} numberOfLines={1}>
          Para onde vamos?
        </Text>
      </View>

      <View
        style={styles.cardWrap}
        onLayout={(e) => {
          const y = e.nativeEvent.layout.y;
          setOverlayH(y);
        }}
      >
        <View style={styles.card}>
          <View style={styles.cardGlow} />
          <View style={styles.cardDepth} />
          <View style={styles.cardInnerBorder} />

          <Text style={styles.sectionLabel}>EMBARQUE</Text>

          <Pressable
            style={({ pressed }) => [
              styles.input,
              pressed && styles.inputPressed,
            ]}
            onPress={() => router.push("/passageiro/busca")}
          >
            <View style={styles.dotGray} />
            <Text style={styles.inputText} numberOfLines={1}>
              Toque para definir embarque...
            </Text>
          </Pressable>

          <View style={{ height: 10 }} />

          <Text style={styles.sectionLabel}>DESTINO</Text>

          <Pressable
            style={({ pressed }) => [
              styles.input,
              pressed && styles.inputPressed,
            ]}
            onPress={() => router.push("/passageiro/busca")}
          >
            <View style={styles.dotGray} />
            <Text style={styles.inputText} numberOfLines={1}>
              Toque para definir destino...
            </Text>
          </Pressable>
        </View>
      </View>

      <View style={[styles.marketingWrap, { bottom: insets.bottom + 6 }]}>
        <View style={styles.marketingCard}>
          <View style={styles.marketingGlow} />
          <View style={styles.marketingDepth} />
          <View style={styles.marketingInnerBorder} />

          <Text style={styles.marketingTitle}>
            VIAGENS COM{"\n"}DESCONTO
          </Text>

          <Text style={styles.marketingSub}>Até 20% OFF</Text>

          <View style={styles.dotsRow}>
            <View style={[styles.dot, styles.dotActive]} />
            <View style={styles.dot} />
            <View style={styles.dot} />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  topOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: UI.colors.overlay,
  },

  menuOuter: {
    position: "absolute",
    width: 58,
    height: 58,
    borderRadius: 18,
    backgroundColor: UI.colors.blue2,
    borderWidth: 1.4,
    borderColor: UI.colors.line,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.28,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  menuOuterPressed: {
    transform: [{ scale: 0.96 }],
    shadowOpacity: 0.14,
  },

  menuGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "52%",
    backgroundColor: "rgba(255,255,255,0.24)",
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },

  menuDepth: {
    position: "absolute",
    bottom: -6,
    left: 0,
    right: 0,
    height: "40%",
    backgroundColor: "rgba(0,0,0,0.14)",
    borderBottomLeftRadius: 18,
    borderBottomRightRadius: 18,
  },

  menuInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.38)",
  },

  menuInner: {
    width: 28,
    height: 22,
    justifyContent: "center",
  },

  menuLine: {
    height: 3,
    borderRadius: 2,
    backgroundColor: UI.colors.white,
    marginVertical: 3,
    width: 26,
  },

  header: {
    position: "absolute",
    left: 0,
    right: 0,
    alignItems: "center",
  },

  helloText: {
    fontSize: 20,
    fontWeight: "900",
    color: UI.colors.text,
    marginTop: 6,
  },

  helloName: {
    color: UI.colors.blue2,
  },

  title: {
    marginTop: 6,
    fontSize: 30,
    fontWeight: "900",
    color: UI.colors.text,
    letterSpacing: -0.3,
  },

  cardWrap: {
    position: "absolute",
    left: 14,
    right: 14,
    top: 150,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    borderWidth: 1,
    borderColor: UI.colors.border,
    padding: 14,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  cardGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.26)",
    borderTopLeftRadius: UI.radius.xl,
    borderTopRightRadius: UI.radius.xl,
  },

  cardDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
    borderBottomLeftRadius: UI.radius.xl,
    borderBottomRightRadius: UI.radius.xl,
  },

  cardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.40)",
  },

  sectionLabel: {
    fontSize: 14,
    fontWeight: "900",
    letterSpacing: 3,
    color: "rgba(11,27,43,0.70)",
    marginBottom: 8,
  },

  input: {
    height: 48,
    borderRadius: 15,
    backgroundColor: UI.colors.surfaceStrong,
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.10)",
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
  },

  inputPressed: {
    transform: [{ scale: 0.992 }],
    opacity: 0.95,
  },

  dotGray: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "rgba(11,27,43,0.25)",
    marginRight: 10,
  },

  inputText: {
    flex: 1,
    color: "rgba(11,27,43,0.45)",
    fontSize: 16,
    fontWeight: "800",
  },

  marketingWrap: {
    position: "absolute",
    left: 14,
    right: 14,
  },

  marketingCard: {
    backgroundColor: UI.colors.surface,
    borderRadius: 26,
    borderWidth: 1,
    borderColor: UI.colors.border,
    paddingVertical: 16,
    paddingHorizontal: 18,
    alignItems: "center",
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  marketingGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "46%",
    backgroundColor: "rgba(255,255,255,0.22)",
    borderTopLeftRadius: 26,
    borderTopRightRadius: 26,
  },

  marketingDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
    borderBottomLeftRadius: 26,
    borderBottomRightRadius: 26,
  },

  marketingInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.38)",
  },

  marketingTitle: {
    fontSize: 34,
    fontWeight: "900",
    color: UI.colors.blue2,
    textAlign: "center",
    letterSpacing: 0.5,
    lineHeight: 38,
  },

  marketingSub: {
    marginTop: 8,
    fontSize: 22,
    fontWeight: "900",
    color: "rgba(11,27,43,0.45)",
  },

  dotsRow: {
    flexDirection: "row",
    gap: 8,
    marginTop: 10,
  },

  dot: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: "rgba(11,27,43,0.18)",
  },

  dotActive: {
    backgroundColor: UI.colors.blue2,
  },
});