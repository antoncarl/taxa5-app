import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import {
  Animated,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useRideStore } from "../../src/store/rideStore";

type CarType = {
  id: string;
  name: string;
  eta: string;
  price: string;
  badge: string;
};

const UI = {
  colors: {
    bg: "#F4F8FF",
    surface: "rgba(255,255,255,0.94)",
    surfaceStrong: "rgba(255,255,255,0.98)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    border: "rgba(15,23,42,0.10)",
    borderSoft: "rgba(15,23,42,0.08)",
    line: "rgba(255,255,255,0.72)",
    white: "#FFFFFF",
  },
  radius: {
    lg: 18,
    xl: 24,
    pill: 999,
  },
};

export default function EscolhaCarro() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const origin = useRideStore((s) => s.origin);
  const destination = useRideStore((s) => s.destination);

  const cars = useMemo<CarType[]>(
    () => [
      {
        id: "eco",
        name: "Taxa Eco",
        eta: "3 min",
        price: "R$ 18,90",
        badge: "Mais rápido",
      },
      {
        id: "plus",
        name: "Taxa Plus",
        eta: "5 min",
        price: "R$ 24,90",
        badge: "Mais conforto",
      },
      {
        id: "vip",
        name: "Taxa VIP",
        eta: "7 min",
        price: "R$ 39,90",
        badge: "Premium",
      },
    ],
    []
  );

  const [selected, setSelected] = useState<string>("eco");

  const pressAnim = useRef(new Animated.Value(0)).current;
  const buttonScale = pressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.97],
  });

  const podeChamar = !!origin && !!destination;

  function handleSelect(id: string) {
    setSelected(id);
    Haptics.selectionAsync();
  }

  function chamar() {
    if (!podeChamar) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    router.push({
      pathname: "/passageiro/tracking",
      params: { car: selected },
    });
  }

  return (
    <View style={styles.screen}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: insets.top + 14,
          paddingBottom: insets.bottom + 120,
          paddingHorizontal: 16,
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerRow}>
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [
              styles.backBtn,
              pressed && styles.backBtnPressed,
            ]}
          >
            <View style={styles.backGloss} />
            <View style={styles.backDepth} />
            <View style={styles.backInnerBorder} />
            <Text style={styles.backArrow}>‹</Text>
          </Pressable>
        </View>

        <View style={styles.header}>
          <Text style={styles.h1}>Escolha seu carro</Text>
          <Text style={styles.subHeader}>Selecione a melhor opção para sua corrida</Text>
        </View>

        <View style={styles.routeCard}>
          <View style={styles.routeGlow} />
          <View style={styles.routeDepth} />
          <View style={styles.routeInnerBorder} />

          <Text style={styles.sectionLabel}>EMBARQUE</Text>
          <View style={styles.routeRow}>
            <View style={[styles.dot, { backgroundColor: "#19C37D" }]} />
            <Text style={styles.routeText} numberOfLines={1}>
              {origin?.description ?? "—"}
            </Text>
          </View>

          <View style={{ height: 10 }} />

          <Text style={styles.sectionLabel}>DESTINO</Text>
          <View style={styles.routeRow}>
            <View style={[styles.dot, { backgroundColor: "#FF7A59" }]} />
            <Text style={styles.routeText} numberOfLines={1}>
              {destination?.description ?? "—"}
            </Text>
          </View>
        </View>

        <View style={styles.carsList}>
          {cars.map((c) => {
            const isOn = selected === c.id;

            return (
              <Pressable
                key={c.id}
                onPress={() => handleSelect(c.id)}
                style={({ pressed }) => [
                  styles.carCard,
                  isOn && styles.carCardActive,
                  pressed && styles.carCardPressed,
                ]}
              >
                <View style={styles.cardGlow} />
                <View style={styles.cardDepth} />
                <View style={styles.cardInnerBorder} />

                <View style={styles.carLeft}>
                  <View style={styles.carTopRow}>
                    <Text style={styles.name}>{c.name}</Text>

                    <View style={[styles.badge, isOn && styles.badgeActive]}>
                      <Text style={[styles.badgeText, isOn && styles.badgeTextActive]}>
                        {c.badge}
                      </Text>
                    </View>
                  </View>

                  <Text style={styles.sub}>
                    {c.eta} • {c.price}
                  </Text>
                </View>

                <View style={[styles.pill, isOn && styles.pillOn]}>
                  <Text style={[styles.pillText, isOn && styles.pillTextOn]}>
                    {isOn ? "Selecionado" : "Escolher"}
                  </Text>
                </View>
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      <View style={[styles.ctaWrap, { paddingBottom: insets.bottom + 12 }]}>
        <Animated.View style={{ transform: [{ scale: buttonScale }] }}>
          <Pressable
            onPressIn={() =>
              Animated.timing(pressAnim, {
                toValue: 1,
                duration: 90,
                useNativeDriver: true,
              }).start()
            }
            onPressOut={() =>
              Animated.timing(pressAnim, {
                toValue: 0,
                duration: 140,
                useNativeDriver: true,
              }).start()
            }
            onPress={chamar}
            disabled={!podeChamar}
            style={[
              styles.cta,
              !podeChamar && styles.ctaDisabled,
            ]}
          >
            <View style={styles.ctaGloss} />
            <View style={styles.ctaDepth} />
            <View style={styles.ctaInnerBorder} />
            <Text
              style={[
                styles.ctaText,
                !podeChamar && styles.ctaTextDisabled,
              ]}
            >
              CHAMAR CORRIDA
            </Text>
          </Pressable>
        </Animated.View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  headerRow: {
    marginBottom: 12,
  },

  backBtn: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: UI.colors.white,
    borderWidth: 1,
    borderColor: UI.colors.border,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.12,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 5,
  },

  backBtnPressed: {
    transform: [{ scale: 0.96 }],
    shadowOpacity: 0.06,
  },

  backGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.70)",
  },

  backDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  backInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 13,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.80)",
  },

  backArrow: {
    fontSize: 30,
    color: UI.colors.blue2,
    marginTop: -2,
    fontWeight: "700",
  },

  header: {
    marginBottom: 18,
  },

  h1: {
    fontSize: 28,
    fontWeight: "900",
    color: UI.colors.text,
    letterSpacing: -0.3,
  },

  subHeader: {
    marginTop: 6,
    fontSize: 14,
    color: UI.colors.muted,
    fontWeight: "700",
  },

  routeCard: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.colors ? 24 : 24,
    padding: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  routeGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.25)",
  },

  routeDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  routeInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  sectionLabel: {
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 3,
    color: "rgba(11,27,43,0.70)",
    marginBottom: 8,
  },

  routeRow: {
    height: 48,
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.surfaceStrong,
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
    paddingHorizontal: 14,
    flexDirection: "row",
    alignItems: "center",
  },

  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 10,
  },

  routeText: {
    flex: 1,
    fontSize: 15,
    fontWeight: "700",
    color: UI.colors.text,
  },

  carsList: {
    gap: 12,
  },

  carCard: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  carCardActive: {
    borderColor: "rgba(43,122,230,0.30)",
    backgroundColor: "#F4F9FF",
  },

  carCardPressed: {
    transform: [{ scale: 0.992 }],
    opacity: 0.97,
  },

  cardGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  cardDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  cardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.40)",
  },

  carLeft: {
    flex: 1,
  },

  carTopRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },

  name: {
    fontSize: 18,
    fontWeight: "900",
    color: UI.colors.text,
    flex: 1,
  },

  sub: {
    marginTop: 6,
    color: UI.colors.blue2,
    fontWeight: "800",
    fontSize: 14,
  },

  badge: {
    height: 28,
    paddingHorizontal: 10,
    borderRadius: UI.radius.pill,
    backgroundColor: "rgba(15,23,42,0.05)",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.05)",
    alignItems: "center",
    justifyContent: "center",
  },

  badgeActive: {
    backgroundColor: "rgba(43,122,230,0.12)",
    borderColor: "rgba(43,122,230,0.18)",
  },

  badgeText: {
    fontSize: 11,
    fontWeight: "900",
    color: "#425466",
  },

  badgeTextActive: {
    color: UI.colors.blue2,
  },

  pill: {
    height: 38,
    paddingHorizontal: 14,
    borderRadius: UI.radius.pill,
    backgroundColor: "rgba(15,23,42,0.04)",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 12,
  },

  pillOn: {
    backgroundColor: UI.colors.blue2,
    borderColor: "rgba(43,122,230,0.16)",
  },

  pillText: {
    fontWeight: "900",
    color: "#334155",
    fontSize: 12,
  },

  pillTextOn: {
    color: UI.colors.white,
  },

  ctaWrap: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 0,
    backgroundColor: "rgba(244,248,255,0.92)",
  },

  cta: {
    height: 58,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(255,255,255,0.72)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.28,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  ctaDisabled: {
    backgroundColor: "rgba(43,122,230,0.25)",
    shadowOpacity: 0,
    elevation: 0,
  },

  ctaGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  ctaDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.12)",
  },

  ctaInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
  },

  ctaText: {
    color: UI.colors.white,
    fontWeight: "900",
    letterSpacing: 1.4,
    fontSize: 16,
  },

  ctaTextDisabled: {
    color: "rgba(255,255,255,0.85)",
  },
});