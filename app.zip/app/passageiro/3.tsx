import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
  },
  radius: { lg: 18, xl: 22 },
};

export default function CadastroPassageiro() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [nome, setNome] = useState("");
  const [apelido, setApelido] = useState("");
  const [email, setEmail] = useState("");
  const [telefone, setTelefone] = useState("");

  const [fontsLoaded] = useFonts({ Cinzel_700Bold });

  // (opcional) se quiser esperar carregar a fonte antes de renderizar
  // por enquanto vamos só renderizar e aplicar quando carregar
  const titleStyle = fontsLoaded ? { fontFamily: "Cinzel_700Bold" as const } : undefined;

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, titleStyle]}>Cadastro Passageiro</Text>

      <View style={styles.card}>
        <Label text="Nome completo" />
        <Input value={nome} onChangeText={setNome} />

        <Label text="Apelido / Nome social" />
        <Input value={apelido} onChangeText={setApelido} />

        <Label text="E-mail" />
        <Input value={email} onChangeText={setEmail} keyboardType="email-address" />

        <Label text="Telefone" />
        <Input value={telefone} onChangeText={setTelefone} keyboardType="phone-pad" />

        <Pressable onPress={() => router.push("/passageiro/4")}>
          <Text style={styles.link}>Ler termos e condições</Text>
        </Pressable>
      </View>

      <Pressable onPress={() => router.push("/passageiro/5")} style={styles.btn}>
        <Text style={styles.btnText}>Avançar</Text>
      </Pressable>
    </View>
  );
}

function Label({ text }: { text: string }) {
  return <Text style={styles.label}>{text}</Text>;
}

function Input({
  value,
  onChangeText,
  keyboardType,
}: {
  value: string;
  onChangeText: (t: string) => void;
  keyboardType?: "default" | "email-address" | "phone-pad";
}) {
  return (
    <TextInput
      value={value}
      onChangeText={onChangeText}
      placeholder="Digite..."
      placeholderTextColor="rgba(11,27,43,0.35)"
      keyboardAppearance="light"
      selectionColor={UI.colors.blue}
      keyboardType={keyboardType}
      style={styles.input}
    />
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    color: UI.colors.text,
    marginBottom: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
  },

  label: {
    fontSize: 12,
    fontWeight: "800",
    color: UI.colors.muted,
    marginTop: 10,
    marginBottom: 6,
  },

  input: {
    height: 54,
    borderRadius: UI.radius.lg,
    paddingHorizontal: 14,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: UI.colors.border,
    color: UI.colors.text,
    fontWeight: "600",
  },

  link: {
    marginTop: 14,
    color: UI.colors.blue,
    fontWeight: "800",
    textAlign: "center",
  },

  btn: {
    marginTop: 20,
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },

  btnText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "900",
  },
});