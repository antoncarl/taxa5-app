import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo } from "react";
import {
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.60)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
  },
  radius: { lg: 18, xl: 22 },
};

export default function DocumentosPassageiro() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [fontsLoaded] = useFonts({
    Cinzel_700Bold,
  });

  const titleFont = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : null),
    [fontsLoaded]
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, titleFont]}>Verificação</Text>
      <Text style={styles.sub}>
        Segurança • Sentinel Protocol • Antifraude
      </Text>

      <ScrollView
        contentContainerStyle={{ paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* DOCUMENTO */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Documento com foto</Text>
          <Text style={styles.cardSub}>
            Envie frente e verso do RG, CNH ou documento válido.
          </Text>

          <Pressable style={styles.actionBtn}>
            <Text style={styles.actionText}>Tirar foto</Text>
          </Pressable>

          <Pressable style={styles.actionBtn}>
            <Text style={styles.actionText}>Fazer upload</Text>
          </Pressable>
        </View>

        {/* SELFIE */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Selfie com verificação</Text>
          <Text style={styles.cardSub}>
            Prova de vida (piscar, mover cabeça ou aproximar).
          </Text>

          <Pressable style={styles.actionBtn}>
            <Text style={styles.actionText}>Fazer selfie</Text>
          </Pressable>
        </View>

        {/* FOTO PERFIL */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Foto de perfil</Text>
          <Text style={styles.cardSub}>
            Esta foto será exibida para o motorista.
          </Text>

          <Pressable style={styles.actionBtn}>
            <Text style={styles.actionText}>Adicionar foto</Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* BOTÃO SEGUIR (LIBERADO) */}
      <Pressable
        onPress={() => router.push("/passageiro/home")}
        style={styles.btn}
      >
        <Text style={styles.btnText}>Finalizar e entrar</Text>
      </Pressable>

      <View style={{ height: insets.bottom + 10 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    color: UI.colors.text,
    marginBottom: 6,
  },

  sub: {
    color: UI.colors.muted,
    fontWeight: "700",
    marginBottom: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
    marginBottom: 12,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "900",
    color: UI.colors.text,
  },

  cardSub: {
    marginTop: 4,
    color: UI.colors.muted,
    fontWeight: "600",
  },

  actionBtn: {
    marginTop: 10,
    height: 46,
    borderRadius: UI.radius.lg,
    borderWidth: 1,
    borderColor: "rgba(31,102,209,0.25)",
    backgroundColor: "#F4F8FF",
    alignItems: "center",
    justifyContent: "center",
  },

  actionText: {
    color: UI.colors.blue,
    fontWeight: "800",
  },

  btn: {
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
  },

  btnText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "900",
  },
});