import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { Ionicons } from "@expo/vector-icons";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#F4F8FF",
    text: "#0B1B2B",
    white: "#FFFFFF",
    blueTop: "#7FB2FF",
    blueBottom: "#2B7AE6",
    dangerText: "#D92D20",
    warningText: "#FFD84D",
    successText: "#16A34A",
    border: "rgba(11,27,43,0.10)",
    line: "rgba(255,255,255,0.72)",
    shadowBlue: "rgba(43,122,230,0.22)",
  },
  radius: {
    xl: 30,
    pill: 999,
  },
};

export default function MenuPassageiro() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [fontsLoaded] = useFonts({
    Cinzel_700Bold,
  });

  const titleFont = useMemo(
    () =>
      fontsLoaded
        ? { fontFamily: "Cinzel_700Bold" as const }
        : { fontWeight: "900" as const },
    [fontsLoaded]
  );

  const goBackSafe = () => {
    // @ts-ignore
    if (typeof router.canGoBack === "function" && router.canGoBack()) {
      // @ts-ignore
      router.back();
      return;
    }
    router.replace("/passageiro/home");
  };

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={{
        paddingTop: insets.top + 10,
        paddingBottom: insets.bottom + 34,
        paddingHorizontal: 18,
      }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.headerRow}>
        <Pressable
          onPress={goBackSafe}
          style={({ pressed }) => [
            styles.backBtn,
            pressed && styles.backBtnPressed,
          ]}
        >
          <View style={styles.backGloss} />
          <View style={styles.backInnerBorder} />
          <Ionicons name="arrow-back" size={24} color="#4A86D9" />
        </Pressable>
      </View>

      <View style={styles.titleBox}>
        <Text style={[styles.title, titleFont]}>MENU</Text>
      </View>

      <View style={styles.list}>
        <MenuButton
          title="EMERGÊNCIA"
          icon="warning-outline"
          titleColor={UI.colors.dangerText}
          titleFont={titleFont}
          onPress={() => router.push("/contatos-emergencia")}
        />

        <MenuButton
          title="GRAVAR"
          icon="radio-button-on-outline"
          titleColor={UI.colors.warningText}
          titleFont={titleFont}
          onPress={() => router.push("/gravar")}
        />

        <MenuButton
          title="HISTÓRICO TAXA 5"
          icon="time-outline"
          titleColor={UI.colors.white}
          titleFont={titleFont}
          onPress={() => router.push("/ride-rating")}
        />

        <MenuButton
          title="PERFIL"
          icon="person-outline"
          titleColor={UI.colors.white}
          titleFont={titleFont}
          onPress={() => router.push("/cadastro-passageiro")}
        />

        <MenuButton
          title="AJUDA / SUPORTE"
          icon="headset-outline"
          titleColor={UI.colors.white}
          titleFont={titleFont}
          onPress={() => router.push("/atendimento")}
        />

        <MenuButton
          title="DICAS TAXA 5"
          icon="bulb-outline"
          titleColor={UI.colors.white}
          titleFont={titleFont}
          onPress={() => router.push("/passageiro/gravar")}
        />

        <MenuButton
          title="MODO MOTORISTA"
          icon="car-outline"
          titleColor={UI.colors.successText}
          titleFont={titleFont}
          onPress={() => router.replace("/motorista/100")}
        />
      </View>
    </ScrollView>
  );
}

function MenuButton({
  title,
  icon,
  titleColor,
  titleFont,
  onPress,
}: {
  title: string;
  icon: React.ComponentProps<typeof Ionicons>["name"];
  titleColor: string;
  titleFont: any;
  onPress?: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.btnWrap,
        pressed && styles.btnWrapPressed,
      ]}
    >
      <View style={styles.btnAura} />
      <View style={styles.btn}>
        <View style={styles.btnTopHalf} />
        <View style={styles.btnInnerBorder} />

        <View style={styles.iconWrap}>
          <Ionicons name={icon} size={24} color="#FFFFFF" />
        </View>

        <View style={styles.textWrap}>
          <Text
            style={[styles.btnTitle, { color: titleColor }, titleFont]}
            numberOfLines={1}
          >
            {title}
          </Text>
        </View>

        <Ionicons name="chevron-forward" size={22} color="#FFFFFF" />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  headerRow: {
    marginBottom: 8,
  },

  backBtn: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: UI.colors.border,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    shadowColor: "#8CB8FF",
    shadowOpacity: 0.18,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 6,
  },

  backBtnPressed: {
    transform: [{ scale: 0.96 }],
  },

  backGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.75)",
  },

  backInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.86)",
  },

  titleBox: {
    alignItems: "center",
    marginBottom: 24,
  },

  title: {
    fontSize: 30,
    color: "rgba(78,114,170,0.88)",
    letterSpacing: 6,
  },

  list: {
    gap: 18,
    paddingBottom: 8,
  },

  btnWrap: {
    borderRadius: UI.radius.pill,
  },

  btnWrapPressed: {
    transform: [{ scale: 0.985 }],
  },

  btnAura: {
    position: "absolute",
    top: 10,
    left: 16,
    right: 16,
    bottom: -10,
    borderRadius: UI.radius.pill,
    backgroundColor: UI.colors.shadowBlue,
  },

  btn: {
    minHeight: 84,
    borderRadius: UI.radius.pill,
    backgroundColor: UI.colors.blueBottom,
    borderWidth: 1.4,
    borderColor: "rgba(220,236,255,0.95)",
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    shadowColor: "#2B7AE6",
    shadowOpacity: 0.14,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 10 },
    elevation: 7,
  },

  btnTopHalf: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: UI.colors.blueTop,
  },

  btnInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: UI.radius.pill,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.14)",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 14,
  },

  textWrap: {
    flex: 1,
    justifyContent: "center",
  },

  btnTitle: {
    fontSize: 19,
    letterSpacing: 1.2,
  },
});