import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useRef, useState } from "react";
import {
    Animated,
    Pressable,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSession, type RideCategory } from "../lib/session";

const CATS: RideCategory[] = [
  { id: "eco", name: "Taxa Eco", etaMin: 3, price: 14.9, badge: "Mais barato" },
  { id: "plus", name: "Taxa Plus", etaMin: 2, price: 19.9, badge: "Premium" },
  { id: "black", name: "Taxa Black", etaMin: 4, price: 29.9, badge: "Tesla vibe" },
];

export default function Categorias() {
  const router = useRouter();
  const { ride, chooseCategory, requestRide } = useSession();

  const [selected, setSelected] = useState<RideCategory | null>(ride.category);
  const hold = useRef(new Animated.Value(0)).current;
  const [holding, setHolding] = useState(false);

  const canCall = Boolean(ride.pickup && ride.destination && selected);

  const onSelect = (c: RideCategory) => {
    Haptics.selectionAsync();
    setSelected(c);
    chooseCategory(c);
  };

  const startHold = () => {
    if (!canCall || holding) return;
    setHolding(true);
    hold.setValue(0);

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    Animated.timing(hold, {
      toValue: 1,
      duration: 900,
      useNativeDriver: false,
    }).start(({ finished }) => {
      setHolding(false);
      if (!finished) return;

      // confirma
      requestRide();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace("/passageiro/tracking");
    });
  };

  const stopHold = () => {
    if (!holding) return;
    Animated.timing(hold, { toValue: 0, duration: 160, useNativeDriver: false }).start();
    setHolding(false);
  };

  const widthFill = hold.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={10}>
          <Text style={styles.backTxt}>←</Text>
        </Pressable>
        <Text style={styles.hTitle}>Escolha seu carro</Text>
        <View style={{ width: 42 }} />
      </View>

      <View style={styles.summary}>
        <Text style={styles.sLabel}>Embarque</Text>
        <Text style={styles.sValue}>{ride.pickupText}</Text>
        <View style={{ height: 10 }} />
        <Text style={styles.sLabel}>Destino</Text>
        <Text style={styles.sValue}>{ride.destinationText}</Text>
      </View>

      <View style={styles.list}>
        {CATS.map((c) => {
          const active = selected?.id === c.id;
          return (
            <Pressable
              key={c.id}
              onPress={() => onSelect(c)}
              style={[styles.card, active && styles.cardActive]}
            >
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>
                  {c.name}{" "}
                  {c.badge ? <Text style={styles.badge}> • {c.badge}</Text> : null}
                </Text>
                <Text style={styles.meta}>Chega em ~{c.etaMin} min</Text>
              </View>

              <Text style={styles.price}>R$ {c.price.toFixed(2)}</Text>
            </Pressable>
          );
        })}
      </View>

      {/* Tesla Hold Button */}
      <View style={styles.bottom}>
        <Pressable
          onPressIn={startHold}
          onPressOut={stopHold}
          disabled={!canCall}
          style={[styles.callBtn, !canCall && styles.callBtnDisabled]}
        >
          <Animated.View style={[styles.callFill, { width: widthFill }]} />
          <Text style={styles.callTxt}>
            {canCall ? "Segure para chamar" : "Complete embarque e destino"}
          </Text>
        </Pressable>

        <Text style={styles.hint}>
          * Este é o MVP “absurdo”: confirmação por segurar (reduz toque acidental e passa confiança).
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#EEF6FF" },

  header: {
    paddingTop: 44,
    paddingHorizontal: 16,
    paddingBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  backBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.92)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },
  backTxt: { fontSize: 18, fontWeight: "900", color: "#0B4FA3" },
  hTitle: { fontSize: 18, fontWeight: "900", color: "#1F2A37" },

  summary: {
    marginHorizontal: 16,
    borderRadius: 24,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
    padding: 14,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 10 },
    elevation: 4,
  },
  sLabel: { fontSize: 12, fontWeight: "900", color: "#3C5B78", letterSpacing: 2 },
  sValue: { marginTop: 4, fontSize: 16, fontWeight: "800", color: "#1F2A37" },

  list: { paddingHorizontal: 16, paddingTop: 14, gap: 12 },

  card: {
    borderRadius: 24,
    padding: 16,
    backgroundColor: "#F8FCFF",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 8 },
    elevation: 3,
  },
  cardActive: { borderColor: "rgba(11,79,163,0.35)" },

  name: { fontSize: 16, fontWeight: "900", color: "#1F2A37" },
  badge: { fontSize: 12, fontWeight: "900", color: "#0B4FA3" },
  meta: { marginTop: 6, fontSize: 13, fontWeight: "700", color: "#5F7388" },
  price: { fontSize: 16, fontWeight: "900", color: "#0B4FA3" },

  bottom: { marginTop: "auto", padding: 16, paddingBottom: 18 },

  callBtn: {
    height: 58,
    borderRadius: 22,
    backgroundColor: "#0B4FA3",
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#0B4FA3",
    shadowOpacity: 0.22,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 12 },
    elevation: 8,
  },
  callBtnDisabled: { backgroundColor: "rgba(0,0,0,0.15)" },
  callFill: {
    position: "absolute",
    left: 0,
    top: 0,
    bottom: 0,
    backgroundColor: "rgba(255,255,255,0.22)",
  },
  callTxt: { color: "#FFF", fontWeight: "900", fontSize: 16 },

  hint: { marginTop: 10, color: "#5F7388", fontWeight: "700", fontSize: 12 },
});