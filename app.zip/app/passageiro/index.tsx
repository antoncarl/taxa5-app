import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { MarketingCarousel } from "../components/MarketingCarousel";
import { PremiumInput } from "../components/PremiumInput";
import { useSession } from "../lib/session";
import PassengerMap from "./PassengerMap";

export default function PassengerHome() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { ride } = useSession();

  const passengerName = ride.passengerName || "Passageiro";

  // marketing colado e premium (sem encostar nos botões do sistema)
  const GAP = 2;
  const marketingBottom = Math.max(Math.round(insets.bottom * 0.25) + GAP + 10, GAP);

  // animações de entrada
  const fade = useRef(new Animated.Value(0)).current;
  const titleY = useRef(new Animated.Value(10)).current;
  const cardY = useRef(new Animated.Value(18)).current;
  const cardScale = useRef(new Animated.Value(1)).current;

  // menu micro press
  const menuPress = useRef(new Animated.Value(0)).current;
  const menuScale = menuPress.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.92],
  });

  // ✅ Se seu PassengerMap não expõe handle, mantém assim mesmo (ref opcional)
  const mapRef = useRef<any>(null);
  const [destHasText, setDestHasText] = useState(false);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, {
        toValue: 1,
        duration: 520,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.timing(titleY, {
        toValue: 0,
        duration: 520,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.timing(cardY, {
        toValue: 0,
        duration: 620,
        delay: 60,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
    ]).start();
  }, [fade, titleY, cardY]);

  const liftCard = () => {
    Animated.parallel([
      Animated.timing(cardY, {
        toValue: -6,
        duration: 220,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.spring(cardScale, {
        toValue: 1.01,
        friction: 10,
        tension: 120,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const dropCard = () => {
    Animated.parallel([
      Animated.timing(cardY, {
        toValue: 0,
        duration: 260,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }),
      Animated.spring(cardScale, {
        toValue: 1,
        friction: 12,
        tension: 120,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const bounceCardOnce = () => {
    Animated.sequence([
      Animated.spring(cardScale, {
        toValue: 1.02,
        friction: 8,
        tension: 140,
        useNativeDriver: true,
      }),
      Animated.spring(cardScale, {
        toValue: 1.01,
        friction: 10,
        tension: 120,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const goBusca = (mode: "embarque" | "destino") => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({ pathname: "/passageiro/busca", params: { mode } });
  };

  return (
    <View style={styles.screen}>
      <PassengerMap ref={mapRef} />

      <View style={styles.topOverlay} pointerEvents="box-none">
        {/* vidro premium (branco + highlight) */}
        <View style={styles.topGlassWrap} pointerEvents="none">
          <View style={styles.topGlassWhite} />
          <View style={styles.topGlassHighlight} />
        </View>

        <Animated.View style={{ opacity: fade, transform: [{ translateY: titleY }] }}>
          <View style={styles.headerRow}>
            <Animated.View style={{ transform: [{ scale: menuScale }] }}>
              <Pressable
                onPressIn={() => {
                  Animated.timing(menuPress, {
                    toValue: 1,
                    duration: 110,
                    easing: Easing.out(Easing.quad),
                    useNativeDriver: true,
                  }).start();
                }}
                onPressOut={() => {
                  Animated.timing(menuPress, {
                    toValue: 0,
                    duration: 160,
                    easing: Easing.out(Easing.quad),
                    useNativeDriver: true,
                  }).start();
                }}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push("/menu-passageiro");
                }}
                style={styles.menuButton}
                hitSlop={10}
              >
                <View style={styles.menuLines}>
                  <View style={styles.menuLine} />
                  <View style={styles.menuLine} />
                  <View style={styles.menuLine} />
                </View>
              </Pressable>
            </Animated.View>

            <Text style={styles.hello}>Olá, {passengerName}</Text>
          </View>

          <Text style={styles.title}>Para onde vamos?</Text>
        </Animated.View>

        <Animated.View
          style={{
            opacity: fade,
            transform: [{ translateY: cardY }, { scale: cardScale }],
          }}
        >
          <View style={styles.card} pointerEvents="auto">
            <View style={styles.cardInnerHighlight} pointerEvents="none" />

            <Text style={styles.label}>EMBARQUE</Text>
            <PremiumInput
              placeholder={ride.pickupText || "Sua localização"}
              leftIcon={<Ionicons name="search" size={18} color="#4C6175" />}
              dense
              value={ride.pickupText || ""}
              editable={false}
              onPress={() => goBusca("embarque")}
              onFocus={() => {
                liftCard();
                mapRef.current?.setFocusMode?.("search");
              }}
              onBlur={() => {
                if (!destHasText) {
                  dropCard();
                  mapRef.current?.setFocusMode?.("idle");
                }
              }}
            />

            <Text style={[styles.label, { marginTop: 10 }]}>DESTINO</Text>
            <PremiumInput
              placeholder="Digitar destino..."
              leftIcon={<Ionicons name="search" size={18} color="#4C6175" />}
              dense
              value={ride.destinationText || ""}
              editable={false}
              onPress={() => goBusca("destino")}
              onFocus={() => {
                liftCard();
                mapRef.current?.setFocusMode?.("search");
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              }}
              onBlur={() => {
                dropCard();
                mapRef.current?.setFocusMode?.("idle");
              }}
              onChangeText={(t: string) => {
                const has = t.trim().length > 0;
                if (!destHasText && has) {
                  bounceCardOnce();
                  Haptics.selectionAsync();
                }
                setDestHasText(has);
              }}
            />
          </View>
        </Animated.View>
      </View>

      {/* MARKETING (20% menor) */}
      <View style={[styles.bottomOverlay, { bottom: marketingBottom }]} pointerEvents="box-none">
        <MarketingCarousel height={184} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#FFFFFF" },

  topOverlay: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    paddingTop: 44,
    paddingHorizontal: 16,
  },

  topGlassWrap: {
    position: "absolute",
    left: -16,
    right: -16,
    top: 0,
    height: 176,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
    overflow: "hidden",
  },

  topGlassWhite: { ...StyleSheet.absoluteFillObject, backgroundColor: "rgba(255,255,255,0.55)" },

  topGlassHighlight: {
    position: "absolute",
    left: 0,
    right: 0,
    top: -14,
    height: 70,
    backgroundColor: "rgba(255,255,255,0.28)",
  },

  headerRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 4 },

  menuButton: {
    width: 62,
    height: 54,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.92)",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 9 },
    elevation: 8,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },

  menuLines: { width: 42, gap: 7 },
  menuLine: { height: 4, borderRadius: 3, backgroundColor: "#0B4FA3" },

  hello: {
    flex: 1,
    textAlign: "center",
    fontSize: 20,
    fontWeight: "700",
    letterSpacing: 0.35,
    color: "#1F2A37",
    marginRight: 62,
    opacity: 0.9,
  },

  title: {
    textAlign: "center",
    fontSize: 36,
    fontWeight: "900",
    letterSpacing: -0.4,
    color: "#1F2A37",
    textShadowColor: "rgba(0,0,0,0.08)",
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 6,
    marginTop: 2,
    marginBottom: 6,
  },

  card: {
    borderRadius: 26,
    padding: 14,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 22,
    shadowOffset: { width: 0, height: 12 },
    elevation: 9,
    overflow: "hidden",
  },

  cardInnerHighlight: {
    position: "absolute",
    left: 10,
    right: 10,
    top: 10,
    height: 40,
    borderRadius: 99,
    backgroundColor: "rgba(255,255,255,0.35)",
  },

  label: {
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 2.5,
    color: "#3C5B78",
    marginBottom: 8,
  },

  bottomOverlay: { position: "absolute", left: 0, right: 0, paddingHorizontal: 16 },
});