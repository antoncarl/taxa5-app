import { Ionicons } from "@expo/vector-icons";
import { CameraType, CameraView, useCameraPermissions, useMicrophonePermissions } from "expo-camera";
import * as MediaLibrary from "expo-media-library";
import { useRouter } from "expo-router";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import React, { useEffect, useRef, useState } from "react";
import {
    Pressable,
    SafeAreaView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { storage } from "../../src/lib/firebase";

export default function CameraFrontal() {
  const router = useRouter();
  const cameraRef = useRef<CameraView | null>(null);

  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [micPermission, requestMicPermission] = useMicrophonePermissions();

  const [status, setStatus] = useState("Preparando filmagem...");
  const [isRecording, setIsRecording] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    startVideo();
  }, []);

  async function uploadFileToSentinel(uri: string) {
    const response = await fetch(uri);
    const blob = await response.blob();

    const fileName = `sentinel/video_front_${Date.now()}.mp4`;
    const fileRef = ref(storage, fileName);

    await uploadBytes(fileRef, blob, {
      contentType: "video/mp4",
    });

    return await getDownloadURL(fileRef);
  }

  async function startVideo() {
    try {
      setStatus("Solicitando permissões...");

      const cam = cameraPermission?.granted
        ? cameraPermission
        : await requestCameraPermission();

      const mic = micPermission?.granted
        ? micPermission
        : await requestMicPermission();

      const media = await MediaLibrary.requestPermissionsAsync();

      if (!cam.granted || !mic.granted || !media.granted) {
        setStatus("Permissão negada");
        return;
      }

      setTimeout(async () => {
        if (!cameraRef.current) {
          setStatus("Câmera não pronta");
          return;
        }

        setStatus("Filmando...");
        setIsRecording(true);

        const video = await cameraRef.current.recordAsync();

        if (!video?.uri) {
          setStatus("Vídeo não gerado");
          setIsRecording(false);
          return;
        }

        setIsSaving(true);
        setStatus("Salvando na galeria...");

        await MediaLibrary.saveToLibraryAsync(video.uri);

        setStatus("Enviando para Sentinel...");
        const url = await uploadFileToSentinel(video.uri);

        console.log("Sentinel URL:", url);
        setStatus("Vídeo salvo no aparelho e enviado para Sentinel");
        setIsRecording(false);
        setIsSaving(false);
      }, 700);
    } catch (error) {
      console.log(error);
      setStatus("Erro ao iniciar filmagem");
      setIsRecording(false);
      setIsSaving(false);
    }
  }

  async function stopVideo() {
    try {
      if (!cameraRef.current) return;
      setStatus("Encerrando filmagem...");
      await cameraRef.current.stopRecording();
    } catch {}
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing={"front" as CameraType}
          mode="video"
          mute={false}
        />

        <View style={styles.overlay}>
          <View style={styles.topInfo}>
            <Ionicons name="camera-outline" size={20} color="#FFFFFF" />
            <Text style={styles.topInfoText}>{status}</Text>
          </View>

          <View style={styles.bottomBar}>
            <Pressable
              onPress={stopVideo}
              disabled={!isRecording || isSaving}
              style={({ pressed }) => [
                styles.stopButton,
                (!isRecording || isSaving) && { opacity: 0.5 },
                pressed && isRecording && !isSaving && { transform: [{ scale: 0.97 }] },
              ]}
            >
              <Text style={styles.stopButtonText}>
                {isSaving ? "Salvando..." : "Parar filmagem"}
              </Text>
            </Pressable>

            <Pressable onPress={() => router.back()} style={styles.backButton}>
              <Text style={styles.backButtonText}>Voltar</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#000",
  },
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  camera: {
    flex: 1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "space-between",
    padding: 18,
  },
  topInfo: {
    marginTop: 18,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: "rgba(0,0,0,0.45)",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
  },
  topInfoText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "800",
  },
  bottomBar: {
    marginBottom: 24,
    gap: 12,
  },
  stopButton: {
    height: 58,
    borderRadius: 999,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
  },
  stopButtonText: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "900",
  },
  backButton: {
    height: 54,
    borderRadius: 999,
    backgroundColor: "#2B7AE6",
    alignItems: "center",
    justifyContent: "center",
  },
  backButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "900",
  },
});