import { Ionicons } from "@expo/vector-icons";
import * as Location from "expo-location";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  FlatList,
  Keyboard,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import MapView, { PROVIDER_GOOGLE } from "react-native-maps";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useFavoritesStore } from "../../store/favoritesStore";
import { SEARCH_2D_STYLE } from "./mapStyles";

const GOOGLE_KEY = process.env.EXPO_PUBLIC_GOOGLE_MAPS_KEY || "";

type Suggestion = {
  description: string;
  place_id: string;
};

const UI = {
  colors: {
    overlay: "rgba(244,248,255,0.78)",
    surface: "rgba(255,255,255,0.94)",
    surfaceStrong: "rgba(255,255,255,0.98)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(15,23,42,0.10)",
    borderSoft: "rgba(15,23,42,0.08)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    blueSoft: "rgba(43,122,230,0.12)",
    blueSoft2: "rgba(43,122,230,0.25)",
    white: "#FFFFFF",
    line: "rgba(255,255,255,0.70)",
    green: "#19C37D",
    orange: "#FF7A59",
  },
  radius: {
    lg: 18,
    xl: 26,
    pill: 999,
  },
};

function newSessionToken() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getFavoriteIcon(name: string) {
  const normalized = name.trim().toLowerCase();

  if (normalized === "casa") return "home";
  if (normalized === "trabalho") return "briefcase";

  return "star";
}

function normalizeParam(value: unknown) {
  if (typeof value === "string") return value;
  if (Array.isArray(value) && typeof value[0] === "string") return value[0];
  return "";
}

export default function Busca() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();

  const casa = useFavoritesStore((s) => s.casa);
  const trabalho = useFavoritesStore((s) => s.trabalho);

  const [pickup, setPickup] = useState("");
  const [dest, setDest] = useState("");
  const [active, setActive] = useState<"pickup" | "dest">("pickup");

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Suggestion[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [sessionToken, setSessionToken] = useState(newSessionToken());

  const [location, setLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  const [userTouchedPickup, setUserTouchedPickup] = useState(false);

  const destRef = useRef<TextInput>(null);

  const stop1 = normalizeParam(params.stop1);
  const stop2 = normalizeParam(params.stop2);
  const stop3 = normalizeParam(params.stop3);
  const stop4 = normalizeParam(params.stop4);
  const stop5 = normalizeParam(params.stop5);

  const stops = [stop1, stop2, stop3, stop4, stop5].filter(
    (item) => item.trim().length > 0
  );

  const stopCount = stops.length;

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (!mounted) return;

        if (status !== "granted") {
          setLocation(null);
          return;
        }

        const loc = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        if (!mounted) return;

        setLocation({
          latitude: loc.coords.latitude,
          longitude: loc.coords.longitude,
        });

        if (!userTouchedPickup) {
          setPickup("Minha localização atual");
        }
      } catch {
        if (!mounted) return;
        setLocation(null);
      }
    })();

    return () => {
      mounted = false;
    };
  }, [userTouchedPickup]);

  useEffect(() => {
    const q = query.trim();

    if (!GOOGLE_KEY) {
      setResults([]);
      return;
    }

    if (q.length < 1) {
      setResults([]);
      return;
    }

    const t = setTimeout(async () => {
      try {
        const base =
          "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
          `?input=${encodeURIComponent(q)}` +
          `&language=pt-BR` +
          `&components=country:br` +
          `&sessiontoken=${encodeURIComponent(sessionToken)}` +
          `&key=${encodeURIComponent(GOOGLE_KEY)}`;

        const bias = location
          ? `&location=${location.latitude},${location.longitude}&radius=50000`
          : "";

        const url = base + bias;

        const res = await fetch(url);
        const json = await res.json();

        if (
          json.status &&
          json.status !== "OK" &&
          json.status !== "ZERO_RESULTS"
        ) {
          console.log("Places status:", json.status, json.error_message || "");
        }

        setResults(Array.isArray(json.predictions) ? json.predictions : []);
      } catch (e) {
        console.log("Places fetch erro:", e);
        setResults([]);
      }
    }, 180);

    return () => clearTimeout(t);
  }, [query, location, sessionToken]);

  const listData = useMemo(() => {
    if (results.length > 0) return results;

    if (query.trim().length === 0) {
      return history.map((h) => ({ description: h, place_id: h }));
    }

    return [];
  }, [results, history, query]);

  function selectPlace(item: Suggestion) {
    Keyboard.dismiss();

    setHistory((prev) =>
      [item.description, ...prev.filter((x) => x !== item.description)].slice(
        0,
        8
      )
    );

    if (active === "pickup") {
      setPickup(item.description);
      setUserTouchedPickup(true);
      setResults([]);
      setActive("dest");
      setQuery(dest);
      setTimeout(() => destRef.current?.focus(), 90);
      return;
    }

    setDest(item.description);
    setResults([]);
    setQuery("");
    setSessionToken(newSessionToken());
  }

  function confirm() {
    if (!pickup.trim() || !dest.trim()) return;

    router.push({
      pathname: "/passageiro/escolha-carro",
      params: {
        embarque: pickup,
        destino: dest,
        stop1,
        stop2,
        stop3,
        stop4,
        stop5,
      },
    });
  }

  function fillFromFavorite(address: string) {
    if (!address.trim()) return;

    if (!pickup.trim() || pickup === "Minha localização atual") {
      setPickup(address);
      setUserTouchedPickup(true);
      setActive("dest");
      setTimeout(() => destRef.current?.focus(), 80);
      return;
    }

    setDest(address);
    setActive("dest");
  }

  function openStops() {
    router.push({
      pathname: "/passageiro/paradas",
      params: {
        stop1,
        stop2,
        stop3,
        stop4,
        stop5,
      },
    });
  }

  return (
    <View style={styles.screen}>
      {location ? (
        <MapView
          provider={PROVIDER_GOOGLE}
          style={StyleSheet.absoluteFillObject}
          customMapStyle={SEARCH_2D_STYLE}
          showsUserLocation
          showsBuildings
          showsCompass={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          pitchEnabled
          rotateEnabled={false}
          zoomControlEnabled={false}
          moveOnMarkerPress={false}
          renderToHardwareTextureAndroid
          cacheEnabled={false}
          initialCamera={{
            center: location,
            pitch: 40,
            heading: 0,
            altitude: 1400,
          }}
        />
      ) : null}

      <View pointerEvents="none" style={styles.mapOverlay} />

      <SafeAreaView style={styles.overlay}>
        <View style={{ paddingTop: 34 }}>
          <View style={styles.header}>
            <Text style={styles.title}>Definir rota</Text>
            <Text style={styles.subTitle}>Origem e destino da viagem</Text>
          </View>

          <Text style={styles.favoriteLabel}>Edite seus favoritos</Text>

          <View style={styles.quickRow}>
            <Pressable
              style={({ pressed }) => [
                styles.quickBtn,
                pressed && styles.pressedTiny,
              ]}
              onPress={() => router.push("/passageiro/favoritos?slot=casa")}
              onLongPress={() => fillFromFavorite(casa.address)}
            >
              <Ionicons
                name={getFavoriteIcon(casa.label)}
                size={16}
                color={UI.colors.blue2}
              />
              <Text style={styles.quickText}>{casa.label}</Text>
            </Pressable>

            <Pressable
              style={({ pressed }) => [
                styles.quickBtn,
                pressed && styles.pressedTiny,
              ]}
              onPress={() =>
                router.push("/passageiro/favoritos?slot=trabalho")
              }
              onLongPress={() => fillFromFavorite(trabalho.address)}
            >
              <Ionicons
                name={getFavoriteIcon(trabalho.label)}
                size={16}
                color={UI.colors.blue2}
              />
              <Text style={styles.quickText}>{trabalho.label}</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardGlow} />
          <View style={styles.cardDepth} />
          <View style={styles.cardInnerBorder} />

          <Text style={styles.sectionLabel}>EMBARQUE</Text>

          <View
            style={[
              styles.inputRow,
              active === "pickup" && styles.inputRowActive,
            ]}
          >
            <View style={[styles.dot, { backgroundColor: UI.colors.green }]} />
            <TextInput
              placeholder="Sua localização"
              value={pickup}
              onFocus={() => {
                setActive("pickup");
                setQuery(pickup === "Minha localização atual" ? "" : pickup);
              }}
              onChangeText={(t) => {
                setUserTouchedPickup(true);
                setPickup(t);
                setActive("pickup");
                setQuery(t);
              }}
              style={styles.input}
              placeholderTextColor="rgba(11,27,43,0.35)"
              autoCorrect={false}
              autoCapitalize="none"
              selectionColor={UI.colors.blue2}
              keyboardAppearance="light"
              returnKeyType="next"
              onSubmitEditing={() => {
                setActive("dest");
                setQuery(dest);
                setTimeout(() => destRef.current?.focus(), 70);
              }}
            />
          </View>

          <View style={{ height: 12 }} />

          <Text style={styles.sectionLabel}>DESTINO</Text>

          <View style={styles.destRow}>
            <View
              style={[
                styles.inputRow,
                styles.destInputWrap,
                active === "dest" && styles.inputRowActive,
              ]}
            >
              <View style={[styles.dot, { backgroundColor: UI.colors.orange }]} />

              <TextInput
                ref={destRef}
                placeholder="Para onde vamos?"
                value={dest}
                onFocus={() => {
                  setActive("dest");
                  setQuery(dest);
                }}
                onChangeText={(t) => {
                  setDest(t);
                  setActive("dest");
                  setQuery(t);
                }}
                style={styles.input}
                placeholderTextColor="rgba(11,27,43,0.35)"
                autoCorrect={false}
                autoCapitalize="none"
                selectionColor={UI.colors.blue2}
                keyboardAppearance="light"
                returnKeyType="done"
                onSubmitEditing={() => Keyboard.dismiss()}
              />

              {dest.length > 0 ? (
                <Pressable
                  onPress={() => {
                    setDest("");
                    setQuery("");
                    setResults([]);
                  }}
                >
                  <Ionicons
                    name="close-circle"
                    size={22}
                    color="rgba(11,27,43,0.35)"
                  />
                </Pressable>
              ) : null}
            </View>

            <Pressable
              style={({ pressed }) => [
                styles.stopBtnInline,
                pressed && styles.pressedTiny,
              ]}
              onPress={openStops}
            >
              <Text style={styles.stopPlus}>+</Text>
              <Text style={styles.stopText}>
                Paradas{stopCount > 0 ? ` (${stopCount})` : ""}
              </Text>
            </Pressable>
          </View>

          {stopCount > 0 ? (
            <View style={styles.stopsPreview}>
              {stops.map((item, index) => (
                <View key={`${item}-${index}`} style={styles.stopPreviewRow}>
                  <View style={styles.stopPreviewDot} />
                  <Text style={styles.stopPreviewText} numberOfLines={1}>
                    {item}
                  </Text>
                </View>
              ))}
            </View>
          ) : null}
        </View>

        {!GOOGLE_KEY ? (
          <View style={styles.warn}>
            <Ionicons
              name="warning-outline"
              size={18}
              color={UI.colors.text}
            />
            <Text style={styles.warnText}>
              Falta a chave EXPO_PUBLIC_GOOGLE_MAPS_KEY no .env
            </Text>
          </View>
        ) : null}

        <FlatList
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
          data={listData}
          keyExtractor={(item) => item.place_id}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => selectPlace(item)}
              style={({ pressed }) => [
                styles.item,
                pressed && styles.itemPressed,
              ]}
            >
              <View style={styles.itemIconWrap}>
                <Ionicons
                  name={
                    query.trim().length === 0
                      ? "time-outline"
                      : "location-outline"
                  }
                  size={18}
                  color={UI.colors.blue2}
                />
              </View>

              <Text style={styles.itemText} numberOfLines={2}>
                {item.description}
              </Text>
            </Pressable>
          )}
          contentContainerStyle={{
            paddingBottom: 8,
          }}
          showsVerticalScrollIndicator={false}
        />

        <View style={{ paddingBottom: insets.bottom + 12 }}>
          <Pressable
            onPress={confirm}
            disabled={!pickup.trim() || !dest.trim()}
            style={({ pressed }) => [
              styles.confirm,
              (!pickup.trim() || !dest.trim()) && { opacity: 0.45 },
              pressed && pickup.trim() && dest.trim() && styles.confirmPressed,
            ]}
          >
            <View style={styles.confirmGloss} />
            <View style={styles.confirmDepth} />
            <View style={styles.confirmInnerBorder} />
            <Text style={styles.confirmText}>Confirmar</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(244,248,255,0.12)",
  },

  overlay: {
    flex: 1,
    backgroundColor: UI.colors.overlay,
    paddingHorizontal: 16,
  },

  header: {
    marginBottom: 14,
  },

  title: {
    fontSize: 24,
    fontWeight: "900",
    color: UI.colors.text,
    letterSpacing: -0.2,
  },

  subTitle: {
    marginTop: 4,
    fontSize: 14,
    fontWeight: "700",
    color: UI.colors.muted,
  },

  favoriteLabel: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 2.2,
    color: "rgba(11,27,43,0.62)",
    marginBottom: 10,
    marginLeft: 2,
  },

  quickRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 18,
  },

  quickBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: UI.radius.lg,
    backgroundColor: "rgba(255,255,255,0.66)",
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.16)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.08,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 2,
  },

  quickText: {
    fontWeight: "800",
    color: UI.colors.text,
    fontSize: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  cardGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.25)",
    borderTopLeftRadius: UI.radius.xl,
    borderTopRightRadius: UI.radius.xl,
  },

  cardDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
    borderBottomLeftRadius: UI.radius.xl,
    borderBottomRightRadius: UI.radius.xl,
  },

  cardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  sectionLabel: {
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 3,
    color: "rgba(11,27,43,0.70)",
    marginBottom: 8,
  },

  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: UI.colors.surfaceStrong,
    paddingHorizontal: 12,
    height: 56,
    borderRadius: UI.radius.lg,
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
  },

  destRow: {
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },

  destInputWrap: {
    flex: 1,
  },

  inputRowActive: {
    borderColor: UI.colors.blueSoft2,
    backgroundColor: "#FFFFFF",
  },

  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },

  input: {
    flex: 1,
    fontSize: 15,
    fontWeight: "700",
    color: UI.colors.text,
  },

  stopBtnInline: {
    width: 132,
    height: 56,
    borderRadius: UI.radius.lg,
    backgroundColor: "#EAF3FF",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: UI.colors.blueSoft,
    flexDirection: "row",
    gap: 8,
  },

  stopPlus: {
    fontWeight: "900",
    fontSize: 26,
    color: UI.colors.blue2,
    marginTop: -1,
  },

  stopText: {
    fontWeight: "900",
    fontSize: 15,
    color: UI.colors.blue2,
  },

  stopsPreview: {
    marginTop: 12,
    borderRadius: 18,
    padding: 12,
    backgroundColor: "rgba(234,243,255,0.88)",
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.10)",
    gap: 8,
  },

  stopPreviewRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },

  stopPreviewDot: {
    width: 8,
    height: 8,
    borderRadius: 999,
    backgroundColor: UI.colors.blue2,
  },

  stopPreviewText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "700",
    color: UI.colors.text,
  },

  warn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.88)",
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
    marginBottom: 10,
  },

  warnText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "700",
    color: UI.colors.text,
  },

  item: {
    flexDirection: "row",
    gap: 10,
    padding: 12,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderRadius: UI.radius.lg,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
    alignItems: "center",
  },

  itemPressed: {
    transform: [{ scale: 0.992 }],
    opacity: 0.96,
  },

  itemIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: "rgba(43,122,230,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },

  itemText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "700",
    color: UI.colors.text,
  },

  confirm: {
    height: 58,
    borderRadius: UI.radius.pill,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 10,
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(255,255,255,0.72)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.28,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  confirmPressed: {
    transform: [{ scale: 0.97 }],
    shadowOpacity: 0.14,
  },

  confirmGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  confirmDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.12)",
  },

  confirmInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: UI.radius.pill,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
  },

  confirmText: {
    color: "#FFFFFF",
    fontWeight: "900",
    fontSize: 17,
    letterSpacing: 0.5,
  },

  pressedTiny: {
    transform: [{ scale: 0.985 }],
    opacity: 0.96,
  },
});

