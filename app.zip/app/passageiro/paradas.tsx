import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

const UI = {
  colors: {
    bg: "#F4F8FF",
    surface: "rgba(255,255,255,0.94)",
    surfaceStrong: "rgba(255,255,255,0.98)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(15,23,42,0.10)",
    borderSoft: "rgba(15,23,42,0.08)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    line: "rgba(255,255,255,0.72)",
    orange: "#FF7A59",
  },
  radius: {
    lg: 18,
    xl: 28,
    pill: 999,
  },
};

function normalizeParam(value: unknown) {
  if (typeof value === "string") return value;
  if (Array.isArray(value) && typeof value[0] === "string") return value[0];
  return "";
}

export default function Paradas() {
  const router = useRouter();
  const params = useLocalSearchParams();

  const initialStops = [
    normalizeParam(params.stop1),
    normalizeParam(params.stop2),
    normalizeParam(params.stop3),
    normalizeParam(params.stop4),
    normalizeParam(params.stop5),
  ];

  const [stops, setStops] = useState<string[]>(initialStops);

  const filledCount = useMemo(
    () => stops.filter((item) => item.trim().length > 0).length,
    [stops]
  );

  function updateStop(index: number, value: string) {
    setStops((prev) => prev.map((item, i) => (i === index ? value : item)));
  }

  function saveStops() {
    router.push({
      pathname: "/passageiro/busca",
      params: {
        stop1: stops[0]?.trim() || "",
        stop2: stops[1]?.trim() || "",
        stop3: stops[2]?.trim() || "",
        stop4: stops[3]?.trim() || "",
        stop5: stops[4]?.trim() || "",
      },
    });
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.topWrap}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <View style={styles.backGloss} />
            <Ionicons name="arrow-back" size={22} color={UI.colors.blue2} />
          </Pressable>

          <View style={styles.titleWrap}>
            <Text style={styles.eyebrow}>ROTA PREMIUM</Text>
            <Text style={styles.topTitle}>Adicionar paradas</Text>
            <Text style={styles.helper}>
              Você pode incluir até{" "}
              <Text style={styles.helperStrong}>5 paradas</Text> no trajeto.
            </Text>
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          <View style={styles.card}>
            <View style={styles.cardGloss} />
            <View style={styles.cardDepth} />
            <View style={styles.cardInnerBorder} />

            {stops.map((stop, index) => (
              <View key={index} style={styles.block}>
                <Text style={styles.sectionTitle}>PARADA {index + 1}</Text>

                <View style={styles.inputShell}>
                  <View style={styles.inputRow}>
                    <View style={styles.dot} />

                    <TextInput
                      value={stop}
                      onChangeText={(t) => updateStop(index, t)}
                      placeholder={`Digite a parada ${index + 1}`}
                      placeholderTextColor="rgba(11,27,43,0.35)"
                      style={styles.input}
                    />

                    {stop.length > 0 ? (
                      <Pressable onPress={() => updateStop(index, "")}>
                        <Ionicons
                          name="close-circle"
                          size={22}
                          color="rgba(11,27,43,0.30)"
                        />
                      </Pressable>
                    ) : null}
                  </View>
                </View>
              </View>
            ))}
          </View>

          <View style={styles.counterCard}>
            <View style={styles.counterGlow} />
            <Text style={styles.counterText}>
              {filledCount} parada{filledCount === 1 ? "" : "s"} preenchida
              {filledCount === 1 ? "" : "s"}
            </Text>
          </View>
        </ScrollView>

        <Pressable onPress={saveStops} style={({ pressed }) => [
          styles.confirm,
          pressed && styles.confirmPressed,
        ]}>
          <View style={styles.confirmGloss} />
          <View style={styles.confirmDepth} />
          <View style={styles.confirmInnerBorder} />
          <Text style={styles.confirmText}>Confirmar paradas</Text>
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  screen: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 18,
    backgroundColor: UI.colors.bg,
  },

  topWrap: {
    marginBottom: 14,
  },

  backBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.88)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.16)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.10,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 3,
    overflow: "hidden",
    marginBottom: 14,
  },

  backGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "52%",
    backgroundColor: "rgba(255,255,255,0.30)",
  },

  titleWrap: {
    paddingTop: 2,
  },

  eyebrow: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 2.8,
    color: "rgba(43,122,230,0.72)",
    marginBottom: 6,
  },

  topTitle: {
    fontSize: 28,
    fontWeight: "900",
    color: UI.colors.text,
    letterSpacing: -0.5,
  },

  helper: {
    marginTop: 6,
    fontSize: 14,
    color: UI.colors.muted,
    fontWeight: "700",
  },

  helperStrong: {
    color: UI.colors.text,
    fontWeight: "900",
  },

  scrollContent: {
    paddingBottom: 14,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 16,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 12 },
    elevation: 4,
  },

  cardGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  cardDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  cardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  block: {
    marginBottom: 14,
  },

  sectionTitle: {
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 2.4,
    color: "rgba(11,27,43,0.70)",
    marginBottom: 8,
  },

  inputShell: {
    borderRadius: UI.radius.lg,
    backgroundColor: "rgba(255,255,255,0.40)",
    padding: 2,
  },

  inputRow: {
    minHeight: 58,
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.surfaceStrong,
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.14)",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    gap: 10,
    shadowColor: "#FFFFFF",
    shadowOpacity: 0.25,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: -2 },
  },

  dot: {
    width: 11,
    height: 11,
    borderRadius: 999,
    backgroundColor: UI.colors.orange,
  },

  input: {
    flex: 1,
    color: UI.colors.text,
    fontSize: 15,
    fontWeight: "700",
  },

  counterCard: {
    marginTop: 14,
    borderRadius: 22,
    paddingVertical: 14,
    paddingHorizontal: 16,
    backgroundColor: "rgba(255,255,255,0.74)",
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.10)",
    overflow: "hidden",
  },

  counterGlow: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.22)",
  },

  counterText: {
    textAlign: "center",
    color: UI.colors.muted,
    fontWeight: "800",
    fontSize: 13,
  },

  confirm: {
    height: 60,
    borderRadius: UI.radius.pill,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(255,255,255,0.72)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.28,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  confirmPressed: {
    transform: [{ scale: 0.975 }],
  },

  confirmGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  confirmDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.12)",
  },

  confirmInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: UI.radius.pill,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
  },

  confirmText: {
    color: UI.colors.white,
    fontWeight: "900",
    fontSize: 17,
    letterSpacing: 0.3,
  },
});