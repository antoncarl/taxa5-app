import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Pressable,
    SafeAreaView,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";

type Params = { selected?: string };

type Method = {
  key: string;
  title: string;
  subtitle?: string;
};

export default function Pagamento() {
  const router = useRouter();
  const p = useLocalSearchParams<Params>();

  const [sel, setSel] = useState((p.selected ?? "Dinheiro").toString());

  const cards: Method[] = useMemo(
    () => [
      { key: "Saldo", title: "Saldo Taxa5", subtitle: "R$0,00 • saldo insuficiente" },
      { key: "5207", title: "Mastercard • 5207" },
      { key: "8688", title: "Visa • 8688" },
      { key: "3190", title: "Mastercard • 3190" },
      { key: "2837", title: "Mastercard • 2837" },
    ],
    []
  );

  const other: Method[] = useMemo(
    () => [
      { key: "Pix", title: "Pix (pré-pago)", subtitle: "Para esta opção, é necessário pagar antecipadamente" },
      { key: "Dinheiro", title: "Dinheiro" },
      { key: "Maquininha", title: "Maquininha de cartão" },
    ],
    []
  );

  function pick(m: string) {
    setSel(m);
    // volta pro corrida (aqui deixamos simples: volta e você enxerga “Dinheiro/Pix/Cartão” depois que eu integrar)
    router.back();
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.back} hitSlop={10}>
          <Ionicons name="chevron-back" size={22} color="#0B4FA3" />
        </Pressable>
        <Text style={styles.title}>Métodos de pagamento</Text>
      </View>

      <ScrollView contentContainerStyle={{ padding: 14, paddingBottom: 20 }}>
        <View style={styles.payBox}>
          <Text style={styles.boxTitle}>Taxa5 Pay</Text>

          <View style={styles.payCard}>
            <View style={styles.payBrand}>
              <Text style={styles.brandText}>Taxa5</Text>
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.payName}>Saldo Taxa5</Text>
              <Text style={styles.paySub}>R$0,00</Text>
              <View style={styles.negChip}>
                <Text style={styles.negText}>-R$4,00</Text>
              </View>
            </View>

            <Pressable style={styles.pixBtn}>
              <Text style={styles.pixText}>Depositar via Pix</Text>
            </Pressable>
          </View>
        </View>

        <View style={styles.section}>
          {cards.map((m) => (
            <Pressable key={m.key} onPress={() => pick(m.key)} style={styles.row}>
              <View style={styles.leftIcon}>
                <Ionicons name="card-outline" size={18} color="#0B4FA3" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle}>{m.title}</Text>
                {!!m.subtitle && <Text style={styles.rowSub}>{m.subtitle}</Text>}
              </View>
              <View style={[styles.radio, sel === m.key && styles.radioOn]}>
                {sel === m.key ? <View style={styles.radioDot} /> : null}
              </View>
            </Pressable>
          ))}
        </View>

        <View style={{ height: 10 }} />

        <View style={styles.section}>
          {other.map((m) => (
            <Pressable key={m.key} onPress={() => pick(m.key)} style={styles.row}>
              <View style={styles.leftIcon}>
                <Ionicons name="wallet-outline" size={18} color="#0B4FA3" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle}>{m.title}</Text>
                {!!m.subtitle && <Text style={styles.rowSub}>{m.subtitle}</Text>}
              </View>
              <View style={[styles.radio, sel === m.key && styles.radioOn]}>
                {sel === m.key ? <View style={styles.radioDot} /> : null}
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const ICE = "#F4F8FF";
const BORDER = "rgba(15, 23, 42, 0.08)";

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: ICE },

  header: {
    paddingHorizontal: 14,
    paddingTop: 8,
    paddingBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  back: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: BORDER,
  },
  title: { fontSize: 18, fontWeight: "900", color: "#0F172A" },

  payBox: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 22,
    padding: 12,
  },
  boxTitle: { fontSize: 14, fontWeight: "900", color: "#0F172A", marginBottom: 10 },

  payCard: {
    borderRadius: 20,
    borderWidth: 2,
    borderColor: "rgba(11,79,163,0.15)",
    backgroundColor: "#F8FBFF",
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  payBrand: {
    width: 46,
    height: 46,
    borderRadius: 16,
    backgroundColor: "#0B4FA3",
    alignItems: "center",
    justifyContent: "center",
  },
  brandText: { color: "#FFFFFF", fontWeight: "900" },
  payName: { fontSize: 16, fontWeight: "900", color: "#0F172A" },
  paySub: { marginTop: 4, fontSize: 12, fontWeight: "800", color: "#64748B" },
  negChip: {
    marginTop: 8,
    alignSelf: "flex-start",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(25,195,125,0.12)",
    borderWidth: 1,
    borderColor: "rgba(25,195,125,0.20)",
  },
  negText: { fontWeight: "900", color: "#0F7A50" },

  pixBtn: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: "#0B4FA3",
  },
  pixText: { color: "#FFFFFF", fontWeight: "900" },

  section: {
    marginTop: 14,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 22,
    padding: 10,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(15,23,42,0.06)",
  },
  leftIcon: {
    width: 38,
    height: 38,
    borderRadius: 14,
    backgroundColor: "#F1F6FF",
    borderWidth: 1,
    borderColor: "rgba(11,79,163,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  rowTitle: { fontSize: 14, fontWeight: "900", color: "#0F172A" },
  rowSub: { marginTop: 2, fontSize: 12, fontWeight: "700", color: "#64748B" },

  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: "rgba(15,23,42,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  radioOn: { borderColor: "#0B4FA3" },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#0B4FA3" },
});