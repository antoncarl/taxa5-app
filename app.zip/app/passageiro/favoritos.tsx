import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Alert,
    KeyboardAvoidingView,
    Platform,
    Pressable,
    SafeAreaView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";
import { useFavoritesStore, type FavoriteSlot } from "../../store/favoritesStore";

const UI = {
  colors: {
    bg: "#F4F8FF",
    surface: "rgba(255,255,255,0.94)",
    surfaceStrong: "rgba(255,255,255,0.98)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(15,23,42,0.10)",
    borderSoft: "rgba(15,23,42,0.08)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    line: "rgba(255,255,255,0.72)",
    shadow: "rgba(31,102,209,0.20)",
  },
  radius: {
    lg: 18,
    xl: 26,
    pill: 999,
  },
};

function getIconName(label: string) {
  const normalized = label.trim().toLowerCase();

  if (normalized === "casa") return "home";
  if (normalized === "trabalho") return "briefcase";

  return "star";
}

export default function Favoritos() {
  const router = useRouter();
  const params = useLocalSearchParams<{ slot?: FavoriteSlot }>();

  const slot: FavoriteSlot =
    params.slot === "trabalho" ? "trabalho" : "casa";

  const favorite = useFavoritesStore((s) =>
    slot === "trabalho" ? s.trabalho : s.casa
  );
  const setFavorite = useFavoritesStore((s) => s.setFavorite);

  const [label, setLabel] = useState(favorite.label);
  const [address, setAddress] = useState(favorite.address);

  const title = useMemo(() => {
    if (slot === "casa") return "Editar favorito Casa";
    return "Editar favorito Trabalho";
  }, [slot]);

  function save() {
    if (!label.trim()) {
      Alert.alert("Falta o nome", "Digite um nome para esse favorito.");
      return;
    }

    if (!address.trim()) {
      Alert.alert("Falta o endereço", "Digite o endereço do favorito.");
      return;
    }

    setFavorite(slot, {
      label: label.trim(),
      address: address.trim(),
    });

    router.back();
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.screen}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.topBar}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={UI.colors.blue2} />
          </Pressable>

          <Text style={styles.topTitle}>{title}</Text>

          <View style={{ width: 44 }} />
        </View>

        <View style={styles.card}>
          <View style={styles.cardGloss} />
          <View style={styles.cardDepth} />
          <View style={styles.cardInnerBorder} />

          <Text style={styles.sectionTitle}>Nome do favorito</Text>

          <View style={styles.inputRow}>
            <View style={styles.iconWrap}>
              <Ionicons
                name={getIconName(label)}
                size={18}
                color={UI.colors.blue2}
              />
            </View>

            <TextInput
              value={label}
              onChangeText={setLabel}
              placeholder="Ex.: Casa, Trabalho, Apartamento, Mãe..."
              placeholderTextColor="rgba(11,27,43,0.35)"
              style={styles.input}
            />
          </View>

          <View style={{ height: 16 }} />

          <Text style={styles.sectionTitle}>Endereço</Text>

          <View style={[styles.inputRow, styles.inputRowTall]}>
            <View style={styles.iconWrap}>
              <Ionicons
                name="location-outline"
                size={18}
                color={UI.colors.blue2}
              />
            </View>

            <TextInput
              value={address}
              onChangeText={setAddress}
              placeholder="Digite o endereço completo"
              placeholderTextColor="rgba(11,27,43,0.35)"
              style={[styles.input, { textAlignVertical: "top" }]}
              multiline
            />
          </View>
        </View>

        <Pressable onPress={save} style={({ pressed }) => [
          styles.confirm,
          pressed && styles.confirmPressed,
        ]}>
          <View style={styles.confirmGloss} />
          <View style={styles.confirmDepth} />
          <View style={styles.confirmInnerBorder} />
          <Text style={styles.confirmText}>Salvar favorito</Text>
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  screen: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 18,
    backgroundColor: UI.colors.bg,
  },

  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    backgroundColor: "rgba(255,255,255,0.82)",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
  },

  topTitle: {
    flex: 1,
    textAlign: "center",
    fontSize: 18,
    fontWeight: "900",
    color: UI.colors.text,
    marginHorizontal: 10,
  },

  card: {
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 16,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.10,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 4,
  },

  cardGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  cardDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  cardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  sectionTitle: {
    fontSize: 13,
    fontWeight: "900",
    letterSpacing: 2.2,
    color: "rgba(11,27,43,0.70)",
    marginBottom: 10,
  },

  inputRow: {
    minHeight: 58,
    borderRadius: UI.radius.lg,
    backgroundColor: UI.colors.surfaceStrong,
    borderWidth: 1,
    borderColor: UI.colors.borderSoft,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    gap: 10,
  },

  inputRowTall: {
    minHeight: 110,
    alignItems: "flex-start",
    paddingTop: 12,
  },

  iconWrap: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: "rgba(43,122,230,0.10)",
    alignItems: "center",
    justifyContent: "center",
    marginTop: 1,
  },

  input: {
    flex: 1,
    color: UI.colors.text,
    fontSize: 16,
    fontWeight: "700",
  },

  confirm: {
    marginTop: 22,
    height: 58,
    borderRadius: UI.radius.pill,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(255,255,255,0.72)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.28,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  confirmPressed: {
    transform: [{ scale: 0.97 }],
  },

  confirmGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  confirmDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.12)",
  },

  confirmInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: UI.radius.pill,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
  },

  confirmText: {
    color: UI.colors.white,
    fontWeight: "900",
    fontSize: 17,
    letterSpacing: 0.3,
  },
});