import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo, useState } from "react";
import {
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.60)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
  },
  radius: { lg: 18, xl: 22 },
};

export default function TermosPassageiro() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  // ✅ Por enquanto: não bloquear (você pediu pra deixar seguir livre)
  const [accepted, setAccepted] = useState(false);

  const [fontsLoaded] = useFonts({
    Cinzel_700Bold,
  });

  const titleFont = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : null),
    [fontsLoaded]
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 10 }]}>
      <Text style={[styles.title, titleFont]}>Termos de Aceite</Text>
      <Text style={styles.sub}>
        Passageiro • Taxa 5 Tecnologia LTDA • Security Sentinel Protocol
      </Text>

      <View style={styles.card}>
        <ScrollView
          contentContainerStyle={{ paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.h}>
            1) Finalidade e Consentimento
          </Text>
          <Text style={styles.p}>
            Ao se cadastrar, você concorda com a coleta e processamento de dados
            necessários para operar o aplicativo, prevenir fraudes e garantir
            segurança das viagens.
          </Text>

          <Text style={styles.h}>
            2) Documentos, Selfie e Verificação Antifraude
          </Text>
          <Text style={styles.p}>
            O cadastro poderá incluir envio de documento de identidade (frente e verso),
            selfie e prova de vida (ex.: piscar / mover a cabeça). Essas evidências são
            usadas para reduzir fraudes e aumentar a segurança de motoristas e passageiros.
          </Text>

          <Text style={styles.h}>
            3) Armazenamento Criptografado (Sentinel Protocol)
          </Text>
          <Text style={styles.p}>
            Os arquivos enviados podem ser armazenados em nuvem com criptografia e trilha
            de auditoria (“cadeia de custódia”) para eventual necessidade legal.
          </Text>

          <Text style={styles.h}>
            4) Uso em Caso de Investigação
          </Text>
          <Text style={styles.p}>
            Em situações de investigação criminal e mediante solicitação de autoridade competente,
            os registros e evidências poderão ser disponibilizados conforme a lei.
          </Text>

          <Text style={styles.h}>
            5) Responsabilidades do Usuário
          </Text>
          <Text style={styles.p}>
            Você se compromete a fornecer informações verdadeiras, não usar dados de terceiros
            sem autorização e respeitar as regras de conduta da plataforma.
          </Text>

          <Text style={styles.h}>
            6) Política de Privacidade e Atualizações
          </Text>
          <Text style={styles.p}>
            Estes termos podem ser atualizados. Você será informado quando houver mudanças relevantes.
          </Text>

          <View style={{ height: 12 }} />
        </ScrollView>

        {/* Aceite (por enquanto não é obrigatório) */}
        <Pressable
          onPress={() => setAccepted((v) => !v)}
          style={[
            styles.acceptBox,
            accepted && { borderColor: "rgba(31,102,209,0.45)" },
          ]}
        >
          <View style={[styles.checkbox, accepted && styles.checkboxOn]}>
            {accepted ? <Text style={styles.check}>✓</Text> : null}
          </View>
          <Text style={styles.acceptText}>
            Li e aceito os termos de uso e condições.
          </Text>
        </Pressable>
      </View>

      <View style={{ height: 14 }} />

      <Pressable
        onPress={() => router.back()} // volta pra página 3
        style={styles.btn}
      >
        <Text style={styles.btnText}>Voltar</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 16,
  },

  title: {
    fontSize: 22,
    color: UI.colors.text,
    marginBottom: 6,
  },

  sub: {
    color: UI.colors.muted,
    fontWeight: "700",
    marginBottom: 14,
  },

  card: {
    flex: 1,
    backgroundColor: UI.colors.surface,
    borderRadius: UI.radius.xl,
    padding: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
  },

  h: {
    color: UI.colors.text,
    fontWeight: "900",
    marginTop: 10,
    marginBottom: 6,
  },

  p: {
    color: "rgba(11,27,43,0.78)",
    fontWeight: "600",
    lineHeight: 19,
  },

  acceptBox: {
    marginTop: 14,
    borderWidth: 1,
    borderColor: UI.colors.border,
    borderRadius: UI.radius.lg,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    backgroundColor: "rgba(234,243,255,0.65)",
  },

  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.25)",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },
  checkboxOn: {
    backgroundColor: UI.colors.blue2,
    borderColor: UI.colors.blue2,
  },
  check: { color: "#FFFFFF", fontWeight: "900" },

  acceptText: {
    flex: 1,
    color: UI.colors.text,
    fontWeight: "700",
  },

  btn: {
    height: 56,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },

  btnText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "900",
  },
});