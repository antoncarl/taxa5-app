import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Animated,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import MapView, {
  Marker,
  Polyline,
  PROVIDER_GOOGLE,
} from "react-native-maps";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useSession } from "../lib/session";
import { TESLA_DAY_STYLE } from "./mapStyles";

const UI = {
  colors: {
    bg: "#F4F8FF",
    surface: "rgba(255,255,255,0.94)",
    surfaceStrong: "rgba(255,255,255,0.98)",
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    border: "rgba(15,23,42,0.10)",
    line: "rgba(255,255,255,0.72)",
    danger: "#D92D20",
    success: "#16A34A",
    cardShadow: "rgba(17,24,39,0.12)",
  },
  radius: {
    lg: 18,
    xl: 24,
    pill: 999,
  },
};

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export default function Tracking() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const { ride, driverUpdatePos, cancelRide, finishRide } = useSession();

  const mapRef = useRef<MapView>(null);
  const [localDriver, setLocalDriver] = useState(ride.driverPos);

  const pressAnimLeft = useRef(new Animated.Value(0)).current;
  const pressAnimRight = useRef(new Animated.Value(0)).current;

  const pickup = ride.pickup;
  const dest = ride.destination;

  const statusText = useMemo(() => {
    switch (ride.status) {
      case "waiting_driver":
        return "Procurando motorista…";
      case "driver_arriving":
        return "Motorista a caminho do embarque";
      case "accepted":
        return "Corrida aceita";
      case "on_trip":
        return "Em viagem";
      case "finished":
        return "Finalizada";
      case "cancelled":
        return "Cancelada";
      default:
        return "Aguardando…";
    }
  }, [ride.status]);

  const etaText = useMemo(() => {
    switch (ride.status) {
      case "waiting_driver":
        return "Buscando disponibilidade";
      case "driver_arriving":
        return "Chegada estimada em instantes";
      case "accepted":
        return "Motorista confirmado";
      case "on_trip":
        return "Rota em andamento";
      case "finished":
        return "Viagem concluída";
      case "cancelled":
        return "Corrida cancelada";
      default:
        return "Atualizando status";
    }
  }, [ride.status]);

  useEffect(() => {
    if (!pickup) return;

    const t = setTimeout(() => {
      mapRef.current?.animateCamera(
        {
          center: pickup,
          pitch: 62,
          heading: 8,
          altitude: 850,
        },
        { duration: 800 }
      );
    }, 250);

    return () => clearTimeout(t);
  }, [pickup]);

  useEffect(() => {
    if (!pickup || !dest) return;
    if (!ride.driverPos) return;

    setLocalDriver(ride.driverPos);

    const start = ride.driverPos;
    const end = pickup;

    let t = 0;
    const id = setInterval(() => {
      t += 0.035;
      const nt = Math.min(t, 1);

      const p = {
        latitude: lerp(start.latitude, end.latitude, nt),
        longitude: lerp(start.longitude, end.longitude, nt),
      };

      setLocalDriver(p);
      driverUpdatePos(p);

      mapRef.current?.animateCamera(
        {
          center: p,
          pitch: 60,
          heading: 10,
          altitude: 950,
        },
        { duration: 500 }
      );

      if (nt >= 1) {
        clearInterval(id);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

        setTimeout(() => {
          const start2 = end;
          const end2 = dest;
          let t2 = 0;

          const id2 = setInterval(() => {
            t2 += 0.03;
            const nt2 = Math.min(t2, 1);

            const p2 = {
              latitude: lerp(start2.latitude, end2.latitude, nt2),
              longitude: lerp(start2.longitude, end2.longitude, nt2),
            };

            setLocalDriver(p2);
            driverUpdatePos(p2);

            mapRef.current?.animateCamera(
              {
                center: p2,
                pitch: 60,
                heading: 12,
                altitude: 900,
              },
              { duration: 500 }
            );

            if (nt2 >= 1) {
              clearInterval(id2);
              finishRide();
            }
          }, 420);
        }, 1200);
      }
    }, 420);

    return () => clearInterval(id);
  }, [
    ride.driverPos?.latitude,
    ride.driverPos?.longitude,
    pickup?.latitude,
    dest?.latitude,
    pickup,
    dest,
    driverUpdatePos,
    finishRide,
  ]);

  if (!pickup || !dest) {
    return (
      <View style={styles.center}>
        <Text style={styles.emptyTitle}>Falta embarque ou destino</Text>

        <Pressable
          onPress={() => router.replace("/passageiro/home")}
          style={({ pressed }) => [
            styles.emptyBtn,
            pressed && styles.buttonPressed,
          ]}
        >
          <View style={styles.ctaGloss} />
          <View style={styles.ctaDepth} />
          <View style={styles.ctaInnerBorder} />
          <Text style={styles.emptyBtnText}>Voltar</Text>
        </Pressable>
      </View>
    );
  }

  const line = [pickup, dest];
  const driverLine = localDriver ? [localDriver, pickup] : [pickup];

  return (
    <View style={styles.screen}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={StyleSheet.absoluteFillObject}
        initialRegion={{
          latitude: pickup.latitude,
          longitude: pickup.longitude,
          latitudeDelta: 0.03,
          longitudeDelta: 0.03,
        }}
        customMapStyle={TESLA_DAY_STYLE}
        showsUserLocation={false}
        showsMyLocationButton={false}
        showsCompass={false}
        toolbarEnabled={false}
        zoomControlEnabled={false}
        rotateEnabled
        pitchEnabled
        moveOnMarkerPress={false}
        showsBuildings
        renderToHardwareTextureAndroid
        cacheEnabled={false}
        loadingEnabled
      >
        <Marker coordinate={pickup} title="Embarque" pinColor="#19C37D" />
        <Marker coordinate={dest} title="Destino" pinColor="#1F2A37" />

        {localDriver ? (
          <Polyline
            coordinates={driverLine}
            strokeWidth={5}
            strokeColor="rgba(43,122,230,0.55)"
            lineDashPattern={[8, 8]}
          />
        ) : null}

        <Polyline coordinates={line} strokeWidth={6} strokeColor="#1F66D1" />

        {localDriver ? (
          <Marker
            coordinate={localDriver}
            title="Motorista"
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View style={styles.driverMarker}>
              <Ionicons name="car-sport" size={18} color="#FFFFFF" />
            </View>
          </Marker>
        ) : null}
      </MapView>

      <View pointerEvents="none" style={styles.mapOverlay} />

      <View style={[styles.topGlass, { top: insets.top + 10 }]}>
        <View style={styles.topGloss} />
        <View style={styles.topDepth} />
        <View style={styles.topInnerBorder} />

        <Text style={styles.status}>{statusText}</Text>

        <Text style={styles.sub}>
          {ride.driverName
            ? `${ride.driverName} • ${ride.driverCar}`
            : "Aguardando motorista aceitar…"}
        </Text>

        <View style={styles.metaRow}>
          <View style={styles.liveRow}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>Atualização em tempo real</Text>
          </View>

          <Text style={styles.etaText}>{etaText}</Text>
        </View>
      </View>

      <View style={[styles.bottomCard, { bottom: insets.bottom + 88 }]}>
        <View style={styles.bottomCardGloss} />
        <View style={styles.bottomCardDepth} />
        <View style={styles.bottomCardInnerBorder} />

        <View style={styles.tripHeader}>
          <View>
            <Text style={styles.tripTitle}>Corrida em andamento</Text>
            <Text style={styles.tripSub}>
              {ride.driverName ? `${ride.driverName} está na rota` : "Atualizando dados da corrida"}
            </Text>
          </View>

          <View style={styles.badge}>
            <Ionicons name="shield-checkmark" size={14} color="#1F66D1" />
            <Text style={styles.badgeText}>Seguro</Text>
          </View>
        </View>

        <View style={styles.locationsBlock}>
          <View style={styles.locationRow}>
            <View style={[styles.locationDot, { backgroundColor: "#19C37D" }]} />
            <Text style={styles.locationText} numberOfLines={1}>
              Embarque confirmado
            </Text>
          </View>

          <View style={styles.locationDivider} />

          <View style={styles.locationRow}>
            <View style={[styles.locationDot, { backgroundColor: "#FF7A59" }]} />
            <Text style={styles.locationText} numberOfLines={1}>
              Destino definido
            </Text>
          </View>
        </View>
      </View>

      <View style={[styles.bottom, { bottom: insets.bottom + 12 }]}>
        <AnimatedActionButton
          title="Cancelar"
          kind="danger"
          anim={pressAnimLeft}
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            cancelRide();
            router.replace("/passageiro/home");
          }}
        />

        <AnimatedActionButton
          title="Tela inicial"
          kind="primary"
          anim={pressAnimRight}
          onPress={() => router.replace("/passageiro/home")}
        />
      </View>
    </View>
  );
}

function AnimatedActionButton({
  title,
  onPress,
  kind,
  anim,
}: {
  title: string;
  onPress: () => void;
  kind: "primary" | "danger";
  anim: Animated.Value;
}) {
  const scale = anim.interpolate({
    inputRange: [0, 1],
    outputRange: [1, 0.97],
  });

  return (
    <Animated.View style={{ flex: 1, transform: [{ scale }] }}>
      <Pressable
        onPressIn={() =>
          Animated.timing(anim, {
            toValue: 1,
            duration: 90,
            useNativeDriver: true,
          }).start()
        }
        onPressOut={() =>
          Animated.timing(anim, {
            toValue: 0,
            duration: 140,
            useNativeDriver: true,
          }).start()
        }
        onPress={onPress}
        style={[
          styles.action,
          kind === "danger" ? styles.cancel : styles.ok,
        ]}
      >
        <View style={styles.actionGloss} />
        <View style={styles.actionDepth} />
        <View style={styles.actionInnerBorder} />
        <Text
          style={[
            styles.actionTxt,
            kind === "danger" && styles.actionTxtDanger,
          ]}
        >
          {title}
        </Text>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
  },

  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(244,248,255,0.08)",
  },

  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
    backgroundColor: UI.colors.bg,
  },

  emptyTitle: {
    fontSize: 20,
    fontWeight: "900",
    color: UI.colors.text,
    marginBottom: 16,
    textAlign: "center",
  },

  emptyBtn: {
    minWidth: 180,
    height: 56,
    borderRadius: 22,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderWidth: 1.4,
    borderColor: "rgba(255,255,255,0.72)",
    shadowColor: UI.colors.blue2,
    shadowOpacity: 0.24,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },

  emptyBtnText: {
    color: UI.colors.white,
    fontWeight: "900",
    fontSize: 16,
  },

  topGlass: {
    position: "absolute",
    left: 16,
    right: 16,
    borderRadius: UI.radius.xl,
    padding: 14,
    backgroundColor: UI.colors.surface,
    borderWidth: 1,
    borderColor: UI.colors.border,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 10 },
    elevation: 6,
  },

  topGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.26)",
  },

  topDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  topInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: UI.colors.line,
  },

  status: {
    fontSize: 17,
    fontWeight: "900",
    color: UI.colors.text,
  },

  sub: {
    marginTop: 6,
    fontWeight: "800",
    color: "#5F7388",
    fontSize: 14,
  },

  metaRow: {
    marginTop: 10,
    gap: 6,
  },

  liveRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  liveDot: {
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: UI.colors.success,
    marginRight: 8,
  },

  liveText: {
    fontSize: 12,
    fontWeight: "800",
    color: UI.colors.muted,
  },

  etaText: {
    fontSize: 12,
    fontWeight: "800",
    color: "#5F7388",
  },

  bottomCard: {
    position: "absolute",
    left: 16,
    right: 16,
    borderRadius: 24,
    padding: 14,
    backgroundColor: "rgba(255,255,255,0.95)",
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.10)",
    overflow: "hidden",
    shadowColor: UI.colors.cardShadow,
    shadowOpacity: 1,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
    elevation: 8,
  },

  bottomCardGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.30)",
  },

  bottomCardDepth: {
    position: "absolute",
    bottom: -10,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.04)",
  },

  bottomCardInnerBorder: {
    position: "absolute",
    top: 4,
    left: 4,
    right: 4,
    bottom: 4,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.55)",
  },

  tripHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 10,
  },

  tripTitle: {
    fontSize: 16,
    fontWeight: "900",
    color: UI.colors.text,
  },

  tripSub: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: "700",
    color: "#5F7388",
  },

  badge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "rgba(43,122,230,0.10)",
    borderWidth: 1,
    borderColor: "rgba(43,122,230,0.16)",
  },

  badgeText: {
    color: "#1F66D1",
    fontWeight: "900",
    fontSize: 12,
  },

  locationsBlock: {
    marginTop: 14,
    padding: 12,
    borderRadius: 18,
    backgroundColor: "rgba(244,248,255,0.90)",
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.06)",
  },

  locationRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  locationDot: {
    width: 10,
    height: 10,
    borderRadius: 999,
    marginRight: 10,
  },

  locationText: {
    flex: 1,
    color: UI.colors.text,
    fontSize: 14,
    fontWeight: "800",
  },

  locationDivider: {
    height: 14,
    width: 1,
    backgroundColor: "rgba(15,23,42,0.10)",
    marginLeft: 4,
    marginVertical: 6,
  },

  bottom: {
    position: "absolute",
    left: 16,
    right: 16,
    flexDirection: "row",
    gap: 12,
  },

  action: {
    height: 56,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
    borderWidth: 1.2,
  },

  cancel: {
    backgroundColor: "rgba(217,45,32,0.16)",
    borderColor: "rgba(217,45,32,0.28)",
  },

  ok: {
    backgroundColor: "rgba(43,122,230,0.14)",
    borderColor: "rgba(43,122,230,0.24)",
  },

  actionGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "48%",
    backgroundColor: "rgba(255,255,255,0.22)",
  },

  actionDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "34%",
    backgroundColor: "rgba(0,0,0,0.05)",
  },

  actionInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.38)",
  },

  actionTxt: {
    fontWeight: "900",
    color: UI.colors.text,
    fontSize: 15,
  },

  actionTxtDanger: {
    color: "#8E1C13",
  },

  ctaGloss: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: "50%",
    backgroundColor: "rgba(255,255,255,0.24)",
  },

  ctaDepth: {
    position: "absolute",
    bottom: -8,
    left: 0,
    right: 0,
    height: "36%",
    backgroundColor: "rgba(0,0,0,0.12)",
  },

  ctaInnerBorder: {
    position: "absolute",
    top: 3,
    left: 3,
    right: 3,
    bottom: 3,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
  },

  buttonPressed: {
    transform: [{ scale: 0.97 }],
  },

  driverMarker: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#1F66D1",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
    borderColor: "#FFFFFF",
    shadowColor: "#1F66D1",
    shadowOpacity: 0.28,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
});