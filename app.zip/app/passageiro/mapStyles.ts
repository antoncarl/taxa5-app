import type { MapStyleElement } from "react-native-maps";

export const TESLA_DAY_STYLE: MapStyleElement[] = [
  { featureType: "poi", elementType: "all", stylers: [{ visibility: "off" }] },
  { featureType: "transit", elementType: "all", stylers: [{ visibility: "off" }] },

  { featureType: "water", elementType: "geometry", stylers: [{ color: "#D6ECFF" }] },
  { featureType: "landscape", elementType: "geometry", stylers: [{ color: "#F2F7FF" }] },

  { featureType: "road", elementType: "geometry", stylers: [{ color: "#FFFFFF" }] },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#D7E6F7" }, { weight: 1.2 }],
  },

  { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#EAF3FF" }] },
  {
    featureType: "road.highway",
    elementType: "geometry.stroke",
    stylers: [{ color: "#BFD7FF" }, { weight: 1.4 }],
  },

  {
    featureType: "administrative",
    elementType: "labels.text.fill",
    stylers: [{ color: "#6B7280" }],
  },
  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#4B5563" }],
  },
  { featureType: "road", elementType: "labels.icon", stylers: [{ visibility: "off" }] },
];

export const SEARCH_2D_STYLE: MapStyleElement[] = [
  { featureType: "poi", elementType: "all", stylers: [{ visibility: "off" }] },
  { featureType: "transit", elementType: "all", stylers: [{ visibility: "off" }] },

  { featureType: "water", elementType: "geometry", stylers: [{ color: "#DCEEFF" }] },
  { featureType: "landscape", elementType: "geometry", stylers: [{ color: "#F2F7FF" }] },

  { featureType: "road", elementType: "geometry", stylers: [{ color: "#FFFFFF" }] },
  {
    featureType: "road",
    elementType: "geometry.stroke",
    stylers: [{ color: "#DDE9F7" }, { weight: 1.1 }],
  },

  {
    featureType: "road",
    elementType: "labels.text.fill",
    stylers: [{ color: "#556070" }],
  },
  { featureType: "road", elementType: "labels.icon", stylers: [{ visibility: "off" }] },
];