import { Ionicons } from "@expo/vector-icons";
import { Audio } from "expo-av";
import * as MediaLibrary from "expo-media-library";
import { useRouter } from "expo-router";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import React, { useEffect, useRef, useState } from "react";
import {
    Pressable,
    SafeAreaView,
    StyleSheet,
    Text,
    View,
} from "react-native";
import { storage } from "../../src/lib/firebase";

export default function GravarAudio() {
  const router = useRouter();

  const recordingRef = useRef<Audio.Recording | null>(null);

  const [status, setStatus] = useState("Preparando gravação...");
  const [isRecording, setIsRecording] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    startRecording();

    return () => {
      cleanupRecording();
    };
  }, []);

  async function cleanupRecording() {
    try {
      if (recordingRef.current) {
        const rs = await recordingRef.current.getStatusAsync();
        if (rs.isRecording) {
          await recordingRef.current.stopAndUnloadAsync();
        }
      }
    } catch {}
  }

  async function uploadFileToSentinel(uri: string) {
    const response = await fetch(uri);
    const blob = await response.blob();

    const fileName = `sentinel/audio_${Date.now()}.m4a`;
    const fileRef = ref(storage, fileName);

    await uploadBytes(fileRef, blob, {
      contentType: "audio/m4a",
    });

    return await getDownloadURL(fileRef);
  }

  async function startRecording() {
    try {
      setStatus("Solicitando permissões...");

      const audioPermission = await Audio.requestPermissionsAsync();
      const mediaPermission = await MediaLibrary.requestPermissionsAsync();

      if (!audioPermission.granted || !mediaPermission.granted) {
        setStatus("Permissão negada");
        return;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      setStatus("Gravando...");
      setIsRecording(true);

      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY
      );

      recordingRef.current = recording;
    } catch {
      setStatus("Erro ao iniciar gravação");
      setIsRecording(false);
    }
  }

  async function stopRecording() {
    try {
      if (!recordingRef.current) return;

      setIsSaving(true);
      setStatus("Salvando...");

      await recordingRef.current.stopAndUnloadAsync();
      const uri = recordingRef.current.getURI();

      if (!uri) {
        setStatus("Arquivo não encontrado");
        setIsSaving(false);
        setIsRecording(false);
        return;
      }

      await MediaLibrary.saveToLibraryAsync(uri);

      setStatus("Enviando para Sentinel...");
      const url = await uploadFileToSentinel(uri);

      setStatus("Áudio salvo no aparelho e enviado para Sentinel");
      console.log("Sentinel URL:", url);

      setIsRecording(false);
      setIsSaving(false);
      recordingRef.current = null;
    } catch (error) {
      console.log(error);
      setStatus("Erro ao salvar ou enviar");
      setIsSaving(false);
      setIsRecording(false);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.container}>
        <View style={styles.badge}>
          <Ionicons name="mic-outline" size={26} color="#FFD84D" />
        </View>

        <Text style={styles.title}>Gravação de áudio</Text>
        <Text style={styles.status}>{status}</Text>

        <Pressable
          onPress={stopRecording}
          disabled={!isRecording || isSaving}
          style={({ pressed }) => [
            styles.mainButton,
            (!isRecording || isSaving) && { opacity: 0.5 },
            pressed && isRecording && !isSaving && { transform: [{ scale: 0.97 }] },
          ]}
        >
          <Text style={styles.mainButtonText}>
            {isSaving ? "Salvando..." : isRecording ? "Parar gravação" : "Finalizado"}
          </Text>
        </Pressable>

        <Pressable onPress={() => router.back()} style={styles.secondaryButton}>
          <Text style={styles.secondaryButtonText}>Voltar</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#F4F8FF",
  },
  container: {
    flex: 1,
    padding: 24,
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    width: 72,
    height: 72,
    borderRadius: 22,
    backgroundColor: "#2B7AE6",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 18,
  },
  title: {
    fontSize: 24,
    fontWeight: "900",
    color: "#0B1B2B",
  },
  status: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: "700",
    color: "#5F7388",
    textAlign: "center",
    marginBottom: 28,
  },
  mainButton: {
    width: "100%",
    height: 58,
    borderRadius: 999,
    backgroundColor: "#D92D20",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 14,
  },
  mainButtonText: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "900",
  },
  secondaryButton: {
    width: "100%",
    height: 54,
    borderRadius: 999,
    backgroundColor: "#2B7AE6",
    alignItems: "center",
    justifyContent: "center",
  },
  secondaryButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "900",
  },
});