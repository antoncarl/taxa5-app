import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useCallback, useMemo, useRef, useState } from "react";
import {
    FlatList,
    KeyboardAvoidingView,
    Platform,
    Pressable,
    SafeAreaView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";
import { auth } from "../../src/lib/firebase";

type Msg = {
  id: string;
  role: "user" | "assistant";
  text: string;
  createdAt: number;
};

const UI = {
  colors: {
    bg: "#EEF5FF",
    surface: "#FFFFFF",
    ink: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    border: "rgba(11,27,43,0.10)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    bubbleUser: "#2B7AE6",
    bubbleBot: "#FFFFFF",
  },
  radius: { xl: 22, lg: 18, md: 14, pill: 999 },
};

function uid() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

export default function ChatPro() {
  const router = useRouter();

  // ✅ depois você conecta com threadId real (corridaId etc.)
  const threadId = "taxa5_default";

  const [messages, setMessages] = useState<Msg[]>([
    {
      id: uid(),
      role: "assistant",
      text: "Chat Taxa5 PRO pronto. Envie texto, foto, áudio, PDF, Word, Excel.",
      createdAt: Date.now(),
    },
  ]);

  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);

  const listRef = useRef<FlatList<Msg>>(null);

  const canSend = useMemo(() => text.trim().length > 0 && !sending, [text, sending]);

  const scrollToEnd = useCallback(() => {
    requestAnimationFrame(() => {
      listRef.current?.scrollToOffset({ offset: 0, animated: true });
    });
  }, []);

  const sendText = useCallback(async () => {
    const msg = text.trim();
    if (!msg || sending) return;

    setSending(true);

    const mine: Msg = { id: uid(), role: "user", text: msg, createdAt: Date.now() };
    setMessages((prev) => [mine, ...prev]);
    setText("");
    scrollToEnd();

    try {
      const user = auth.currentUser;
      if (!user) {
        setMessages((prev) => [
          {
            id: uid(),
            role: "assistant",
            text: "Você precisa estar logado para usar o chat.",
            createdAt: Date.now(),
          },
          ...prev,
        ]);
        return;
      }

      const token = await user.getIdToken();

      // ✅ configure no .env: EXPO_PUBLIC_AI_BASE_URL=https://seu-backend.onrender.com
      const base = process.env.EXPO_PUBLIC_AI_BASE_URL || "";
      if (!base) {
        setMessages((prev) => [
          {
            id: uid(),
            role: "assistant",
            text: "Falta configurar EXPO_PUBLIC_AI_BASE_URL (URL do backend).",
            createdAt: Date.now(),
          },
          ...prev,
        ]);
        return;
      }

      const res = await fetch(`${base}/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          thread_id: threadId,
          message: msg,
          // file/mime/filename entram quando formos implementar anexos
        }),
      });

      const json = await res.json().catch(() => ({} as any));

      if (!res.ok) {
        const errText = json?.error || `Erro HTTP ${res.status}`;
        setMessages((prev) => [
          { id: uid(), role: "assistant", text: `Erro: ${errText}`, createdAt: Date.now() },
          ...prev,
        ]);
        return;
      }

      const reply = String(json?.reply || "").trim() || "Sem resposta agora.";
      setMessages((prev) => [
        { id: uid(), role: "assistant", text: reply, createdAt: Date.now() },
        ...prev,
      ]);
      scrollToEnd();
    } catch (e: any) {
      setMessages((prev) => [
        {
          id: uid(),
          role: "assistant",
          text: `Falha de rede: ${e?.message || "erro"}`,
          createdAt: Date.now(),
        },
        ...prev,
      ]);
    } finally {
      setSending(false);
    }
  }, [text, sending, scrollToEnd]);

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.safe}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}
      >
        {/* HEADER */}
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.iconBtn}>
            <Ionicons name="chevron-back" size={22} color={UI.colors.ink} />
          </Pressable>

          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>CHAT</Text>
            <Text style={styles.headerSub}>Taxa5 • Mensagens e anexos</Text>
          </View>

          {/* botões do topo (stub por enquanto) */}
          <Pressable onPress={() => {}} style={styles.iconBtn}>
            <Ionicons name="call-outline" size={20} color={UI.colors.blue2} />
          </Pressable>
          <Pressable onPress={() => {}} style={styles.iconBtn}>
            <Ionicons name="videocam-outline" size={20} color={UI.colors.blue2} />
          </Pressable>
        </View>

        {/* LISTA */}
        <FlatList
          ref={listRef}
          inverted
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <View
              style={[
                styles.row,
                item.role === "user" ? { justifyContent: "flex-end" } : { justifyContent: "flex-start" },
              ]}
            >
              <View
                style={[
                  styles.bubble,
                  item.role === "user" ? styles.bubbleUser : styles.bubbleBot,
                ]}
              >
                <Text
                  style={[
                    styles.bubbleText,
                    item.role === "user" ? { color: UI.colors.white } : { color: UI.colors.ink },
                  ]}
                >
                  {item.text}
                </Text>
              </View>
            </View>
          )}
        />

        {/* BARRA DE INPUT (não sobrepõe texto + cresce até 10 linhas) */}
        <View style={styles.composerWrap}>
          <View style={styles.composer}>
            {/* anexos (stub agora) */}
            <Pressable onPress={() => {}} style={styles.attachBtn}>
              <Ionicons name="add" size={22} color={UI.colors.blue2} />
            </Pressable>

            <TextInput
              value={text}
              onChangeText={setText}
              placeholder="Digite sua mensagem…"
              placeholderTextColor="rgba(11,27,43,0.35)"
              style={styles.input}
              multiline
              maxLength={6000}
              textAlignVertical="top"
              // ✅ deixa crescer (até ~10 linhas)
              scrollEnabled={false}
            />

            <Pressable
              onPress={sendText}
              disabled={!canSend}
              style={({ pressed }) => [
                styles.sendBtn,
                (!canSend || sending) && { opacity: 0.45 },
                pressed && canSend && { transform: [{ scale: 0.99 }] },
              ]}
            >
              <Ionicons name="send" size={18} color="#FFFFFF" />
            </Pressable>
          </View>

          <Text style={styles.hint}>
            {sending ? "Enviando…" : "Dica: o campo cresce e não corta o texto."}
          </Text>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: UI.colors.bg },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: "rgba(255,255,255,0.82)",
    borderBottomWidth: 1,
    borderBottomColor: UI.colors.border,
  },
  headerTitle: {
    fontFamily: "Cinzel_700Bold", // se não tiver, cai no padrão
    fontSize: 18,
    letterSpacing: 4,
    color: UI.colors.ink,
    textTransform: "uppercase",
  },
  headerSub: {
    marginTop: 2,
    fontSize: 12,
    color: UI.colors.muted,
    fontWeight: "600",
  },

  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginRight: 6,
    backgroundColor: "rgba(31,102,209,0.08)",
    borderWidth: 1,
    borderColor: "rgba(31,102,209,0.10)",
  },

  listContent: {
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 10,
  },

  row: {
    flexDirection: "row",
    marginVertical: 6,
  },

  bubble: {
    maxWidth: "82%",
    borderRadius: UI.radius.lg,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
  },
  bubbleUser: {
    backgroundColor: UI.colors.bubbleUser,
    borderColor: "rgba(255,255,255,0.22)",
  },
  bubbleBot: {
    backgroundColor: UI.colors.bubbleBot,
    borderColor: UI.colors.border,
  },
  bubbleText: {
    fontSize: 15,
    fontWeight: "600",
    lineHeight: 20,
  },

  composerWrap: {
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 10,
    borderTopWidth: 1,
    borderTopColor: UI.colors.border,
    backgroundColor: "rgba(255,255,255,0.92)",
  },

  composer: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 10,
    padding: 10,
    borderRadius: UI.radius.xl,
    borderWidth: 1,
    borderColor: UI.colors.border,
    backgroundColor: UI.colors.surface,
  },

  attachBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(31,102,209,0.10)",
    borderWidth: 1,
    borderColor: "rgba(31,102,209,0.12)",
  },

  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 44 + 9 * 22, // ~10 linhas visíveis (sem subir por trás)
    paddingTop: 10,
    paddingHorizontal: 10,
    paddingBottom: 10,
    borderRadius: 16,
    backgroundColor: "rgba(234,243,255,0.65)",
    borderWidth: 1,
    borderColor: "rgba(11,27,43,0.10)",
    color: UI.colors.ink,
    fontSize: 15,
    fontWeight: "600",
  },

  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: UI.colors.blue2,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.25)",
  },

  hint: {
    marginTop: 6,
    fontSize: 11,
    color: UI.colors.muted,
    fontWeight: "600",
    textAlign: "center",
  },
});