import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import PremiumButton from "./components/PremiumButton";

export default function RideRating() {
  const [rating, setRating] = useState<"up" | "down" | "neutral" | null>(null);

  function finishRide() {
    router.replace("/passageiro/PassageiroMap");
  }

  return (
    <View style={s.container}>
      <Text style={s.title}>AVALIAR CORRIDA</Text>

      <View style={{ height: 20 }} />

      <PremiumButton
        title="👍 JOINHA POSITIVO"
        onPress={() => setRating("up")}
      />

      <View style={{ height: 10 }} />

      <PremiumButton
        title="😐 JOINHA NEUTRO"
        onPress={() => setRating("neutral")}
      />

      <View style={{ height: 10 }} />

      <PremiumButton
        title="👎 JOINHA NEGATIVO"
        variant="danger"
        onPress={() => setRating("down")}
      />

      <View style={{ height: 20 }} />

      {rating && (
        <Text style={s.selected}>
          Avaliação registrada: {rating}
        </Text>
      )}

      <View style={{ height: 20 }} />

      <PremiumButton title="FINALIZAR" onPress={finishRide} />
    </View>
  );
}

const s = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 18,
    justifyContent: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "900",
    textAlign: "center",
  },
  selected: {
    textAlign: "center",
    fontWeight: "700",
  },
});
