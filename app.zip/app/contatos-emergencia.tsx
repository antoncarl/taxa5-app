import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useEffect, useMemo, useState } from "react";
import {
    Alert,
    Linking,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";
import PremiumButton from "./components/PremiumButton";

type Contact = { name: string; phone: string };

const KEY_CONTACTS = "@taxa5:emergencyContacts";
const KEY_SENTINEL_OPTIN = "@taxa5:sentinelCitizenOptIn";

function normalizePhoneBR(raw: string) {
  // mantém só números
  const digits = raw.replace(/\D/g, "");
  return digits;
}

async function callPhone(numberDigitsOnly: string) {
  const url = `tel:${numberDigitsOnly}`;
  const supported = await Linking.canOpenURL(url);
  if (!supported) {
    Alert.alert("Não foi possível ligar", "Seu aparelho não suporta chamadas por aqui.");
    return;
  }
  await Linking.openURL(url);
}

export default function ContatosEmergencia() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [draftName, setDraftName] = useState("");
  const [draftPhone, setDraftPhone] = useState("");
  const [citizenOptIn, setCitizenOptIn] = useState<boolean>(false);

  const canAdd = useMemo(() => {
    const n = draftName.trim();
    const p = normalizePhoneBR(draftPhone);
    return n.length >= 2 && p.length >= 8 && contacts.length < 10;
  }, [draftName, draftPhone, contacts.length]);

  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem(KEY_CONTACTS);
      if (raw) {
        try {
          const parsed = JSON.parse(raw) as Contact[];
          if (Array.isArray(parsed)) setContacts(parsed.slice(0, 10));
        } catch {}
      }
      const opt = await AsyncStorage.getItem(KEY_SENTINEL_OPTIN);
      setCitizenOptIn(opt === "1");
    })();
  }, []);

  async function persist(next: Contact[]) {
    setContacts(next);
    await AsyncStorage.setItem(KEY_CONTACTS, JSON.stringify(next));
  }

  async function addContact() {
    if (!canAdd) return;
    const name = draftName.trim();
    const phone = normalizePhoneBR(draftPhone);

    const next = [...contacts, { name, phone }].slice(0, 10);
    await persist(next);

    setDraftName("");
    setDraftPhone("");
  }

  async function removeContact(index: number) {
    Alert.alert("Remover contato", "Deseja remover este contato de emergência?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Remover",
        style: "destructive",
        onPress: async () => {
          const next = contacts.filter((_, i) => i !== index);
          await persist(next);
        },
      },
    ]);
  }

  async function toggleCitizenSentinel() {
    // o botão fica visível sempre; o aceite acontece aqui dentro
    if (!citizenOptIn) {
      Alert.alert(
        "Cidadão Sentinel",
        "Deseja ativar o modo Cidadão Sentinel?\n\nQuando alguém próximo (até 100m) estiver em perigo e permitir, você poderá receber um alerta com a localização em tempo real para chamar ajuda.",
        [
          { text: "Agora não", style: "cancel" },
          {
            text: "Aceito ativar",
            onPress: async () => {
              setCitizenOptIn(true);
              await AsyncStorage.setItem(KEY_SENTINEL_OPTIN, "1");
              Alert.alert("Ativado", "Você agora é um Cidadão Sentinel.");
            },
          },
        ]
      );
      return;
    }

    Alert.alert("Cidadão Sentinel", "Deseja desativar o modo Cidadão Sentinel?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Desativar",
        style: "destructive",
        onPress: async () => {
          setCitizenOptIn(false);
          await AsyncStorage.setItem(KEY_SENTINEL_OPTIN, "0");
        },
      },
    ]);
  }

  return (
    <ScrollView style={s.screen} contentContainerStyle={s.container}>
      <Text style={s.title}>EMERGÊNCIA</Text>
      <Text style={s.subtitle}>
        Ligue rápido e cadastre até 10 contatos para receberem seu alerta.
      </Text>

      {/* Serviços */}
      <View style={s.section}>
        <Text style={s.sectionTitle}>Serviços</Text>

        <View style={s.row}>
          <PremiumButton title="POLÍCIA (190)" onPress={() => callPhone("190")} variant="red" />
        </View>

        <View style={{ height: 10 }} />
        <View style={s.row}>
          <PremiumButton title="BOMBEIROS (193)" onPress={() => callPhone("193")} />
        </View>

        <View style={{ height: 10 }} />
        <View style={s.row}>
          <PremiumButton title="AMBULÂNCIA (192)" onPress={() => callPhone("192")} />
        </View>
      </View>

      {/* Cadastro de contatos */}
      <View style={s.section}>
        <Text style={s.sectionTitle}>Contatos de emergência</Text>

        <View style={s.formCard}>
          <Text style={s.label}>Nome</Text>
          <TextInput
            value={draftName}
            onChangeText={setDraftName}
            placeholder="Ex.: Pai"
            placeholderTextColor="#9aa3ad"
            style={s.input}
          />

          <Text style={[s.label, { marginTop: 10 }]}>Telefone</Text>
          <TextInput
            value={draftPhone}
            onChangeText={setDraftPhone}
            placeholder="Ex.: 11999999999"
            placeholderTextColor="#9aa3ad"
            keyboardType="phone-pad"
            style={s.input}
          />

          <View style={{ height: 12 }} />
          <PremiumButton
            title={contacts.length >= 10 ? "LIMITE 10 CONTATOS" : "SALVAR CONTATO"}
            onPress={addContact}
            disabled={!canAdd}
          />

          <Text style={s.hint}>
            Dica: ao salvar, o contato vira um botão. Ao clicar, liga direto.
          </Text>
        </View>

        {/* Botões dinâmicos dos contatos */}
        {contacts.length > 0 && (
          <View style={{ marginTop: 14 }}>
            {contacts.map((c, idx) => (
              <View key={`${c.phone}-${idx}`} style={{ marginBottom: 10 }}>
                <View style={s.contactRow}>
                  <View style={{ flex: 1 }}>
                    <PremiumButton
                      title={`${c.name.toUpperCase()} (${c.phone})`}
                      onPress={() => callPhone(c.phone)}
                    />
                  </View>
                  <Pressable onPress={() => removeContact(idx)} style={s.removeBtn}>
                    <Text style={s.removeText}>Remover</Text>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        )}

        <Text style={s.longHint}>
          Em caso de perigo real, o protocolo poderá escalar o alerta para todos os contatos ao
          mesmo tempo (localização em tempo real). Mais opções avançadas (SMS/WhatsApp/áudio/vídeo)
          entram na próxima etapa do Sentinel.
        </Text>
      </View>

      {/* Cidadão Sentinel */}
      <View style={s.section}>
        <Text style={s.sectionTitle}>Cidadão Sentinel</Text>
        <PremiumButton
          title={citizenOptIn ? "CIDADÃO SENTINEL: ATIVO ✅" : "CIDADÃO SENTINEL: ATIVAR"}
          onPress={toggleCitizenSentinel}
        />
        <Text style={s.hint}>
          Botão visível sempre. O aceite acontece ao clicar.
        </Text>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#fff" },
  container: { padding: 16, paddingBottom: 40 },

  title: { fontSize: 28, fontWeight: "900", color: "#0b4aa6", textAlign: "center", marginTop: 10 },
  subtitle: {
    marginTop: 8,
    fontSize: 13,
    fontWeight: "700",
    color: "#2f2f2f",
    textAlign: "center",
  },

  section: { marginTop: 22 },
  sectionTitle: { fontSize: 16, fontWeight: "900", color: "#0b4aa6", marginBottom: 10 },

  row: { width: "100%" },

  formCard: {
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#e6eef8",
    padding: 14,
    backgroundColor: "#fbfdff",
  },
  label: { fontSize: 12, fontWeight: "900", color: "#1f2937" },
  input: {
    marginTop: 6,
    borderWidth: 1,
    borderColor: "#d6e4f5",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: "#0f172a",
    backgroundColor: "#ffffff",
  },
  hint: { marginTop: 10, fontSize: 12, color: "#6b7280", fontWeight: "700" },
  longHint: { marginTop: 12, fontSize: 12, color: "#6b7280", lineHeight: 17 },

  contactRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  removeBtn: {
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#f3c6c6",
    backgroundColor: "#fff5f5",
  },
  removeText: { color: "#b91c1c", fontWeight: "900", fontSize: 12 },
});
