import * as Location from "expo-location";
import React, { useEffect, useRef, useState } from "react";
import { Platform, StyleSheet, Text, View } from "react-native";
import MapView, { Marker, PROVIDER_GOOGLE, Region } from "react-native-maps";
import { TESLA_DAY_STYLE } from "../passageiro/mapStyles";

const FALLBACK = {
  latitude: -23.55052,
  longitude: -46.633308,
};

export default function DriverMap() {
  const mapRef = useRef<MapView>(null);
  const watchRef = useRef<Location.LocationSubscription | null>(null);
  const lastCameraTsRef = useRef(0);

  const [driverPos, setDriverPos] = useState(FALLBACK);
  const [initialRegion] = useState<Region>({
    latitude: FALLBACK.latitude,
    longitude: FALLBACK.longitude,
    latitudeDelta: 0.012,
    longitudeDelta: 0.012,
  });

  const idlePitch = Platform.OS === "android" ? 66 : 62;
  const idleHeading = Platform.OS === "android" ? 16 : 10;
  const idleAltitude = 760;

  useEffect(() => {
    let mounted = true;

    const start = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();

        if (!mounted) return;

        mapRef.current?.animateCamera(
          {
            center: FALLBACK,
            pitch: idlePitch,
            altitude: idleAltitude,
            heading: idleHeading,
          },
          { duration: 700 }
        );

        if (status !== "granted") return;

        const current = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        if (!mounted) return;

        const firstPos = {
          latitude: current.coords.latitude,
          longitude: current.coords.longitude,
        };

        setDriverPos(firstPos);

        mapRef.current?.animateCamera(
          {
            center: firstPos,
            pitch: idlePitch,
            altitude: idleAltitude,
            heading: idleHeading,
          },
          { duration: 900 }
        );

        watchRef.current = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            timeInterval: 1500,
            distanceInterval: 8,
          },
          (pos) => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;

            if (!lat || !lng) return;

            setDriverPos((prev) => {
              const next = {
                latitude: prev.latitude + (lat - prev.latitude) * 0.35,
                longitude: prev.longitude + (lng - prev.longitude) * 0.35,
              };

              const now = Date.now();
              if (now - lastCameraTsRef.current > 1000) {
                lastCameraTsRef.current = now;

                mapRef.current?.animateCamera(
                  {
                    center: next,
                    pitch: idlePitch,
                    altitude: idleAltitude,
                    heading: idleHeading,
                  },
                  { duration: 650 }
                );
              }

              return next;
            });
          }
        );
      } catch {}
    };

    start();

    return () => {
      mounted = false;
      watchRef.current?.remove();
    };
  }, []);

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        provider={PROVIDER_GOOGLE}
        style={StyleSheet.absoluteFillObject}
        initialRegion={initialRegion}
        customMapStyle={TESLA_DAY_STYLE}
        mapType="standard"
        pitchEnabled
        rotateEnabled
        showsBuildings
        showsIndoors={false}
        showsUserLocation={false}
        showsMyLocationButton={false}
        showsCompass={false}
        showsScale={false}
        toolbarEnabled={false}
        zoomControlEnabled={false}
        moveOnMarkerPress={false}
        loadingEnabled
        renderToHardwareTextureAndroid={true}
        cacheEnabled={false}
      >
        <Marker coordinate={driverPos} title="Motorista" pinColor="#1F66D1" />
      </MapView>

      <View pointerEvents="none" style={styles.topBadge}>
        <Text style={styles.topBadgeText}>Modo motorista ativo</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F4F8FF",
  },

  topBadge: {
    position: "absolute",
    top: 24,
    alignSelf: "center",
    backgroundColor: "rgba(255,255,255,0.92)",
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "rgba(15,23,42,0.10)",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 5,
  },

  topBadgeText: {
    color: "#0B1B2B",
    fontWeight: "800",
    fontSize: 13,
  },
});