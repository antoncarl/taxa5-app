import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from "react-native";

export default function CadastroPassageiro() {
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");

  async function salvar() {
    if (!nome.trim() || !telefone.trim()) {
      Alert.alert("Faltou algo", "Preencha nome e telefone.");
      return;
    }
    const payload = { tipo: "passageiro", nome, telefone };
    await AsyncStorage.setItem("@taxa5:perfil", JSON.stringify(payload));

    // Por enquanto jogamos no mapa do motorista (MVP) — depois fazemos o mapa/tela do passageiro
    router.replace("/driver/DriverMap");
  }

  return (
    <View style={s.container}>
      <Text style={s.title}>Cadastro do Passageiro</Text>

      <TextInput style={s.input} placeholder="Nome" value={nome} onChangeText={setNome} />
      <TextInput style={s.input} placeholder="Telefone" value={telefone} onChangeText={setTelefone} keyboardType="phone-pad" />

      <Pressable style={s.btn} onPress={salvar}>
        <Text style={s.btnText}>Continuar</Text>
      </Pressable>

      <Pressable style={s.link} onPress={() => router.back()}>
        <Text style={s.linkText}>Voltar</Text>
      </Pressable>
    </View>
  );
}

const s = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: "center", gap: 12 },
  title: { fontSize: 22, fontWeight: "800", marginBottom: 8, textAlign: "center" },
  input: { borderWidth: 1, borderColor: "#e5e7eb", padding: 12, borderRadius: 12, fontSize: 16 },
  btn: { backgroundColor: "#111827", paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 6 },
  btnText: { color: "white", fontSize: 16, fontWeight: "700" },
  link: { alignItems: "center", marginTop: 8 },
  linkText: { color: "#2563eb", fontWeight: "700" },
});
