import AsyncStorage from "@react-native-async-storage/async-storage";

export type Thumb = "POS" | "NEU" | "NEG";

const KEY_PASS = "@taxa5:rating:passageiro";
const KEY_MOT = "@taxa5:rating:motorista";

const STREAK_TYPE_PASS = "@taxa5:streak:type:passageiro";
const STREAK_COUNT_PASS = "@taxa5:streak:count:passageiro";
const STREAK_START_PASS = "@taxa5:streak:start:passageiro";

const STREAK_TYPE_MOT = "@taxa5:streak:type:motorista";
const STREAK_COUNT_MOT = "@taxa5:streak:count:motorista";
const STREAK_START_MOT = "@taxa5:streak:start:motorista";

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function round1(n: number) {
  return Math.round(n * 10) / 10;
}

function keys(role: "passageiro" | "motorista") {
  const ratingKey = role === "motorista" ? KEY_MOT : KEY_PASS;
  const typeKey = role === "motorista" ? STREAK_TYPE_MOT : STREAK_TYPE_PASS;
  const countKey = role === "motorista" ? STREAK_COUNT_MOT : STREAK_COUNT_PASS;
  const startKey = role === "motorista" ? STREAK_START_MOT : STREAK_START_PASS;
  return { ratingKey, typeKey, countKey, startKey };
}

export async function getRating(role: "passageiro" | "motorista") {
  const { ratingKey } = keys(role);
  const v = await AsyncStorage.getItem(ratingKey);
  if (!v) {
    await AsyncStorage.setItem(ratingKey, "10.0");
    return 10.0;
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : 10.0;
}

async function getStreak(role: "passageiro" | "motorista") {
  const { typeKey, countKey, startKey } = keys(role);
  const t = (await AsyncStorage.getItem(typeKey)) as Thumb | null;
  const c = Number((await AsyncStorage.getItem(countKey)) ?? "0");
  const s = Number((await AsyncStorage.getItem(startKey)) ?? "0");
  return {
    t: t === "POS" || t === "NEG" ? t : null,
    c: Number.isFinite(c) ? c : 0,
    start: Number.isFinite(s) ? s : 0,
  };
}

async function setStreak(role: "passageiro" | "motorista", t: Thumb | null, c: number, start: number) {
  const { typeKey, countKey, startKey } = keys(role);
  if (!t) {
    await AsyncStorage.removeItem(typeKey);
    await AsyncStorage.setItem(countKey, "0");
    await AsyncStorage.removeItem(startKey);
    return;
  }
  await AsyncStorage.setItem(typeKey, t);
  await AsyncStorage.setItem(countKey, String(c));
  await AsyncStorage.setItem(startKey, String(start));
}

/**
 * Regra:
 * - cada joinha POS/NEG: +/- 0.1
 * - 5 seguidos: total da sequência vira +/- 1.0 (ajuste automático)
 * - 10 seguidos: total da sequência vira +/- 3.0 (salto)
 * - NEU: não muda e zera sequência
 */
export async function applyThumb(role: "passageiro" | "motorista", thumb: Thumb) {
  const { ratingKey } = keys(role);
  const cur = await getRating(role);
  const st = await getStreak(role);

  if (thumb === "NEU") {
    await setStreak(role, null, 0, 0);
    await AsyncStorage.setItem(ratingKey, round1(cur).toFixed(1));
    return round1(cur);
  }

  // inicia ou continua a sequência
  const same = st.t === thumb;
  const count = same ? Math.min(st.c + 1, 10) : 1; // cap em 10
  const start = same ? st.start : cur; // start é a nota antes do 1º da sequência

  // aplica delta base 0.1
  let next = thumb === "POS" ? cur + 0.1 : cur - 0.1;

  // marcos de sequência:
  // no 5º, a sequência TOTAL deve ser +/- 1.0 desde o start
  if (count === 5) {
    next = thumb === "POS" ? start + 1.0 : start - 1.0;
  }

  // no 10º, a sequência TOTAL deve ser +/- 3.0 desde o start
  if (count === 10) {
    next = thumb === "POS" ? start + 3.0 : start - 3.0;
  }

  next = round1(clamp(next, 0, 10));

  await AsyncStorage.setItem(ratingKey, next.toFixed(1));
  await setStreak(role, thumb, count, start);

  return next;
}

export function isBlockedByRating(rating: number) {
  return rating <= 3.0;
}

export function shouldShowManual(rating: number) {
  return rating <= 5.0;
}
