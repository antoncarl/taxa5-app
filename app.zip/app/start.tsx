import { Cinzel_700Bold } from "@expo-google-fonts/cinzel";
import { useFonts } from "expo-font";
import { useRouter } from "expo-router";
import React, { useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// Identidade visual (branco gelo + azul premium)
const UI = {
  colors: {
    bg: "#EEF5FF", // branco gelo
    text: "#0B1B2B",
    muted: "rgba(11,27,43,0.55)",
    blue: "#1F66D1",
    blue2: "#2B7AE6",
    white: "#FFFFFF",
    border: "rgba(11,27,43,0.10)",
    glow: "rgba(31,102,209,0.35)",
    sentinel: "#16A34A",
  },
  radius: { lg: 18, xl: 22 },
};

export default function Start() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [fontsLoaded] = useFonts({
    Cinzel_700Bold,
  });

  const headerFont = useMemo(
    () => (fontsLoaded ? { fontFamily: "Cinzel_700Bold" } : null),
    [fontsLoaded]
  );

  return (
    <View style={[styles.screen, { paddingTop: insets.top + 18, paddingBottom: insets.bottom + 18 }]}>
      {/* Topo */}
      <View style={styles.top}>
        <Text style={[styles.company, headerFont]}>Taxa 5 Tecnologia LTDA</Text>
      </View>

      {/* Meio: botões centralizados com “respiro” igual pra cima e pra baixo */}
      <View style={styles.middle}>
        <PrimaryButton
          title="MOTORISTA"
          onPress={() => router.push("/motorista/100")}
        />
        <View style={{ height: 14 }} />
        <PrimaryButton
          title="PASSAGEIRO"
          onPress={() => router.push("/passageiro/3")}
        />
      </View>

      {/* Rodapé */}
      <View style={styles.bottom}>
        <Text style={[styles.sentinel, headerFont]}>Security Sentinel Protocol</Text>
      </View>
    </View>
  );
}

function PrimaryButton({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.btn,
        pressed && { transform: [{ scale: 0.99 }], opacity: 0.96 },
      ]}
    >
      <Text style={styles.btnText}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: UI.colors.bg,
    paddingHorizontal: 18,
  },

  top: {
    alignItems: "center",
  },

  company: {
    color: UI.colors.text,
    fontSize: 20,
    letterSpacing: 0.6,
  },

  middle: {
    flex: 1,
    justifyContent: "center",
  },

  btn: {
    height: 64,
    borderRadius: UI.radius.xl,
    backgroundColor: UI.colors.blue2,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",

    // sombra “premium” leve
    shadowColor: UI.colors.glow,
    shadowOpacity: 0.35,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 3,
  },

  btnText: {
    color: UI.colors.white,
    fontSize: 18,
    fontWeight: "900",
    letterSpacing: 2,
  },

  bottom: {
    alignItems: "center",
  },

  sentinel: {
    color: UI.colors.sentinel,
    fontSize: 14,
    letterSpacing: 0.8,
  },
});