import React, { createContext, useContext, useMemo, useState } from "react";

export type RideStatus =
  | "idle"
  | "draft"
  | "requesting"
  | "waiting_driver"
  | "accepted"
  | "driver_arriving"
  | "on_trip"
  | "finished"
  | "cancelled";

export type LatLng = { latitude: number; longitude: number };

export type RideCategory = {
  id: string;
  name: string;
  etaMin: number;
  price: number;
  badge?: string;
};

export type RideSession = {
  id: string;
  status: RideStatus;

  passengerName: string;

  pickupText: string;
  destinationText: string;

  pickup: LatLng | null;
  destination: LatLng | null;

  category: RideCategory | null;

  driverId: string | null;
  driverName: string | null;
  driverCar: string | null;

  driverPos: LatLng | null;
};

type SessionContextValue = {
  ride: RideSession;
  setPassengerName: (name: string) => void;

  setDraftAddresses: (pickupText: string, destinationText: string) => void;
  setDraftCoords: (pickup: LatLng | null, destination: LatLng | null) => void;

  chooseCategory: (cat: RideCategory) => void;
  requestRide: () => void;

  driverAcceptRide: (driver: {
    id: string;
    name: string;
    car: string;
    pos: LatLng;
  }) => void;

  driverUpdatePos: (pos: LatLng) => void;

  cancelRide: () => void;
  finishRide: () => void;

  resetRide: () => void;
};

const SessionContext = createContext<SessionContextValue | null>(null);

const makeId = () => `ride_${Math.random().toString(16).slice(2)}_${Date.now()}`;

const defaultRide = (): RideSession => ({
  id: makeId(),
  status: "idle",
  passengerName: "Anton",

  pickupText: "Sua localização",
  destinationText: "",

  pickup: null,
  destination: null,

  category: null,

  driverId: null,
  driverName: null,
  driverCar: null,
  driverPos: null,
});

export function SessionProvider({ children }: { children: React.ReactNode }) {
  const [ride, setRide] = useState<RideSession>(() => defaultRide());

  const api = useMemo<SessionContextValue>(() => {
    return {
      ride,

      setPassengerName: (name) =>
        setRide((r) => ({
          ...r,
          passengerName: name?.trim() ? name.trim() : r.passengerName,
        })),

      setDraftAddresses: (pickupText, destinationText) =>
        setRide((r) => ({
          ...r,
          status: r.status === "idle" ? "draft" : r.status,
          pickupText,
          destinationText,
        })),

      setDraftCoords: (pickup, destination) =>
        setRide((r) => ({
          ...r,
          status: r.status === "idle" ? "draft" : r.status,
          pickup,
          destination,
        })),

      chooseCategory: (cat) =>
        setRide((r) => ({
          ...r,
          category: cat,
        })),

      requestRide: () =>
        setRide((r) => {
          // trava regra: precisa pickup + destination + category
          if (!r.pickup || !r.destination || !r.category) return r;
          return {
            ...r,
            status: "waiting_driver",
            driverId: null,
            driverName: null,
            driverCar: null,
            driverPos: null,
          };
        }),

      driverAcceptRide: (driver) =>
        setRide((r) => {
          if (r.status !== "waiting_driver") return r;
          return {
            ...r,
            status: "driver_arriving",
            driverId: driver.id,
            driverName: driver.name,
            driverCar: driver.car,
            driverPos: driver.pos,
          };
        }),

      driverUpdatePos: (pos) =>
        setRide((r) => ({
          ...r,
          driverPos: pos,
        })),

      cancelRide: () =>
        setRide((r) => ({
          ...r,
          status: "cancelled",
        })),

      finishRide: () =>
        setRide((r) => ({
          ...r,
          status: "finished",
        })),

      resetRide: () => setRide(defaultRide()),
    };
  }, [ride]);

  return <SessionContext.Provider value={api}>{children}</SessionContext.Provider>;
}

export function useSession() {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error("useSession must be used within SessionProvider");
  return ctx;
}