import { useRouter } from "expo-router";
import { Text, TouchableOpacity, View } from "react-native";

export default function EscolhaPerfil() {
  const router = useRouter();

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 24, marginBottom: 30 }}>
        Quem está usando?
      </Text>

      <TouchableOpacity
        onPress={() => router.push("/driver/DriverMap")}
        style={{
          backgroundColor: "#2e86de",
          padding: 15,
          borderRadius: 10,
          marginBottom: 15,
        }}
      >
        <Text style={{ color: "#fff" }}>Sou Motorista</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => router.push("/buscar-destino")}
        style={{
          backgroundColor: "#27ae60",
          padding: 15,
          borderRadius: 10,
        }}
      >
        <Text style={{ color: "#fff" }}>Sou Passageiro</Text>
      </TouchableOpacity>
    </View>
  );
}
